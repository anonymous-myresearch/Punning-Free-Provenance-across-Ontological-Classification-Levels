# Verification artefacts

Companion material for **Punning-Free Provenance across Ontological
Classification Levels**. This standalone package contains the executable
analyses, written models, fixtures, queries, expected results, raw reasoner
outputs and reproduction documentation used by the paper. Paper sources and
PDFs are not required.

## Quick start

Requirements: Python 3.10 or later, a Java 17 or later **JDK** containing
`jdk.compiler`, and GNU Make. The HermiT JAR, licence notices, local PROV-O
imports and selected native modelling dependencies are included. Put `java`
on `PATH`, or set `PROV_JAVA` to its executable.

Extract the ZIP into a writable directory. From the directory containing this
README and Makefile, run:

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
make check-integrity
make check
```

The requirements pin RDFLib 7.1.4 and owlrl 7.1.4. Installing Python packages
requires access to a package index unless they are already available. The
reasoner uses the bundled imports and does not fetch ontologies from the Web.
The full check takes a few minutes, depending on the machine. No LaTeX
installation is needed. `make check` exits with status 0 when every check
matches its declared expectations.

The experiments regenerate inputs and reports. The checksum manifest describes
the files **as distributed**, so run `make check-integrity` before rerunning the
experiments, or against a fresh extraction afterwards. Changes to timestamps,
runtime measurements or generated RDF serialisations need not change answers.

## Connection to the paper

| Paper evidence | Directory | Expected results |
|---|---|---|
| Section 6.1, chart policies and Table 1 | `provenance-profile/chart-analysis/` | Five rules, five snapshots, 25 complete output comparisons and 74 individual checks |
| Section 6.1, independent RDF/SPARQL comparison | `provenance-profile/chart-baseline/` | 25 matching output sets, 32 answer tuples and 55 input-relation comparisons |
| Section 6.2, E1-E3 controls in Table 2 | `provenance-profile/owl-reasoner/controls/` | Per import arm: 20 consistent cases, 340 entailment expectations and 65 satisfiability checks |
| Section 6.2, E4/E5 metamodel comparison in Table 2 | `provenance-profile/owl-reasoner/metamodel/` | 110 HermiT runs across two imports; per arm, 30 consistent and 25 inconsistent inputs |
| Section 6.3, controlled native changes and Table 3 | `provenance-profile/model-integration/` | 15 sources: eight accepted, seven rejected; 40 native and 40 SPARQL output comparisons |
| Section 6.4, native-DL-native integration and Table 4 | `provenance-profile/integration-run/` | Nine sources: seven accepted, two rejected; 14 HermiT runs; per arm, 19 entailed and three non-entailed coverage subsumptions, plus 42 provenance checks |
| Section 6.5, RDF interchange probes | `provenance-profile/tools/interchange_probe.py` | Six passing round trips and two expected loss rejections |
| Appendix A, PROV import variants | `provenance-profile/owl-reasoner/backend/` | Unchanged source and separately manifested projection, removing exactly two annotation-property declarations |

Module READMEs explain the inputs, commands, oracles and report files in detail.
`provenance-profile/PROFILE_SPECIFICATION.md`,
`provenance-profile/INTERFACES.tsv` and the native `.fhas` and `.dl`
files describe the selected binding and analysis interfaces. Keep the directory
name `provenance-profile`: experimental manifests use that relative path.

## Expected negative outcomes and retained corrections

Some test ontologies are deliberately inconsistent or contain unsatisfiable
classes. Seven native change cases and two integration sources are deliberately
rejected before export. These are successful checks when the actual outcomes
match the oracles.

The unchanged PROV-O import has a known strict-DL property-punning diagnostic.
The control report retains 15 unmet original raw-import profile expectations;
its semantic expectations agree. The separate projected import is checked
against its declared profile expectations. E3 adds SWRL rules. Neither raw
reasoner execution nor acceptance of those extensions is presented as strict
OWL 2 DL conformance.

The original metamodel oracle error and its correction remain in
`provenance-profile/owl-reasoner/metamodel/results/first-run/`. The original
order-sensitive I1 import and its corrected declaration/serialization regression
remain in `provenance-profile/integration-run/regressions/raw-role-declarations/`.
These are retained to reproduce the process notes in the paper.

## Additional commands

```sh
# Inspect the recorded E1-E5 results and their hashes/oracles without HermiT.
make check-reports

# Rerun the I1 import/declaration regression (six further HermiT executions).
make check-regression
```

The default `make check` also retains the supplementary workflow validation
described in Appendix A. The optional modern-parser cross-check stored in the
backend is additional recorded evidence; rerunning it requires its separately
documented external tooling and is not part of the default checks.

## Execution scope and dependencies

Native execution uses independent bounded reference interpreters. OWL answers
come from the bundled HermiT 1.3.8.1099/OWLAPI 3.4.3 Java backend. This package
does not require the official PAMoLa runtime and does not certify that runtime
or the complete LML/TRD language. Recorded provenance, direct classification,
external entailments and policy witnesses use separate interfaces.

The HermiT binary is pinned by SHA-256 and accompanied by its upstream licence
and notices in `provenance-profile/owl-reasoner/backend/`. Dependency versions
and source/import hashes are recorded there and in module manifests. Fresh
standalone reproduction results are summarised in `verification/VALIDATION.json`
and its accompanying log.
