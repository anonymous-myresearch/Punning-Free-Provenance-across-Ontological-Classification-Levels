#!/usr/bin/env python3
"""Verify the files as distributed, before regenerating experiment outputs."""
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
manifest = json.loads((root / "SHA256SUMS.json").read_text())
failures = []
for name, expected in manifest.items():
    path = root / name
    if not path.is_file():
        failures.append(f"Missing: {name}")
    elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        failures.append(f"Changed: {name}")
if failures:
    print("\n".join(failures))
    print("Checksums describe the distributed files; rerunning experiments can change reports.")
    sys.exit(1)
print(f"PASS: SHA-256 hashes match for all {len(manifest)} distributed files.")
