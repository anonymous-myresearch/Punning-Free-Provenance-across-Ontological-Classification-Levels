# Provenance profile and bounded OCA binding

Revision 6 review draft, 25 October 2026. The implemented binding connects an
authored native model to recorded provenance, standard-facing views, real OWL
reasoning and native policy witnesses. It is an experimental reference binding,
not an adopted standard or the official PAMoLa runtime.

E4/E5 now provide a bounded Glimm-based metamodel comparison with explicit
role exemptions, policy closure and layer-placement controls. It is evaluated
within its documented fragment, rather than presented as a complete comparison
of every metamodeling approach.

## Native representation and validation

Orthogonal classification separates linguistic kind from ontological
classification. StatisticalChartType, CrimeRateChart_v1 and chart1 all have
linguistic kind Core.Entity. The category classifies the definition, which
classifies the chart. The definition is attributed to Alice and derived from a
guideline; chart1 retains its own attribution to Derek and derivation from data.
A native classifier has one identity in these roles. Core.Entity is a modelling
construct, distinct from the domain concept prov:Entity.

`Provenance_Profile_Candidate.fhas` binds 95 named PROV-O class/property identities
and eight selected P-Plan terms, with external IRI markers and predicate
signatures. Provenance assertions are native Atoms with role-bound Arguments.
Model-specific assertions belong to the data; reusable declarations, interfaces
and rules belong to the profile. Structural Relationships could expose the same
interfaces, but the evaluated representation uses Atoms and native attributes.
No new Core category or public PROV predicate is introduced.

The independent interpreter in `model-integration/verify_integration.py` checks
a selected native contract. Direct classification D(x,t) obeys fixed-step
potency p(t) = p(x) + 1. Categories have potency 2, definitions potency 1 and charts
potency 0. Classifier specialisation G is acyclic and connects equal-potency
elements. With S the reflexive-transitive closure of G, conformance H(x,u) holds
when D(x,t) and S(t,u) hold for some t. D itself is not transitively closed.
PROV revision creates neither D nor G.

A category's Boolean approval schema has durability 1. Corresponding attributes
on its definitions have the same semantic name/datatype and durability 0. This
requires approval information on definitions without requiring it on charts or
copying values between levels. Selected potency, applicability, correspondence
and durability checks follow the included LML rule occurrences identified in
`model-integration/README.md`. This is a bounded interpretation, not complete
LML/TRD or Participation conformance.

A true approval value projects approval under the category owning its schema,
independently of the definition's current declared type. False does not project
positive approval. Ambiguous schemas and duplicate owner/category observations
are rejected. Recategorisation therefore preserves old approval scope.
Completeness is supplied category/context evidence, accepted only when the
selected definitions have known Boolean observations. Unknown approval with no
certificate is an accepted incomplete snapshot; unknown approval with a claimed
certificate is rejected. This cannot establish completeness of an unseen registry.
Failed retrieval remains a separate processing failure; no live adapter is tested.

## Standard-facing projection

An injective mapping uses native persistent IRIs where present and otherwise
full qualified identities; collisions are rejected. The selected RDF view exposes
direct classification through asserted `rdf:type`, recorded provenance through
standard PROV predicates, approval through definition/category pairs, and
context-local approval requirements/completeness. Linguistic typing remains
separate. Explicit classifier specialisation can be projected as
`rdfs:subClassOf` without closing the direct-type evidence view.

The earlier finite analyses use recorded assertions, without RDFS/OWL closure.
In particular, revision is retained without adding its entailed derivation to
that selected input. Seven analysis relations are checked through an inverse
projection: direct typing, derivation, attribution, revision, approval,
requirements and completeness. That is an interface-preservation check, not
reconstruction of all native structures or statement-occurrence identities.

RDF already permits classifiers to be resources with their own provenance.
Matching RDF/SPARQL answers check the binding's interpretation rather than an
exclusive expressivity claim. The controlled stale-view comparison detects a
changed view, not an implemented production cache invalidator or a measured
maintenance advantage.

## Original category-scoped policy

`chart-analysis/Chart_Analysis_Profile.fhas` contains five clauses and eleven
private interfaces. All relations have one selected context C. Inputs are
`directType(C,X,T)`, `derived(C,X,S)`, `attributed(C,X,A)`,
`requiresApproval(C,K)`, `completeApprovalRegistry(C,K)` and
`approvedType(C,T,K)`. Additional recorded inputs are retained for preservation
comparisons.

| Output | Meaning |
|---|---|
| classifierProvenance(C,X,T,S,A) | X directly instantiates T, whose recorded history identifies source S and agent A. |
| reviewType(C,T,K) | Required approval for T under K is absent from a complete registry. |
| reviewEntity(C,X,T) | X directly instantiates a definition selected for review. |
| reviewPublication(C,P,X,T) | P has a recorded direct derivation from such X. |
| approvalUndetermined(C,T,K) | Required positive approval and a completeness certificate are both absent. |

Positive approval prevents an undetermined witness even if the rest of the
registry is incomplete. The interface exposes positive approvals and completeness,
not a full truth-valued approval/refusal account. Missing review does not prove
approval or validity. Review follows one derivation edge and does not infer a
publication type, falsity of content or retrospective invalidity.

Only private witness predicates occur in rule heads. Classifier attribution and
derivation are not copied onto instances. The five supplied contexts cover
approval before/after withdrawal, incomplete evidence, a new classifier and
recategorisation. These are supplied snapshots, not inferred approval intervals
or automatically captured withdrawal events.

## E1–E3 real reasoner controls

`owl-reasoner/controls/` preserves all five canonical asserted graphs and adds
explicit declarations/imports plus each declared control change. E1 observes
punning; E1-equality equates individual uses without equating class extensions;
E2 replaces one classifier's category membership with subclassing; E3 adds one
fixed-class SWRL rule propagating attribution to named chart instances.

OWLAPI loads the generated ontology documents and HermiT answers the queries.
Python manages processes and reports rather than simulating inference. Each
PROV import arm has 20 cases, 340 entailment checks and 65 satisfiability checks.
All semantic expectations match, and 20 case comparisons establish cross-arm
answer correspondence for the tested queries. False answers mean not entailed,
not explicit negative assertions. These are semantic controls, not complete
competing implementations of the review policy.

The raw-import reports retain 15 unmet preregistered DL-profile expectations.
The projected arm supports strict-DL claims for the 15 rule-free E1/E1-equality/E2
inputs. The five E3 inputs remain explicit SWRL extensions, despite the profile
checker's permissive acceptance. No unrestricted SWRL completeness claim follows.

## E4/E5: bounded metamodel comparison

`owl-reasoner/metamodel/` maps its construction to Glimm, Rudolph and Völker's
published two-layer transformation. The uniform three-level and layer-separated
PROV-role cases are inconsistent under the tested constraints. A consistent
bounded adaptation exempts the PROV/policy roles and leaves the category's class
reading unlinked to its policy-individual reading. The published correspondence
theorem is not claimed for that entire adapted ontology.

An explicit review policy, nominal closure for complete category registries and
AllDifferent representatives reproduce the original five-snapshot review sets.
Without closure the review conclusion is not entailed. The implemented baseline
is silent for the incomplete registry; this does not establish that OWL cannot
represent an undetermined witness. The tests retain the category scope and
provenance subjects and manifest all encoding-specific changes to source facts.

Flattening is inconsistent under the tested hard layer constraints when the
category's layer placement is authored. Without that placement, or when level
annotations apply only to the individual uses of punned names, the unintended
chart membership is entailed consistently. Native validation rejects the
corresponding cross-level generalisation before projection with the named
`generalisation-level` witness; its separate direct-typing mutation is a
`potency-step` failure. The hard-constraint comparison does not imply that
Glimm's approach cannot locate violations: the published work also supplies a
marker-predicate diagnostic route.

Eleven cases across five canonical contexts and two imports give 110 actual
HermiT runs. Per arm, 30 inputs are consistent and 25 inconsistent. All 55
projected inputs pass the OWL 2 DL profile checker; syntactic profile acceptance
is independent of those consistency results. Raw-import reports retain the
known PROV-O profile diagnostics. The first-run oracle wrongly expected unsatisfiability in each of the five
unassigned-layer controls, producing five mismatches per import arm. The
corrected expectations and unchanged first-run reports are disclosed in the
module README and `results/first-run/`. No runtime, deployment or maintenance
advantage is established by this comparison.

## I1: native → OWL → native policy

`integration-run/` starts from written native Atoms using the existing
SemanticWeb constructors Class, Declaration, Import, ObjectUnionOf,
EquivalentClasses and SubClassOf. Arguments fill their existing signature roles,
refer to native elements/constructor occurrences, and retain variadic operand
occurrences. The verifier independently checks these sources and generates OWL
from them; it does not append the coverage axioms independently in Python.

The selected definition is Chart equivalent to PublicSourceChart union
RestrictedSourceChart. Both branches are subclasses of ReviewEligibleChart;
each chart-definition class is a subclass of Chart. HermiT establishes the
resulting class-level coverage subsumptions. Removing the restricted branch's
coverage axiom makes the target subsumptions not entailed; an explicit finite
counterinterpretation checks the remaining coverage axioms. It is not claimed
as a complete model of imported PROV-O.

Positive answers are written as signature-bound native `dlSubClassOf(C,T,R)`
Atoms and independently reparsed. They stay separate from native `directType`.
The original five policy rules are unchanged. One additional decoded clause is:

```text
dlReviewWitness(C,X,T,K,A) :-
  reviewType(C,T,K), directType(C,X,T), attributed(C,T,A),
  dlSubClassOf(C,T,R), policyTarget(C,R).
```

`policyTarget` is an explicit native input. The output retains the chart,
definition, category and classifier's attributed agent as explanatory support;
it does not assert the chart's responsibility. Absent entailment prevents this
additional witness without asserting ineligibility or suppressing the original
review/undetermined outputs.

The union definition lies outside OWL 2 RL. The runner actually executes the
standard OWL 2 RL/RDF closure over the same generated input and import, rather
than relying on a profile warning. It leaves all 22 queried coverage subsumptions
underived, missing 19 positive DL results. This is a dependency beyond that
standard rule set, not a claim that custom rules could never compute the result.
Forty-two PROV entailment checks per arm agree between HermiT and RL, including
revision implying derivation. That inferred fact remains separate from recorded
native history.

I1 has nine native sources: seven accepted and two expected pre-export rejections
for potency or union arity. Both import variants run on every accepted source,
giving 14 HermiT executions. Per arm, 19 of 22 subsumptions are entailed and three
are not entailed. Five canonical asserted graphs are preserved, including
qualification/generation facts. There are 35 original-policy SPARQL comparisons,
seven new-policy oracles and seven returned-FHAS checks. An omitted-axiom control
and a one-reference native reclassification edit preserve recorded history while
changing guarded policy witnesses.

## Explicit PROV import variants

The raw arm uses the unchanged complete pinned PROV-O snapshot. It declares
prov:specializationOf and prov:wasRevisionOf as both object and annotation
properties, producing profile diagnostics. Processing success is not a strict
OWL 2 DL conformance certificate for that raw import.

`owl-reasoner/backend/prov-o-metadata-projection.ttl` removes exactly those two
`rdf:type owl:AnnotationProperty` declarations. Corresponding object-property
declarations, all application schema and all ontology-document history remain.
The original source bytes are unchanged: 1,146 source triples become 1,144
projected triples, with no additions. The exact delta and hashes are recorded in
`owl-reasoner/backend/metadata-projection-manifest.json`. All seven projected I1
inputs pass the DL profile. The two import variants are reported separately;
answer correspondence does not establish unrestricted RDF-semantic equivalence.

The backend distinguishes import/load failures, unsupported constructs,
inconsistency, unsatisfiability, partial query execution, timeouts and process
errors from non-entailment. These processing outcomes cannot count as successful
empty policy answers.

## Commands and retained evidence

Requirements are Python 3.10+, Java 17 with `jdk.compiler`, RDFLib 7.1.4 and
owlrl 7.1.4. From **provenance-profile**:

```sh
python3 -m pip install -r requirements.txt
python3 owl-reasoner/tools/test_backend.py
python3 chart-analysis/verify_chart.py
python3 chart-baseline/compare_native.py
python3 model-integration/verify_integration.py
python3 owl-reasoner/controls/verify_suite.py
python3 integration-run/verify_i1.py
python3 owl-reasoner/metamodel/build_metamodel.py
python3 owl-reasoner/metamodel/run_metamodel.py
python3 owl-reasoner/metamodel/run_metamodel.py --prov-variant metadata_projection
python3 owl-reasoner/metamodel/verify_metamodel.py
```

The control-suite command reruns real reasoning by default;
`python3 owl-reasoner/controls/verify_suite.py --check-reports` checks recorded
reports only. The SPARQL parity script also runs the independent baseline.
The metamodel verifier checks existing reports without launching HermiT; both
runner commands execute fresh calls. From the project root, `make check`
includes these and the supplementary checks.

| Earlier bounded evidence | Result |
|---|---|
| Chart policy | Five contexts; 25 complete outputs, 74 positive/negative checks, 54 nonempty input-preservation checks. |
| Independent RDF/SPARQL baseline | 25 matching output sets, 32 answer tuples, 55 matching input-relation sets. |
| Native-model integration | Fifteen sources, eight accepted/seven rejected; 40 native output-oracle and 40 SPARQL checks, 56 interface round-trip comparisons, eight input-preservation and 18 history checks. |
| Supplementary legacy workflow | Seven clauses, twelve snapshots, 84 complete output comparisons, 91 individual checks; separate interfaces from the chart module. |
| Supplementary interchange | Six selected RDF round trips pass; two empty-named-graph-loss cases are rejected. |

The supplementary commands are `python3 tools/validate_profile.py` and
`python3 tools/interchange_probe.py`. Those RDFLib probes are not deployed PAMoLa
adapters or full format-conformance tests. N-Quads cannot declare empty graphs;
TriG can, but the tested binding drops them and explicitly rejects that loss.
Module READMEs identify all complete outputs, oracles, input digests and reports.

## Remaining boundaries

The integration uses actual external DL reasoning with a bounded native binding.
It does not establish complete OWL/native translation, general metamodel-reasoner
semantics, full PROV validity, automatic provenance capture, arbitrary temporal
histories, complete LML/TRD execution or official runtime integration. External
OWL DL views may use legal punning without becoming the authority for native
direct classification. RDF/SPARQL policy parity and these finite executions do
not measure maintenance/performance superiority. The E4/E5 evidence is limited
to the documented adaptation and controls. No standards adoption or mandatory
conformance badge is claimed.
