# PAMoLa provenance profile

Standalone verification artefact, 26 October 2026. The package executes a native
model → generated OWL view → HermiT → returned native answer → provenance-policy
path. Earlier native/SPARQL policy checks remain available. The integration uses
independent bounded reference interpreters and a real OWLAPI/HermiT backend;
it is not the official PAMoLa runtime or a complete LML/TRD implementation.

E4/E5 now include an executed bounded Glimm-based metamodel adaptation, closure
and level controls. Its implementation, exact axiom changes, original and
corrected expectations, and raw results are in `owl-reasoner/metamodel/`.

## Requirements and commands

Use Python 3.10+, RDFLib 7.1.4, owlrl 7.1.4 and a Java 17 JDK/runtime containing
`jdk.compiler`. Put `java` on `PATH` or set `PROV_JAVA` to its executable.
The pinned JAR and local PROV import are bundled. Commands below run **from the
provenance-profile directory**:

```sh
python3 -m pip install -r requirements.txt
python3 owl-reasoner/tools/test_backend.py
python3 chart-analysis/verify_chart.py
python3 chart-baseline/compare_native.py
python3 model-integration/verify_integration.py
python3 owl-reasoner/controls/verify_suite.py
python3 integration-run/verify_i1.py
python3 owl-reasoner/metamodel/build_metamodel.py
python3 owl-reasoner/metamodel/run_metamodel.py
python3 owl-reasoner/metamodel/run_metamodel.py --prov-variant metadata_projection
python3 owl-reasoner/metamodel/verify_metamodel.py
```

The control-suite verifier reruns real reasoning by default. Recorded-report
inspection alone uses:

```sh
python3 owl-reasoner/controls/verify_suite.py --check-reports
```

`compare_native.py` also runs the independent SPARQL baseline. Its standalone
runner is `python3 chart-baseline/run_baseline.py`. From the project root,
`make check` runs the checks plus the supplementary workflow/interchange tests.
Sources and expectations are checked in; module READMEs document regeneration.
The E4/E5 first-run oracle correction and its original reports remain available.
Its verifier checks recorded reports without launching the reasoner; the two
preceding runner commands execute fresh HermiT calls.

## New executed evidence

| Module | Verified evidence | Reports and detail |
|---|---|---|
| E1–E3 controls | Twenty cases per import arm; 340 entailment and 65 satisfiability checks per arm; 20 cross-arm case comparisons agree. | `owl-reasoner/controls/README.md`, `owl-reasoner/controls/results/report.json`, `owl-reasoner/controls/results/metadata-projection/report.json` |
| E4/E5 metamodel comparison | Eleven cases × five contexts × two imports: 110 HermiT runs. Per arm: 30 consistent, 25 inconsistent; all 55 projected inputs pass the DL profile checker. | `owl-reasoner/metamodel/README.md`, `owl-reasoner/metamodel/results/raw/report.json`, `owl-reasoner/metamodel/results/metadata_projection/report.json` |
| I1 native/OWL/native integration | Nine sources: seven accepted and two expected pre-export rejections. Fourteen HermiT runs; per arm, 22 subsumption checks (19 entailed, three not entailed) and 42 provenance checks. | `integration-run/README.md`, `integration-run/results/report.json` |
| I1 policy return path | Five canonical asserted graphs preserved; 35 original-rule SPARQL comparisons, seven additional policy-oracle comparisons and seven returned-FHAS checks. | `integration-run/results/report.json` |

E1 tests punning and its separation of roles. E1-equality adds equality between
individual uses without equating their class extensions. E2 deliberately
replaces one instance-membership assertion with subclassing, changing the chart
population. E3 adds one fixed-class SWRL attribution-copying rule and observes
the extra responsibility assertions. These are explanatory semantic controls,
not complete implementations of competing provenance policies.

E4 uses the published two-layer construction as the basis of a bounded
provenance adaptation. Applying one instance/class separation uniformly to all
three scenario levels is inconsistent. The consistent bounded route exempts
PROV/policy roles from that separation and leaves the category's class reading
unlinked to its policy-individual reading. Nominal closure of complete approval
registries and AllDifferent representatives reproduce the native review sets
for all five snapshots. The implemented OWL baseline emits no undetermined
witness in the incomplete case; OWL is not claimed incapable of expressing one.
E5's hard constraints detect flattening when the category's layer placement is
supplied. Removing that placement admits the unintended population. The native
contract rejects before projection with a named witness. Global inconsistency is
the tested OWL diagnostic route, not Glimm's only option: the published work also
provides marker predicates for localisation. These finite experiments measure no
runtime, authoring-effort or maintenance advantage.

I1 represents a union-based coverage definition using existing native SemanticWeb
constructors. The generated ontology entails definition-class subsumption into
a policy target when both branches are covered. Standard OWL 2 RL/RDF closure
leaves all 22 queried coverage subsumptions underived, missing the 19 positive
DL consequences. Its 42 provenance answers agree with HermiT. This establishes
a dependency beyond the tested standard rule set, not an impossibility result
for custom Datalog.

Positive class-level answers are written as signature-bound native Atoms,
reparsed, and joined with direct classification, classifier attribution and the
original category-scoped review condition. One additional rule derives guarded
witnesses; the original five chart rules are unchanged. Dropping one coverage
axiom removes the guard while leaving original review outputs available.
Reclassifying chart1 under approved v2 changes the guarded witnesses without
changing recorded history. Non-entailment does not assert ineligibility.

## Two explicitly distinguished PROV imports

The raw arm uses the complete, unchanged pinned PROV-O snapshot. Its
object/annotation-property punning triggers DL-profile diagnostics. Fifteen
predeclared raw-control profile expectations remain unmet and are retained in
`owl-reasoner/controls/results/report.json`; all semantic expectations match.
A successful reasoner run is separate from a strict OWL 2 DL profile claim.

The projected arm removes exactly two `rdf:type owl:AnnotationProperty`
declarations for `prov:specializationOf` and `prov:wasRevisionOf`. Both
object-property declarations, application schema and ontology-document history
remain. The source is unchanged; triple counts are 1,146 and 1,144. The exact
delta and hashes are in `owl-reasoner/backend/metadata-projection-manifest.json`.

Fifteen rule-free projected controls are claimed as OWL 2 DL inputs. The five
E3 inputs remain SWRL extensions, even though the profile checker accepts them.
All seven projected I1 inputs and all 55 projected E4/E5 inputs pass the DL
profile; this is separate from their consistency outcomes. Agreement on tested answers
between arms does not establish unrestricted RDF-semantic equivalence.

## Earlier bounded checks

| Module | Verified result | Report |
|---|---|---|
| Chart policy | Five rules, five contexts, 25 complete outputs, 74 positive/negative checks and 54 nonempty input-preservation checks. | `chart-analysis/results/chart-validation.json` |
| Independent RDF/SPARQL baseline | 25 matching output sets, 32 answer tuples and 55 matching input-relation sets; ordinary asserted `rdf:type`. | `chart-baseline/results.json`, `chart-baseline/native-parity.json` |
| Native-model integration | Fifteen sources: eight accepted and seven expected rejections; 40 native output-oracle checks, 40 SPARQL parity checks, 56 interface round-trip comparisons, eight input-preservation checks and 18 recorded-history comparisons. | `model-integration/results/report.json` |

The selected native contract checks linguistic kinds, fixed-step potency,
required attribute correspondence, durability, category-specific approval and
evidence completeness. Round-trip checks cover seven analysis input relations,
not reconstruction of the whole native model. Approval and completeness are
context/category specific. `approvalUndetermined` reports missing positive
approval without completeness; it is not a complete truth-valued refusal model.

Recorded provenance stays separate from inferred history and policy witnesses.
The original chart analysis uses recorded assertions without entailment closure
and follows one derivation edge to consumers. I1 separately tests the imported
PROV entailment from revision to derivation without adding it to recorded native
history. Live registry retrieval failure is a processing outcome, not an ordinary
incomplete-evidence snapshot; no live adapter is supplied.

## Supplementary material and scope

```sh
python3 tools/validate_profile.py
python3 tools/interchange_probe.py
```

The legacy workflow module has seven clauses, twelve snapshots, 84 complete
output comparisons and 91 individual checks. Its interfaces are separate from
the category-scoped chart module. Six selected RDF round trips pass and two
empty-named-graph-loss cases are rejected. These supplementary tests establish
neither the main integration claim nor full format conformance. Reports are
`results/native-validation.json` and `results/interchange.json`.

The vocabulary binding has 95 named PROV-O class/property identities and eight
selected P-Plan terms. `SOURCE_MANIFEST.json` identifies dependency snapshots.
`PROFILE_SPECIFICATION.md` states the supported contract and `CAPABILITIES.tsv`
distinguishes evidence from unimplemented work. RDF can already represent
classifiers as provenance subjects. No measured maintenance/performance advantage,
automatic capture, full PROV validity, standards adoption or complete runtime
integration is claimed. Existing technical filenames are retained.
