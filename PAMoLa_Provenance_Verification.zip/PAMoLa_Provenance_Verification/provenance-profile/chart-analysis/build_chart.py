#!/usr/bin/env python3
"""Construct native chart example and rules; verification is in verify_chart.py.

The tiny scalar FHAS writer follows ../tools/build_profile.py. No RDF package is
needed to construct or independently decode these bounded examples.
"""
from collections import OrderedDict
from pathlib import Path
import copy, csv, json, re, sys

HERE=Path(__file__).resolve().parent
PROFILE=HERE.parent
sys.path.insert(0,str(PROFILE/'reference-analysis'))
import reference_analysis as reference
BASE='Ordium.Profile.Provenance.ChartAnalysis'
EX='Ordium.ChartProvenanceExample'
REUSE='Ordium.ChartReuseExample'
PV='Ordium.Profile.Provenance.vocab.prov'

class Ref(str): pass
class Node:
    def __init__(self,badge,name,**props):
        self.badge=badge;self.props=OrderedDict(hasName=name,**props);self.children=[]
    def add(self,n):self.children.append(n);return n
    def render(self,depth=0):
        pad='  '*depth
        parts=[k+' '+(str(v) if isinstance(v,Ref) else json.dumps(v,ensure_ascii=False)) for k,v in self.props.items()]
        parts += [c.render(depth+1).lstrip() for c in self.children]
        return pad+self.badge+' {'+(',\n'+pad+'  ').join(parts)+'}'

def fact(parent,name,pred,values,path):
    n=parent.add(Node('AO',name,hasPredicate=Ref(pred)))
    for i,v in enumerate(values,1):
        p={'bindsTo':Ref(v),'fills':Ref(pred+'.'+('subject' if i==1 else 'object') if pred.startswith(PV) else pred+'.P'+str(i))}
        if i>1:p['follows']=Ref(path+'.'+name+'.AG_'+str(i-1))
        n.add(Node('AG','AG_'+str(i),**p))

def build():
    rules=reference.parse_rules(HERE/'rules.dl')
    root=Node('EN','ChartAnalysis',hasFQN=BASE,hasCustodian=Ref('Ordium.Profile.Provenance'),hasLinguisticType=Ref('Ordium.Core.Entity'),hasNote='Optional bounded entity-centred diagnostic module. Private analysis predicates are not new PROV vocabulary terms.')
    internal=root.add(Node('EN','internal'))
    arities={p:len(vs) for h,b in rules for p,vs in [h]+[a for _,a in b]}
    heads={h[0] for h,b in rules}
    rows=[]
    for p,arity in sorted(arities.items()):
        n=internal.add(Node('OM',p));fq=BASE+'.internal.'+p
        for i in range(1,arity+1):
            props={'hasType':Ref('Ordium')}
            if i>1:props['follows']=Ref(fq+'.P'+str(i-1))
            n.add(Node('PM','P'+str(i),**props))
        rows.append(dict(alias=p,owner_fqn=fq,arity=arity,role='derived' if p in heads else 'input'))
    with (HERE/'INTERFACES.tsv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['alias','owner_fqn','arity','role'],delimiter='\t');w.writeheader();w.writerows(rows)
    rc=root.add(Node('EN','rule'))
    projection=[]
    for i,(h,b) in enumerate(rules,1):
        rp=BASE+'.rule.R'+str(i)
        n=rc.add(Node('AO','R'+str(i),hasPredicate=Ref(BASE+'.internal.'+h[0])))
        variables=sorted({v for p,args in [h]+[a for _,a in b] for v in args})
        def arguments(parent,vs,path):
            for j,v in enumerate(vs,1):
                props={'bindsTo':Ref(rp+'.'+v),'fills':Ref(rp+'.'+v)}
                if j>1:props['follows']=Ref(path+'.AG_'+str(j-1))
                parent.add(Node('AG','AG_'+str(j),**props))
        arguments(n,h[1],rp)
        for j,(neg,(p,vs)) in enumerate(b,1):
            props={'hasPredicate':Ref(BASE+'.internal.'+p)}
            if j>1:props['follows']=Ref(rp+'.AO_'+str(j-1))
            if neg:props['isNegated']=Ref('true')
            child=n.add(Node('AO','AO_'+str(j),**props));arguments(child,vs,rp+'.AO_'+str(j))
        for v in variables:n.add(Node('PM',v,hasType=Ref('Ordium')))
        def fmt(a):return a[0]+'('+','.join('?'+v for v in a[1])+')'
        projection.append(fmt(h)+' :- '+', '.join(('not ' if neg else '')+fmt(a) for neg,a in b)+'.')
    (HERE/'Chart_Analysis_Profile.fhas').write_text(root.render()+'\n')
    (HERE/'Chart_Analysis_Profile.dl').write_text('\n'.join(projection)+'\n')
    ex=Node('EN','ChartProvenanceExample',hasFQN=EX,hasCustodian=Ref('Ordium'))
    typed={'StatisticalChartType':None,'SensitiveChartType':None,'CrimeRateChart_v1':'StatisticalChartType','CrimeRateChart_v2':'StatisticalChartType','chart1':'CrimeRateChart_v1','chart2':'CrimeRateChart_v1','chart3':'CrimeRateChart_v2'}
    for name in ('article1','article2','guideline1','guideline2','Alice','Chen','Derek','data1','data2','data3','plotting1','usage1','plottedData'):typed[name]=None
    for name,t in typed.items():
        p={'hasLinguisticType':Ref('Ordium.Core.Entity')}
        if t:p['hasDeclaredType']=Ref(EX+'.'+t)
        ex.add(Node('EN',name,**p))
    graph=ex.add(Node('EN','graph'))
    triples=[('wasAttributedTo','CrimeRateChart_v1','Alice'),('wasAttributedTo','CrimeRateChart_v2','Chen')]
    triples += [('wasAttributedTo',c,'Derek') for c in ('chart1','chart2','chart3')]
    triples += [('wasDerivedFrom','CrimeRateChart_v1','guideline1'),('wasDerivedFrom','CrimeRateChart_v2','guideline2')]
    triples += [('wasDerivedFrom','chart'+str(i),'data'+str(i)) for i in (1,2,3)]
    triples += [('wasDerivedFrom','article1','chart1'),('wasDerivedFrom','article2','chart3'),('wasRevisionOf','CrimeRateChart_v2','CrimeRateChart_v1'),('wasGeneratedBy','chart1','plotting1'),('qualifiedUsage','plotting1','usage1'),('entity','usage1','data1'),('hadRole','usage1','plottedData')]
    for i,(p,s,o) in enumerate(triples,1):fact(graph,'F'+str(i),PV+'.'+p,[EX+'.'+s,EX+'.'+o],EX+'.graph')
    contexts=ex.add(Node('EN','contexts'))
    for name,complete,approved in [('beforeWithdrawal',True,['CrimeRateChart_v1','CrimeRateChart_v2']),('afterWithdrawal',True,['CrimeRateChart_v2']),('incompleteRegistry',False,['CrimeRateChart_v2']),('newChartType',True,['CrimeRateChart_v2']),('recategorisedType',True,['CrimeRateChart_v1','CrimeRateChart_v2'])]:
        node=contexts.add(Node('EN',name));ctx=EX+'.contexts.'+name
        facts=[('requiresApproval',[ctx,EX+'.StatisticalChartType'])]
        if complete:facts.append(('completeApprovalRegistry',[ctx,EX+'.StatisticalChartType']))
        if name=='recategorisedType':
            facts += [('requiresApproval',[ctx,EX+'.SensitiveChartType']),('completeApprovalRegistry',[ctx,EX+'.SensitiveChartType'])]
        facts += [('approvedType',[ctx,EX+'.'+t,EX+'.StatisticalChartType']) for t in approved]
        for i,(pred,values) in enumerate(facts,1):fact(node,'F'+str(i),BASE+'.internal.'+pred,values,ctx)
    (HERE/'Chart_Provenance_Example.fhas').write_text(ex.render()+'\n')
    recategorised=copy.deepcopy(ex)
    for node in recategorised.children:
        if node.props['hasName']=='CrimeRateChart_v1':
            node.props['hasDeclaredType']=Ref(EX+'.SensitiveChartType')
    (HERE/'Chart_Recategorised_Example.fhas').write_text(recategorised.render()+'\n')
    reuse=Node('EN','ChartReuseExample',hasFQN=REUSE,hasCustodian=Ref('Ordium'))
    for n,t in [('BudgetChart_v1',EX+'.StatisticalChartType'),('chart4',REUSE+'.BudgetChart_v1'),('article3',None),('guideline3',None),('Elena',None)]:
        p={'hasLinguisticType':Ref('Ordium.Core.Entity')}
        if t:p['hasDeclaredType']=Ref(t)
        reuse.add(Node('EN',n,**p))
    rg=reuse.add(Node('EN','graph'))
    rt=[('wasAttributedTo','BudgetChart_v1','Elena'),('wasDerivedFrom','BudgetChart_v1','guideline3'),('wasDerivedFrom','article3','chart4')]
    for i,(p,s,o) in enumerate(rt,1):fact(rg,'F'+str(i),PV+'.'+p,[REUSE+'.'+s,REUSE+'.'+o],REUSE+'.graph')
    (HERE/'Chart_Reuse_Example.fhas').write_text(reuse.render()+'\n')
    ttl=['@prefix ex: <https://example.org/chart-provenance/> .','@prefix prov: <http://www.w3.org/ns/prov#> .','@prefix owl: <http://www.w3.org/2002/07/owl#> .','', '# PROV facts plus an explicit RDF/OWL view of native classification.', '# This RDF view can use legal OWL class/individual punning; the native model does not.']
    for n,t in typed.items():
        if t:ttl.append(f'ex:{n} a ex:{t} .')
    for n in ('StatisticalChartType','SensitiveChartType','CrimeRateChart_v1','CrimeRateChart_v2'):ttl.append(f'ex:{n} a owl:Class .')
    for n in typed:
        if n not in ('plotting1','usage1','plottedData'):
            ttl.append(f'ex:{n} a prov:'+('Agent' if n in ('Alice','Chen','Derek') else 'Entity')+' .')
    ttl += ['ex:plotting1 a prov:Activity .','ex:usage1 a prov:Usage .','ex:plottedData a prov:Role .']
    ttl += [f'ex:{s} prov:{p} ex:{o} .' for p,s,o in triples]
    (HERE/'chart-provenance.ttl').write_text('\n'.join(ttl)+'\n')
    print(json.dumps({'rules':len(rules),'interfaces':len(arities),'base_prov_facts':len(triples),'reuse_prov_facts':len(rt),'policy_contexts':5}))

if __name__=='__main__':build()
