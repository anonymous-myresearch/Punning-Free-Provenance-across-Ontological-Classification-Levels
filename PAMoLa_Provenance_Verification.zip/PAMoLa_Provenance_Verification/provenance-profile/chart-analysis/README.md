# Chart provenance analysis

This module adapts the newspaper/chart setting of the W3C PROV Primer. The
classifier-governance scenario is an extension of that example. Classifier
definitions, charts and their separately recorded provenance are native PAMoLa
elements. All histories are supplied facts; the analysis derives policy witnesses.

## Representation and input contract

StatisticalChartType classifies CrimeRateChart_v1 and CrimeRateChart_v2, which
classify chart1/chart2 and chart3 respectively. Each element has linguistic kind
Core.Entity. Revision is preserved separately from classification.

The classifier versions are attributed to Alice and Chen and derived from their
methodological guidelines. Charts are attributed to Derek and derived from data.
These facts are not propagated from a classifier onto its instances.

The six analysis inputs are:

- directType(C,X,T): the selected native hasDeclaredType relation.
- derived(C,X,S): recorded prov:wasDerivedFrom assertions.
- attributed(C,X,A): recorded prov:wasAttributedTo assertions.
- requiresApproval(C,K): the selected category requires approval.
- completeApprovalRegistry(C,K): complete evidence for that category and context.
- approvedType(C,T,K): approval is specific to context, classifier and category.

The extractor also preserves recorded revision, generation and qualification
facts for input-parity and source-preservation checks, without using entailment
closure. In particular, wasRevisionOf is not expanded into an additional
wasDerivedFrom fact. A different entailment regime needs a different input
contract and expected outputs.

## Five rules and their results

Chart_Analysis_Profile.fhas contains five native clauses and eleven private
interfaces. The interfaces are not additions to PROV.

| Result | Meaning |
|---|---|
| classifierProvenance(C,X,T,S,A) | Connect X through its classifier T to T's source S and attributed agent A. |
| reviewType(C,T,K) | Required approval for T under K is absent from a complete registry. |
| reviewEntity(C,X,T) | X directly instantiates a definition requiring review. |
| reviewPublication(C,P,X,T) | P has a recorded direct derivation from such X. |
| approvalUndetermined(C,T,K) | Required approval is missing and the relevant registry is not certified complete. |

The last result distinguishes insufficient evidence from an empty review set.
A positive approval prevents an undetermined result even when the registry is
incomplete. No rule interprets absence of review as proof of approval. A failed
retrieval is a separate processing outcome; the finite fixture evaluator does
not implement or test a live registry adapter.

Publication review follows one recorded derivation edge. The name does not
infer an additional publication type; the example's recorded consumers are
articles. Review outputs do not say that content is false or was invalid when
originally published.

## Five supplied snapshots

| Snapshot | Change and expected result |
|---|---|
| beforeWithdrawal | Both definitions have approval under StatisticalChartType; no review or undetermined witnesses. |
| afterWithdrawal | Only v2 remains approved; v1, chart1/chart2 and article1 require review. |
| incompleteRegistry | v2 remains approved, while v1 lacks approval and completeness; v1 has an explicit undetermined witness. |
| newChartType | BudgetChart_v1, chart4 and article3 are added; the unchanged rules also identify them for review. |
| recategorisedType | v1's sole declared category changes to SensitiveChartType. Its approval under StatisticalChartType remains recorded but does not satisfy the new category; v1 and its dependent charts/article require review. |

The recategorised snapshot uses Chart_Recategorised_Example.fhas, an alternative
classification snapshot with the same element names. It does not give v1 two
direct classifiers. Both category registries are complete there, and the old
approval cannot suppress review under the new category.

## Regeneration and verification

From the provenance-profile directory:

    python3 chart-analysis/build_chart.py
    python3 chart-analysis/verify_chart.py

The verifier does not import the builder. It parses written FHAS, resolves
references, decodes native rule occurrences, checks their textual projection and
evaluates the decoded clauses over extracted input views. fixtures.json states
complete expected outputs independently of the builder.

Verified results: five snapshots, 25 complete output-relation comparisons,
74 positive/negative fact checks and 54 preservation checks of nonempty input
relations. The results are in results/chart-validation.json. These are finite
reference checks, not execution in the official PAMoLa runtime.

## RDF view and independent baseline

chart-provenance.ttl is the base example's standard PROV/RDF view. It exposes
native declared typing through ordinary rdf:type. A compatible OWL DL view may
use legal punning; it does not acquire native OCA semantics merely from the RDF.

The chart-baseline directory independently implements all five questions using
ordinary asserted rdf:type, PROV predicates and category-scoped policy
properties. All 25 output sets and 55 input sets agree, comprising 32 returned
answer tuples. This is correctness parity, not an expressivity or performance
advantage claim.

The generic interchange probes elsewhere in the package are separate tests.
The chart rules do not detect the methodological ambiguity motivating approval
withdrawal, compute approval intervals, or implement a numerical chart check.
