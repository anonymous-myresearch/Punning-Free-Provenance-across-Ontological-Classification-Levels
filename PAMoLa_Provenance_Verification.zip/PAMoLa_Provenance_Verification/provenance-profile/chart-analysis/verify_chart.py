#!/usr/bin/env python3
"""Decode native FHAS rules and records independently, then evaluate each context.

No constructor/builder imports. Python standard library only. This is a finite
reference check, not execution in the authoritative PAMoLa runtime.
"""
from collections import defaultdict
from pathlib import Path
import hashlib, json, sys

HERE=Path(__file__).resolve().parent
PROFILE=HERE.parent
sys.path.insert(0,str(PROFILE/'tools'))
sys.path.insert(0,str(PROFILE/'reference-analysis'))
import fhas_reference as native
import reference_analysis as reference

BASE='Ordium.Profile.Provenance.ChartAnalysis'
EX='Ordium.ChartProvenanceExample'
PV='Ordium.Profile.Provenance.vocab.prov'
STANDARD_VIEWS={'wasDerivedFrom':'derived','wasAttributedTo':'attributed','wasRevisionOf':'revisionOf','wasGeneratedBy':'generatedBy','qualifiedUsage':'qualifiedUsage','entity':'usageEntity','hadRole':'usageRole'}

def tail(s):return s.rsplit('.',1)[-1]

def native_fact(node,all_nodes):
    p=node['props']['hasPredicate']
    args=native.ordered_children(node,'AG','AG')
    params=[c for c in all_nodes[p]['children'] if c['badge']=='PM']
    assert len(args)==len(params),(node['fqn'],'arity')
    values=[]
    for a,pm in zip(args,params):
        assert a['props']['fills']==pm['fqn'],(a['fqn'],'wrong parameter')
        values.append(a['props']['bindsTo'])
    return p,tuple(values)

def selected_inputs(nodes,context,all_nodes):
    facts=defaultdict(set)
    for fq,n in nodes.items():
        if 'hasDeclaredType' in n['props']:
            facts['directType'].add((context,tail(fq),tail(n['props']['hasDeclaredType'])))
        if n['badge']!='AO':continue
        p,values=native_fact(n,all_nodes)
        if p.startswith(PV+'.'):
            facts[STANDARD_VIEWS[tail(p)]].add((context,*(tail(v) for v in values)))
        elif p.startswith(BASE+'.internal.') and values[0]==EX+'.contexts.'+context:
            facts[tail(p)].add((context,*(tail(v) for v in values[1:])))
    return facts

def main():
    native.BASE=BASE
    module=native.read_fhas(HERE/'Chart_Analysis_Profile.fhas')
    base=native.read_fhas(HERE/'Chart_Provenance_Example.fhas')
    extra=native.read_fhas(HERE/'Chart_Reuse_Example.fhas')
    recategorised=native.read_fhas(HERE/'Chart_Recategorised_Example.fhas')
    all_nodes={}
    for p in sorted((PROFILE/'dependencies').glob('*.fhas')):all_nodes.update(native.read_fhas(p))
    all_nodes.update(native.read_fhas(PROFILE/'Provenance_Profile_Candidate.fhas'))
    all_nodes.update(module);all_nodes.update(base);all_nodes.update(extra);all_nodes.update(recategorised)
    refs=0
    for fqn,n in {**module,**base,**extra,**recategorised}.items():
        for key,value in n['props'].items():
            if key in native.REFERENCE_PROPERTIES|{'hasDeclaredType'}:
                assert value in all_nodes or value in {'true','false','Ordium.Profile'},(fqn,key,value)
                refs+=1
    aliases,owners=native.interface_table(HERE/'INTERFACES.tsv')
    decoded=native.decode_rules(module,owners,all_nodes)
    projected=native.parse_projection(HERE/'Chart_Analysis_Profile.dl')
    assert [(r.head,r.body) for r in decoded]==[(r.head,r.body) for r in projected]
    strata=native.safety_and_strata(decoded)
    def atom(a):
        assert all(t.kind=='variable' for t in a.args)
        return a.predicate,tuple(t.value for t in a.args)
    rules=[(atom(r.head),[(a.negated,atom(a)) for a in r.body]) for r in decoded]
    assert rules==reference.parse_rules(HERE/'rules.dl')
    fixture=json.loads((HERE/'fixtures.json').read_text())
    heads={r.head.predicate for r in decoded}
    assert heads==set(fixture['output_relations'])
    for name in ('StatisticalChartType','CrimeRateChart_v1','chart1'):
        assert base[EX+'.'+name]['props']['hasLinguisticType']=='Ordium.Core.Entity'
    results=[];comparisons=0;checks=0;preserved=0
    for case in fixture['cases']:
        nodes=native.read_fhas(HERE/case.get('native_source',fixture['base_native_source']))
        for p in case.get('additional_native_sources',[]):nodes.update(native.read_fhas(HERE/p))
        facts=selected_inputs(nodes,case['id'],all_nodes)
        protected={p:set(v) for p,v in facts.items()}
        reference.evaluate(rules,facts)
        for p,rows in protected.items():assert facts[p]==rows,(case['id'],p,'input mutation');preserved+=1
        actual={p:sorted([list(r[1:]) for r in facts[p]]) for p in fixture['output_relations']}
        for p in fixture['output_relations']:
            assert actual[p]==sorted(case['expected'][p]),(case['id'],p,actual[p],case['expected'][p]);comparisons+=1
        for check in fixture['checks_each_context']+case.get('checks',[]):
            p,*v=check['fact'];assert ((case['id'],*v) in facts[p])==check['present'],(case['id'],check);checks+=1
        results.append({'id':case['id'],'outputs':actual,'all_facts':reference.serialise(facts)})
    summary={'scope':'Independent native FHAS decoding and finite reference evaluation; not authoritative PAMoLa runtime execution',
      'module_nodes':len(module),'base_example_nodes':len(base),'reuse_example_nodes':len(extra),'recategorised_example_nodes':len(recategorised),'resolved_references':refs,
      'rule_clauses':len(rules),'interfaces':len(aliases),'max_stratum':max(strata.values()),'fixture_snapshots':len(results),
      'complete_output_relation_comparisons':comparisons,'explicit_fact_checks':checks,'complete_input_relation_preservation_checks':preserved,
      'rules_sha256':hashlib.sha256((HERE/'rules.dl').read_bytes()).hexdigest(),'failures':[],'cases':results}
    (HERE/'results').mkdir(exist_ok=True)
    (HERE/'results/chart-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='cases'},indent=2))

if __name__=='__main__':main()
