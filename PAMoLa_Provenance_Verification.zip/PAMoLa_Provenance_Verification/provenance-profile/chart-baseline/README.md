# RDF/SPARQL baseline for chart provenance

This independent implementation answers the five finite questions used by the
native chart analysis. It uses ordinary RDF datasets and SPARQL SELECT. It does
not decode FHAS or execute the native Datalog rules.

## Execute

With Python 3 and RDFLib 7.1.4 installed:

    python3 run_baseline.py

After running the native chart verifier:

    python3 compare_native.py

The runner constructs five named-graph snapshots and compares every query result
against independently stated complete expected tuples. Queries leave source
statements unchanged. snapshots.trig contains the reproducible RDF input.

Verified results: five queries over five contexts, 25 complete output comparisons,
32 answer tuples, and no failures. Exact native parity also checks 55 input sets,
including empty relations, and records the native report's digest.

## Standard and application relations

Classification uses ordinary rdf:type assertions selected from the authored
snapshot. No private directType RDF predicate is needed. The contract uses those
asserted type triples without RDFS or OWL entailment closure, matching the native
direct-classification input. Neither output parity nor the use of a selected
input view establishes an expressivity advantage for PAMoLa.

PROV attribution, derivation and revision retain their ordinary identities.
Three application predicates describe policy:

- requiresApproval: category to boolean true.
- completeApprovalRegistry: category to boolean true.
- approvedType: classifier to the category under which it is approved.

Each relation is scoped by its named graph. An approval for category K1 cannot
satisfy a requirement for category K2.

| Query | Output |
|---|---|
| classifier-provenance.rq | Entity, classifier, classifier source and attributed agent. |
| review-type.rq | Definition whose required category-specific approval is missing from a complete registry. |
| review-entity.rq | Directly classified entity affected by that review. |
| review-publication.rq | Directly derived consumer, with its supporting entity and classifier. |
| approval-undetermined.rq | Definition with missing approval and no completeness declaration for its category. |

## Scenarios

The original scenarios are beforeWithdrawal, afterWithdrawal, incompleteRegistry
and newChartType. They are supplied snapshots, not inferred temporal histories.
The incomplete registry now produces an explicit approvalUndetermined tuple for
v1; known approval for v2 prevents such a tuple.

The fifth scenario, recategorisedType, assigns v1 to SensitiveChartType while
retaining its prior approval under StatisticalChartType. Both category registries
are complete. The old approval does not silence review under the new category.
This scenario uses a single selected rdf:type classification for v1, not a
multi-classification assumption.

## Interpretation

FILTER NOT EXISTS for review is guarded by the completeness declaration for the
same category in the same graph. The undetermined query instead requires missing
approval and missing completeness. It reports insufficient evidence, not a
retrieval error. Failed retrieval remains a separate adapter/control outcome,
which these explicit datasets do not exercise.

SELECT DISTINCT yields set-valued outputs. Publication review follows one
recorded derivation edge. Revision does not create native classification or
specialisation, and attribution/derivation are not copied along classification.

RDF already permits resources to serve as classifiers and provenance subjects.
The baseline therefore treats identical results as expected correctness parity.
PAMoLa's possible benefit concerns obtaining the selected interpretation from an
authoritative native model. This baseline may itself consume a generated view;
it does not show that RDF inherently needs duplicated authorship or that PAMoLa
has measured maintenance, performance or expressivity superiority.
