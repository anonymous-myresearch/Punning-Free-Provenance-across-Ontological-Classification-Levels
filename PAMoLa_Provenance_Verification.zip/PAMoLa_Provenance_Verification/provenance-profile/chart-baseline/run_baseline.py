#!/usr/bin/env python3
"""An independent RDF/SPARQL implementation of the five chart questions.

Requires RDFLib 7.1.4. It constructs its own RDF dataset, executes stored SPARQL
queries, and compares complete result sets against explicit expected tuples.
This runner does not invoke PAMoLa, decode FHAS, or evaluate Datalog.
"""

import json
from pathlib import Path

import rdflib
from rdflib import Dataset, Literal, Namespace, RDF

HERE = Path(__file__).resolve().parent
EX = Namespace("https://example.org/provenance-chart/")
PROV = Namespace("http://www.w3.org/ns/prov#")
CONTEXTS = ("beforeWithdrawal", "afterWithdrawal", "incompleteRegistry", "newChartType", "recategorisedType")
QUERIES = {
    "classifierProvenance": "classifier-provenance.rq",
    "reviewType": "review-type.rq",
    "reviewEntity": "review-entity.rq",
    "reviewPublication": "review-publication.rq",
    "approvalUndetermined": "approval-undetermined.rq",
}
V1 = "CrimeRateChart_v1"
V2 = "CrimeRateChart_v2"
KIND = "StatisticalChartType"


def write_snapshot_dataset(dataset, path):
    """Preserve the canonical bytes when its named-graph facts are unchanged.

    RDFLib's pretty serializer orders triples by process-dependent iteration.
    Reproduction must not change a pinned input merely by reserialising it.
    New facts use a deterministic full-IRI TriG rendering.
    """
    if path.exists():
        existing = Dataset()
        existing.parse(path, format="trig")
        if set(existing.quads()) == set(dataset.quads()):
            return
    lines = []
    for context in sorted({q[3] for q in dataset.quads()}, key=str):
        lines.append(context.n3() + " {")
        triples = sorted(tuple(term.n3() for term in triple)
                         for triple in dataset.graph(context))
        lines.extend("    " + " ".join(triple) + " ." for triple in triples)
        lines.append("}\n")
    path.write_text("\n".join(lines) + "\n")


def make_dataset():
    dataset = Dataset()
    dataset.bind("ex", EX)
    dataset.bind("prov", PROV)
    dataset.bind("rdf", RDF)
    for context in CONTEXTS:
        graph = dataset.graph(EX[context])
        pairs = {
            "directType": [(V1, KIND), (V2, KIND), ("chart1", V1),
                           ("chart2", V1), ("chart3", V2)],
            "wasDerivedFrom": [(V1, "guideline1"), (V2, "guideline2"),
                               ("chart1", "data1"), ("chart2", "data2"),
                               ("chart3", "data3"), ("article1", "chart1"),
                               ("article2", "chart3")],
            "wasAttributedTo": [(V1, "Alice"), (V2, "Chen"),
                                ("chart1", "Derek"), ("chart2", "Derek"),
                                ("chart3", "Derek")],
            "wasRevisionOf": [(V2, V1)],
            "wasGeneratedBy": [("chart1", "plotting1")],
            "qualifiedUsage": [("plotting1", "usage1")],
            "entity": [("usage1", "data1")],
            "hadRole": [("usage1", "plottedData")],
        }
        if context == "recategorisedType":
            pairs["directType"][0] = (V1, "SensitiveChartType")
        if context == "newChartType":
            pairs["directType"] += [("BudgetChart_v1", KIND),
                                    ("chart4", "BudgetChart_v1")]
            pairs["wasDerivedFrom"] += [("BudgetChart_v1", "guideline3"),
                                        ("article3", "chart4")]
            pairs["wasAttributedTo"] += [("BudgetChart_v1", "Elena")]
        for predicate, assertions in pairs.items():
            iri = RDF.type if predicate == "directType" else PROV[predicate]
            for subject, obj in assertions:
                graph.add((EX[subject], iri, EX[obj]))
        graph.add((EX[KIND], EX.requiresApproval, Literal(True)))
        graph.add((EX[V2], EX.approvedType, EX[KIND]))
        if context != "incompleteRegistry":
            graph.add((EX[KIND], EX.completeApprovalRegistry, Literal(True)))
        if context in ("beforeWithdrawal", "recategorisedType"):
            graph.add((EX[V1], EX.approvedType, EX[KIND]))
        if context == "recategorisedType":
            graph.add((EX.SensitiveChartType, EX.requiresApproval, Literal(True)))
            graph.add((EX.SensitiveChartType, EX.completeApprovalRegistry, Literal(True)))
    return dataset


def expected_results():
    result = {}
    provenance = [
        ["chart1", V1, "guideline1", "Alice"],
        ["chart2", V1, "guideline1", "Alice"],
        ["chart3", V2, "guideline2", "Chen"],
    ]
    for context in CONTEXTS:
        result[context] = {name: [] for name in QUERIES}
        result[context]["classifierProvenance"] = [r[:] for r in provenance]
    for context in ("afterWithdrawal", "newChartType"):
        result[context]["reviewType"] = [[V1, KIND]]
        result[context]["reviewEntity"] = [["chart1", V1], ["chart2", V1]]
        result[context]["reviewPublication"] = [["article1", "chart1", V1]]
    extra = result["newChartType"]
    extra["classifierProvenance"].append(["chart4", "BudgetChart_v1", "guideline3", "Elena"])
    extra["reviewType"].append(["BudgetChart_v1", KIND])
    extra["reviewEntity"].append(["chart4", "BudgetChart_v1"])
    extra["reviewPublication"].append(["article3", "chart4", "BudgetChart_v1"])
    result["incompleteRegistry"]["approvalUndetermined"] = [[V1, KIND]]
    result["recategorisedType"]["reviewType"] = [[V1, "SensitiveChartType"]]
    result["recategorisedType"]["reviewEntity"] = [["chart1", V1], ["chart2", V1]]
    result["recategorisedType"]["reviewPublication"] = [["article1", "chart1", V1]]
    return result


def local_name(term):
    text = str(term)
    if not text.startswith(str(EX)):
        raise ValueError(f"Unexpected output term: {term}")
    return text[len(str(EX)):]


def main():
    dataset = make_dataset()
    before = set(dataset.quads((None, None, None, None)))
    actual = {context: {name: [] for name in QUERIES} for context in CONTEXTS}
    for name, filename in QUERIES.items():
        for row in dataset.query((HERE / filename).read_text()):
            values = [local_name(term) for term in row]
            actual[values[0]][name].append(values[1:])
    expected = expected_results()
    comparisons = []
    for context in CONTEXTS:
        for name in QUERIES:
            actual[context][name].sort()
            expected[context][name].sort()
            passed = actual[context][name] == expected[context][name]
            comparisons.append({"context": context, "query": name, "passed": passed})
    unchanged = before == set(dataset.quads((None, None, None, None)))
    failures = [x for x in comparisons if not x["passed"]]
    if not unchanged:
        failures.append({"source_dataset_unchanged": False})
    result = {
        "implementation": f"RDFLib {rdflib.__version__} SPARQL SELECT",
        "contexts": len(CONTEXTS),
        "queries": len(QUERIES),
        "complete_result_comparisons": len(comparisons),
        "returned_rows": sum(len(rows) for relations in actual.values() for rows in relations.values()),
        "source_dataset_unchanged": unchanged,
        "failures": failures,
        "comparisons": comparisons,
        "results": actual,
        "scope": "Finite explicit RDF snapshots and five application-policy queries; not an expressivity or performance advantage claim for PAMoLa.",
    }
    write_snapshot_dataset(dataset, HERE / "snapshots.trig")
    (HERE / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key not in ("results", "comparisons")}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
