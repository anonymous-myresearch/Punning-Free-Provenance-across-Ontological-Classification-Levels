#!/usr/bin/env python3
"""Compare independently computed SPARQL and decoded-native chart answers."""

import hashlib
import json
from pathlib import Path

from rdflib import Literal, RDF
from run_baseline import CONTEXTS, EX, PROV, QUERIES, local_name, make_dataset, main

HERE = Path(__file__).resolve().parent
main()
native_path = HERE.parent / "chart-analysis" / "results" / "chart-validation.json"
native = json.loads(native_path.read_text())
baseline = json.loads((HERE / "results.json").read_text())
if native["failures"] or baseline["failures"]:
    raise SystemExit("An implementation has reported a failure; refusing to claim parity.")
cases = {case["id"]: case for case in native["cases"]}
assert set(cases) == set(CONTEXTS)
comparisons = []
for context in CONTEXTS:
    for predicate in QUERIES:
        native_rows = sorted(cases[context]["outputs"][predicate])
        baseline_rows = sorted(baseline["results"][context][predicate])
        comparisons.append({"context": context, "relation": predicate,
                            "equal": native_rows == baseline_rows})

# Compare the independently authored input facts as well as their output.
# The two unary policy relations are encoded by boolean-valued RDF properties.
binary_mapping = {
    "directType": RDF.type,
    "approvedType": EX.approvedType,
    "derived": PROV.wasDerivedFrom,
    "attributed": PROV.wasAttributedTo,
    "revisionOf": PROV.wasRevisionOf,
    "generatedBy": PROV.wasGeneratedBy,
    "qualifiedUsage": PROV.qualifiedUsage,
    "usageEntity": PROV.entity,
    "usageRole": PROV.hadRole,
}
unary_mapping = {name: EX[name] for name in (
    "requiresApproval", "completeApprovalRegistry")}
dataset = make_dataset()
input_comparisons = []
for context in CONTEXTS:
    graph = dataset.graph(EX[context])
    for relation, predicate in {**binary_mapping, **unary_mapping}.items():
        if relation in binary_mapping:
            baseline_rows = sorted([local_name(s), local_name(o)] for s, _, o in graph.triples((None, predicate, None)))
        else:
            baseline_rows = sorted([local_name(s)] for s in graph.subjects(predicate, Literal(True)))
        native_rows = sorted(row[1:] for row in cases[context]["all_facts"].get(relation, []))
        input_comparisons.append({"context": context, "relation": relation,
                                  "equal": native_rows == baseline_rows})
failures = [row for row in comparisons + input_comparisons if not row["equal"]]
report = {
    "scope": "Exact finite answer parity, with independently authored input facts also checked; no performance or expressivity-superiority conclusion.",
    "native_report": str(native_path.relative_to(HERE.parent)),
    "native_report_sha256": hashlib.sha256(native_path.read_bytes()).hexdigest(),
    "contexts": len(CONTEXTS),
    "complete_output_relation_comparisons": len(comparisons),
    "complete_input_relation_comparisons": len(input_comparisons),
    "answer_tuples": baseline["returned_rows"],
    "failures": failures,
    "output_comparisons": comparisons,
    "input_comparisons": input_comparisons,
}
(HERE / "native-parity.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k not in ("output_comparisons", "input_comparisons")}, indent=2))
if failures:
    raise SystemExit(1)
