# Direct OWLAPI/HermiT backend

This backend loads the supplied OWL ontology files with OWLAPI and invokes the
HermiT `OWLReasoner` API. Python only manages the subprocess and JSON files. It
does not construct an Owlready2 object model, rewrite axioms, remove annotations,
replace imports, infer expected answers, or implement OWL reasoning.

## Reproduction

Requirements: Python 3.10 or later and a Java 17 JDK/runtime containing
`jdk.compiler`. No Python dependencies are needed. `java` must be on `PATH`, or
`PROV_JAVA` can name its executable. The Java source is compiled into the system
temporary directory, keyed by its content and the bundled jar's checksum.

From `provenance-profile`:

```sh
python owl-reasoner/tools/reasoner_backend.py input.ofn manifest.json --output raw-result.json
python owl-reasoner/tools/reasoner_backend.py input.ofn manifest.json --prov-variant metadata_projection --output projection-result.json
python owl-reasoner/tools/test_backend.py
```

Python callers can place `owl-reasoner/tools` on `sys.path`, then call:

```python
from reasoner_backend import run_reasoner
result = run_reasoner("input.ttl", manifest, output_path="raw-result.json", timeout=120)
projection = run_reasoner("input.ttl", manifest, prov_variant="metadata_projection")
```

The `manifest` argument can be a dictionary or JSON file path. Files can use
Functional Syntax, RDF/XML or Turtle as supported by the pinned OWLAPI parser.

## Manifest

All query identifiers are caller-supplied. Every IRI must be an absolute IRI.
The query manifest does not assert any facts and does not modify the ontology.

```json
{
  "task_timeout_ms": 60000,
  "entailments": [
    {"id":"q1", "kind":"subclass", "sub":"urn:example:Chart", "super":"urn:example:RequiresReview"},
    {"id":"q2", "kind":"class_assertion", "individual":"urn:example:chart1", "class":"urn:example:Chart"},
    {"id":"q3", "kind":"object_property_assertion", "subject":"urn:example:Chart", "property":"http://www.w3.org/ns/prov#wasAttributedTo", "object":"urn:example:Alice"},
    {"id":"q4", "kind":"data_property_assertion", "subject":"urn:example:Chart", "property":"urn:example:approved", "value":"true", "datatype":"http://www.w3.org/2001/XMLSchema#boolean"},
    {"id":"q5", "kind":"equivalent_classes", "left":"urn:example:A", "right":"urn:example:B"},
    {"id":"q6", "kind":"same_individual", "left":"urn:example:a", "right":"urn:example:b"}
  ],
  "satisfiability": [{"id":"s1", "class":"urn:example:Chart"}]
}
```

`different_individuals` and `disjoint_classes` also use `left` and `right`.
Data-property literals support `datatype` or `lang`; absent either, OWLAPI's
plain-string literal constructor is used.

## Results and failure semantics

`status` is `consistent` or `inconsistent` only when ontology loading and the
consistency check completed. `consistency.value` stores that Boolean.
Entailment queries have statuses `entailed`/`not_entailed` and `value` only when
HermiT answered them. Named-class checks have `satisfiable`/`unsatisfiable`.
For an inconsistent ontology, query status is `inconsistent_ontology` and no
Boolean is supplied: this harness does not present explosion as a useful answer.

Other statuses distinguish `import_failure`, `load_failure`,
`unsupported_construct`, `processing_failure`, `process_failure`,
`manifest_failure`, `timeout`, and `reasoner_warning`. Unknown query kinds are
reported as `unsupported_construct` in that query, with no false answer.
`query_execution_status` is `complete` or `partial_failure`. HermiT warnings are
captured explicitly and change the overall status to `reasoner_warning`.
Callers must inspect query statuses, not assume consistency means all queries
ran. A subprocess timeout never means non-entailment or approval.

`profiles.OWL2_DL` and `profiles.OWL2_RL` contain the OWLAPI profile reports for
the loaded import closure, including all reported violations. Profile
conformance is not inferred from a successful consistency or entailment check.
SWRL rules are counted explicitly; they are an extension outside the OWL 2
language, and no general SWRL completeness claim is made.

The exact pinned PROV-O Turtle import explicitly declares both
`prov:specializationOf` and `prov:wasRevisionOf` to be annotation properties as
well as object properties. The raw import therefore produces `IllegalPunning`
profile diagnostics. These diagnostics are retained; successful HermiT
reasoning does not turn that raw import into a conformant OWL 2 DL ontology.

For a separately labelled strict-DL control, `prov_variant="metadata_projection"`
selects `prov-o-metadata-projection.ttl`. Its reproducible generator removes
exactly two `rdf:type owl:AnnotationProperty` declarations, and no other RDF
triples. Both object-property declarations, all application schema, every
provenance assertion, and the ontology document's history are retained. The
original pinned source is untouched. The exact removals and both hashes are in
`metadata-projection-manifest.json`. This is an explicit input projection, not
a claim of RDF semantic equivalence. The raw and projected runs must be reported
separately; the default remains `raw`.

Rebuild with `python owl-reasoner/tools/build_metadata_projection.py`. Add
`--verify-rdf` when the artifact's pinned RDFLib dependency is installed to
reproduce the graph-isomorphism check: 1,146 source triples, 1,144 projected
triples, exactly the two declared removals, and no additions. The check's raw
report is `results/projection-rdf-diff.json`.

`results/modern-parser-comparison.json` records an independent cross-check with
ROBOT 1.9.8's OWLAPI 4.5.29 and HermiT library. It reproduces the raw profile
failure and the projection's zero DL violations. This comparison distribution
is not needed by the default backend, and its download URL and SHA-256 are
recorded for reproduction.

## Import policy

The standard PROV-O ontology/document/version IRIs listed in
`ReasonerHarness.java` map to the existing, unchanged
`dependencies/prov-o.ttl` by default (SHA-256 in `DEPENDENCIES.json`), or the
explicit projection when requested. Existing local file
imports are allowed. Every other import is mapped to a deliberately absent
local file and fails: no network import retrieval or silent missing import is
allowed. The import closure and axiom counts appear in every loaded result.

## Dependency pin and limitations

The jar is the unmodified `owlready2/hermit/HermiT.jar` from PyPI package
`owlready2==0.51`, used solely as a distribution source. It bundles HermiT
1.3.8.1099 and OWLAPI 3.4.3; this is an older implementation and its parser and
profile diagnostics are part of the experimental configuration. Neither the
Owlready2 Python library nor its ontology-object mapping is used. Checksums,
package origin, component versions and notices are recorded alongside the jar.
The raw result records measured runtime, execution timestamp, Java/Python
versions, input/manifest/import hashes and process exit code. No timing or
result is generated from a predeclared oracle.
