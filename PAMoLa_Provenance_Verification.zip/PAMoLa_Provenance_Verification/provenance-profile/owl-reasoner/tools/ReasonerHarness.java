import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.io.FileDocumentSource;
import org.semanticweb.owlapi.model.*;
import org.semanticweb.owlapi.profiles.*;
import org.semanticweb.owlapi.reasoner.*;
import org.semanticweb.HermiT.Configuration;
import org.semanticweb.HermiT.Reasoner;

/** Direct OWLAPI/HermiT file harness: no Python ontology/object mapping. */
public final class ReasonerHarness {
  static Map<String,Object> obj(Object... kv) {
    Map<String,Object> m=new LinkedHashMap<>();
    for(int i=0;i<kv.length;i+=2)m.put((String)kv[i],kv[i+1]); return m;
  }
  static String req(Map<String,Object> m,String k) {
    Object v=m.get(k); if(!(v instanceof String)||((String)v).isEmpty())
      throw new IllegalArgumentException("Missing/non-string field: "+k); return (String)v;
  }
  static OWLClass cls(OWLDataFactory f,String iri){return f.getOWLClass(IRI.create(iri));}
  static OWLNamedIndividual ind(OWLDataFactory f,String iri){return f.getOWLNamedIndividual(IRI.create(iri));}
  static OWLAxiom query(OWLDataFactory f,Map<String,Object> q) {
    switch(req(q,"kind")) {
      case "subclass": return f.getOWLSubClassOfAxiom(cls(f,req(q,"sub")),cls(f,req(q,"super")));
      case "equivalent_classes": return f.getOWLEquivalentClassesAxiom(cls(f,req(q,"left")),cls(f,req(q,"right")));
      case "class_assertion": return f.getOWLClassAssertionAxiom(cls(f,req(q,"class")),ind(f,req(q,"individual")));
      case "object_property_assertion": return f.getOWLObjectPropertyAssertionAxiom(f.getOWLObjectProperty(IRI.create(req(q,"property"))),ind(f,req(q,"subject")),ind(f,req(q,"object")));
      case "data_property_assertion": {
        OWLLiteral lit;
        if(q.containsKey("lang"))lit=f.getOWLLiteral(req(q,"value"),req(q,"lang"));
        else if(q.containsKey("datatype"))lit=f.getOWLLiteral(req(q,"value"),f.getOWLDatatype(IRI.create(req(q,"datatype"))));
        else lit=f.getOWLLiteral(req(q,"value"));
        return f.getOWLDataPropertyAssertionAxiom(f.getOWLDataProperty(IRI.create(req(q,"property"))),ind(f,req(q,"subject")),lit);
      }
      case "same_individual": return f.getOWLSameIndividualAxiom(ind(f,req(q,"left")),ind(f,req(q,"right")));
      case "different_individuals": return f.getOWLDifferentIndividualsAxiom(ind(f,req(q,"left")),ind(f,req(q,"right")));
      case "disjoint_classes": return f.getOWLDisjointClassesAxiom(cls(f,req(q,"left")),cls(f,req(q,"right")));
      default: throw new UnsupportedOperationException("Unsupported query kind: "+q.get("kind"));
    }
  }
  static Map<String,Object> profile(OWLProfile p,OWLOntology o) {
    OWLProfileReport r=p.checkOntology(o); List<Object> vs=new ArrayList<>();
    for(OWLProfileViolation v:r.getViolations())vs.add(obj("type",v.getClass().getSimpleName(),"message",v.toString()));
    vs.sort(Comparator.comparing(Json::write));
    return obj("in_profile",r.isInProfile(),"violation_count",vs.size(),"violations",vs);
  }
  static String errorKind(Throwable t) {
    if(t instanceof UnloadableImportException)return "import_failure";
    if(t instanceof UnsupportedOperationException || t instanceof UnsupportedEntailmentTypeException)return "unsupported_construct";
    if(t instanceof IllegalArgumentException)return "unsupported_construct";
    if(t instanceof TimeOutException)return "timeout";
    return "processing_failure";
  }
  @SuppressWarnings("unchecked") public static void main(String[] args) throws Exception {
    long start=System.nanoTime(); Map<String,Object> out=obj("schema_version",1,"status","processing_failure");
    List<String> blocked=new ArrayList<>(),warnings=new ArrayList<>(); Reasoner reasoner=null;
    try {
      if(args.length!=3)throw new IllegalArgumentException("Usage: ReasonerHarness ontology-file manifest.json local-prov-o.ttl");
      Map<String,Object> manifest=(Map<String,Object>)Json.parse(Files.readString(Path.of(args[1])));
      File source=new File(args[0]).getCanonicalFile(),prov=new File(args[2]).getCanonicalFile();
      if(!source.isFile()||!prov.isFile())throw new FileNotFoundException("Input ontology or pinned PROV-O not found");
      Set<String> provIRIs=new HashSet<>(Arrays.asList("http://www.w3.org/ns/prov-o","http://www.w3.org/ns/prov-o#","http://www.w3.org/ns/prov-o/","http://www.w3.org/ns/prov-o.ttl","https://www.w3.org/ns/prov-o","https://www.w3.org/ns/prov-o#","https://www.w3.org/ns/prov-o/","https://www.w3.org/ns/prov-o.ttl","http://www.w3.org/ns/prov-o-20130430","http://www.w3.org/ns/prov-o-20130430#"));
      OWLOntologyManager manager=OWLManager.createOWLOntologyManager();
      manager.addIRIMapper(ontologyIRI -> {
        String s=ontologyIRI.toString();
        if(provIRIs.contains(s))return IRI.create(prov);
        if(s.startsWith("file:"))return ontologyIRI;
        blocked.add(s); return IRI.create(new File(source.getParentFile(),"__unmapped_import_must_fail__.owl"));
      });
      OWLOntologyLoaderConfiguration loader=new OWLOntologyLoaderConfiguration().setMissingImportHandlingStrategy(MissingImportHandlingStrategy.THROW_EXCEPTION);
      OWLOntology ontology;
      try {ontology=manager.loadOntologyFromOntologyDocument(new FileDocumentSource(source),loader);}
      catch(Throwable t){out.put("status",(!blocked.isEmpty()||t instanceof UnloadableImportException)?"import_failure":"load_failure"); throw t;}
      List<Object> imports=new ArrayList<>(); int swrl=0;
      for(OWLOntology o:manager.getImportsClosure(ontology)) {
        imports.add(obj("ontology_iri",o.getOntologyID().toString(),"axiom_count",o.getAxiomCount()));
        swrl+=o.getAxioms(AxiomType.SWRL_RULE).size();
      }
      imports.sort(Comparator.comparing(Json::write));
      out.put("imports_closure",imports); out.put("swrl_rule_count",swrl);
      out.put("profiles",obj("OWL2_DL",profile(new OWL2DLProfile(),ontology),"OWL2_RL",profile(new OWL2RLProfile(),ontology)));
      Configuration config=new Configuration(); config.ignoreUnsupportedDatatypes=false;
      config.warningMonitor=warnings::add;
      config.individualTaskTimeout=((Number)manifest.getOrDefault("task_timeout_ms",60000)).longValue();
      config.freshEntityPolicy=FreshEntityPolicy.ALLOW;
      reasoner=new Reasoner(config,ontology);
      org.semanticweb.owlapi.util.Version rv=reasoner.getReasonerVersion();
      out.put("reasoner",obj("name",reasoner.getReasonerName(),"version",rv.getMajor()+"."+rv.getMinor()+"."+rv.getPatch()+"."+rv.getBuild()));
      boolean consistent=reasoner.isConsistent();
      out.put("consistency",obj("status",consistent?"consistent":"inconsistent","value",consistent));
      List<Object> answers=new ArrayList<>();
      for(Object raw:(List<Object>)manifest.getOrDefault("entailments",Collections.emptyList())) {
        Map<String,Object> q=(Map<String,Object>)raw; Map<String,Object> a=obj("id",req(q,"id"),"kind",req(q,"kind"));
        if(!consistent)a.put("status","inconsistent_ontology");
        else try {OWLAxiom ax=query(manager.getOWLDataFactory(),q); boolean v=reasoner.isEntailed(ax); a.put("status",v?"entailed":"not_entailed"); a.put("value",v);}
        catch(Throwable t){a.put("status",errorKind(t));a.put("error",t.toString());}
        answers.add(a);
      }
      out.put("entailments",answers); List<Object> sat=new ArrayList<>();
      for(Object raw:(List<Object>)manifest.getOrDefault("satisfiability",Collections.emptyList())) {
        Map<String,Object> q=(Map<String,Object>)raw; Map<String,Object> a=obj("id",req(q,"id"),"class",req(q,"class"));
        if(!consistent)a.put("status","inconsistent_ontology");
        else try {boolean v=reasoner.isSatisfiable(cls(manager.getOWLDataFactory(),req(q,"class")));a.put("status",v?"satisfiable":"unsatisfiable");a.put("value",v);}
        catch(Throwable t){a.put("status",errorKind(t));a.put("error",t.toString());}
        sat.add(a);
      }
      out.put("satisfiability",sat); out.put("status",consistent?"consistent":"inconsistent");
      boolean failed=false;for(Object a:answers)if(!((Map<?,?>)a).containsKey("value")&&consistent)failed=true;
      for(Object a:sat)if(!((Map<?,?>)a).containsKey("value")&&consistent)failed=true;
      out.put("query_execution_status",failed?"partial_failure":"complete");
      if(!warnings.isEmpty())out.put("status","reasoner_warning");
    } catch(Throwable t) {
      if(out.get("status").equals("processing_failure"))out.put("status",errorKind(t));
      out.put("error",obj("type",t.getClass().getName(),"message",String.valueOf(t.getMessage())));
    } finally {
      if(reasoner!=null)reasoner.dispose();
      out.put("blocked_imports",blocked);out.put("reasoner_warnings",warnings);out.put("elapsed_ms",(System.nanoTime()-start)/1000000.0);
      System.out.println(Json.write(out));
    }
  }
  /** Small dependency-free JSON reader/writer for the documented manifest. */
  static final class Json {
    String s;int i;Json(String s){this.s=s;}
    static Object parse(String s){Json p=new Json(s);Object v=p.value();p.ws();if(p.i!=s.length())throw new IllegalArgumentException("Trailing JSON");return v;}
    void ws(){while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;}
    char take(){return s.charAt(i++);}void need(char c){ws();if(take()!=c)throw new IllegalArgumentException("Expected "+c);}
    Object value(){ws();char c=s.charAt(i);if(c=='{'){i++;Map<String,Object> m=new LinkedHashMap<>();ws();if(s.charAt(i)=='}'){i++;return m;}do{String k=str();need(':');m.put(k,value());ws();c=take();if(c=='}')return m;if(c!=',')throw new IllegalArgumentException("Expected comma");}while(true);}if(c=='['){i++;List<Object>a=new ArrayList<>();ws();if(s.charAt(i)==']'){i++;return a;}do{a.add(value());ws();c=take();if(c==']')return a;if(c!=',')throw new IllegalArgumentException("Expected comma");}while(true);}if(c=='"')return str();for(String k:new String[]{"true","false","null"})if(s.startsWith(k,i)){i+=k.length();return k.equals("null")?null:Boolean.valueOf(k);}int b=i;while(i<s.length()&&"-+0123456789.eE".indexOf(s.charAt(i))>=0)i++;if(i==b)throw new IllegalArgumentException("Invalid JSON value");return Double.valueOf(s.substring(b,i));}
    String str(){ws();if(take()!='"')throw new IllegalArgumentException("Expected string");StringBuilder b=new StringBuilder();while(true){char c=take();if(c=='"')return b.toString();if(c=='\\'){c=take();switch(c){case 'u':b.append((char)Integer.parseInt(s.substring(i,i+4),16));i+=4;break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;default:b.append(c);}}else b.append(c);}}
    static String write(Object v){if(v==null)return "null";if(v instanceof String){StringBuilder b=new StringBuilder("\"");for(char c:((String)v).toCharArray()){switch(c){case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default:if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);}}return b.append('"').toString();}if(v instanceof Map){List<String>a=new ArrayList<>();for(Object e0:((Map<?,?>)v).entrySet()){Map.Entry<?,?>e=(Map.Entry<?,?>)e0;a.add(write(e.getKey())+":"+write(e.getValue()));}return "{"+String.join(",",a)+"}";}if(v instanceof Iterable){List<String>a=new ArrayList<>();for(Object x:(Iterable<?>)v)a.add(write(x));return "["+String.join(",",a)+"]";}return v.toString();}
  }
}
