#!/usr/bin/env python3
"""Minimal genuine engine and error-path checks; not the study controls."""
import json
from pathlib import Path
import tempfile
from reasoner_backend import run_reasoner

BACKEND = Path(__file__).resolve().parent.parent / "backend"

def main():
    results = {}
    with tempfile.TemporaryDirectory(prefix="provenance-hermit-smoke-") as temp:
        root = Path(temp)
        def check(name, ontology, manifest):
            path = root / (name + ".ofn")
            path.write_text(ontology)
            result = run_reasoner(path, manifest)
            results[name] = result
            return result
        common = "Prefix(:=<urn:backend:>) Prefix(prov:=<http://www.w3.org/ns/prov#>)\n"
        punned = check("punned", common + '''Ontology(<urn:backend:punned>
          Import(<http://www.w3.org/ns/prov-o>)
          Declaration(Class(:T)) Declaration(NamedIndividual(:T))
          Declaration(Class(:K)) Declaration(NamedIndividual(:x)) Declaration(NamedIndividual(:a))
          SubClassOf(:T :K) ClassAssertion(:T :x)
          ObjectPropertyAssertion(prov:wasAttributedTo :T :a))''', {
            "entailments": [
                {"id":"subclass", "kind":"subclass", "sub":"urn:backend:T", "super":"urn:backend:K"},
                {"id":"membership", "kind":"class_assertion", "individual":"urn:backend:x", "class":"urn:backend:K"},
                {"id":"classifier_attribution", "kind":"object_property_assertion", "subject":"urn:backend:T", "property":"http://www.w3.org/ns/prov#wasAttributedTo", "object":"urn:backend:a"},
                {"id":"instance_attribution", "kind":"object_property_assertion", "subject":"urn:backend:x", "property":"http://www.w3.org/ns/prov#wasAttributedTo", "object":"urn:backend:a"}],
            "satisfiability":[{"id":"sT", "class":"urn:backend:T"}]})
        assert punned["status"] == "consistent", punned
        assert [q["value"] for q in punned["entailments"]] == [True, True, True, False]
        assert punned["satisfiability"][0]["value"] is True
        assert len(punned["imports_closure"]) == 2
        normalized = run_reasoner(root / "punned.ofn", {
            "entailments":[{"id":"instance_attribution", "kind":"object_property_assertion", "subject":"urn:backend:x", "property":"http://www.w3.org/ns/prov#wasAttributedTo", "object":"urn:backend:a"}]}, prov_variant="metadata_projection")
        results["punned_metadata_projection"] = normalized
        assert normalized["status"] == "consistent", normalized
        assert normalized["profiles"]["OWL2_DL"]["in_profile"] is True
        assert normalized["profiles"]["OWL2_DL"]["violation_count"] == 0
        assert normalized["entailments"][0]["value"] is False
        # A class can be unsatisfiable while its ontology remains consistent.
        unsat = check("unsatisfiable_class", common + "Ontology(Declaration(Class(:Empty)) SubClassOf(:Empty owl:Nothing))", {"satisfiability":[{"id":"empty", "class":"urn:backend:Empty"}]})
        assert unsat["status"] == "consistent", unsat
        assert unsat["satisfiability"][0]["status"] == "unsatisfiable"
        inconsistent = check("inconsistent", common + "Ontology(Declaration(Class(:A)) Declaration(Class(:B)) Declaration(NamedIndividual(:x)) DisjointClasses(:A :B) ClassAssertion(:A :x) ClassAssertion(:B :x))", {"entailments":[{"id":"q", "kind":"class_assertion", "individual":"urn:backend:x", "class":"urn:backend:A"}]})
        assert inconsistent["status"] == "inconsistent", inconsistent
        assert inconsistent["entailments"][0]["status"] == "inconsistent_ontology"
        assert "value" not in inconsistent["entailments"][0]
        missing = check("missing_import", "Ontology(Import(<https://example.invalid/must-not-fetch>))", {})
        assert missing["status"] == "import_failure", missing
        malformed = check("malformed", "NotAnOntology !", {})
        assert malformed["status"] == "load_failure", malformed
        unsupported = check("unsupported_query", common + "Ontology(Declaration(Class(:A)))", {"entailments":[{"id":"u", "kind":"arbitrary_query"}]})
        assert unsupported["query_execution_status"] == "partial_failure", unsupported
        assert unsupported["entailments"][0]["status"] == "unsupported_construct"
        assert "value" not in unsupported["entailments"][0]
    target = BACKEND / "results" / "smoke.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps({"passed":True, "cases":results}, indent=2, sort_keys=True) + "\n")
    print("PASS: seven direct-engine, punning, strict-DL projection and failure-path checks")

if __name__ == "__main__":
    main()
