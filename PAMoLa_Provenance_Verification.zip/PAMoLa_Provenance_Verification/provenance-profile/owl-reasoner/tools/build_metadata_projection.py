#!/usr/bin/env python3
"""Explicit two-declaration PROV-O metadata projection; source is untouched."""
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT.parent / "dependencies" / "prov-o.ttl"
TARGET = ROOT / "backend" / "prov-o-metadata-projection.ttl"
PIN = "7d203989f67b38bca572253942acc5a1bf24ce3ccfece16f072dcb4be2b79a96"
OLD = '    a owl:AnnotationProperty, owl:ObjectProperty ;'
NEW = '    a owl:ObjectProperty ;'

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-rdf", action="store_true", help="Check graph difference with the artifact's pinned RDFLib dependency")
    args = parser.parse_args()
    raw = SOURCE.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == PIN
    text = raw.decode()
    assert text.count(OLD) == 2
    projected = text.replace(OLD, NEW).encode()
    TARGET.write_bytes(projected)
    removed = [{"subject":"http://www.w3.org/ns/prov#"+p,
      "predicate":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type",
      "object":"http://www.w3.org/2002/07/owl#AnnotationProperty"}
      for p in ("specializationOf", "wasRevisionOf")]
    manifest = {"source":"../../dependencies/prov-o.ttl", "source_sha256":PIN,
      "projection":"prov-o-metadata-projection.ttl", "projection_sha256":hashlib.sha256(projected).hexdigest(),
      "removed_triples":removed, "added_triples":[], "source_unchanged":True,
      "scope":"Omit only two annotation-property role declarations that duplicate object-property roles. The corresponding object-property declarations, all application class/property axioms, every provenance assertion and the ontology's document-history statements are retained.",
      "semantic_caveat":"Not asserted to be RDF-semantically equivalent to the source: the two annotation-property declarations are intentionally omitted. The strict OWL 2 DL input has object-property roles for these IRIs, and no annotation-property roles for them."}
    (ROOT / "backend" / "metadata-projection-manifest.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
    if args.verify_rdf:
        import rdflib
        from rdflib.compare import graph_diff, to_isomorphic
        source_graph = rdflib.Graph().parse(SOURCE, format="turtle")
        projection_graph = rdflib.Graph().parse(TARGET, format="turtle")
        common, removed_graph, added_graph = graph_diff(to_isomorphic(source_graph), to_isomorphic(projection_graph))
        expected = {(x["subject"], x["predicate"], x["object"]) for x in removed}
        actual = {tuple(map(str,x)) for x in removed_graph}
        assert actual == expected and len(added_graph) == 0
        report = {"source_triples":len(source_graph), "projection_triples":len(projection_graph),
          "common_triples":len(common), "removed_triples":sorted(map(list, actual)), "added_triples":[],
          "rdflib_version":rdflib.__version__,
          "method":"RDFLib graph_diff over isomorphism-normalized graphs (blank-node IDs excluded from comparison)"}
        (ROOT / "backend" / "results").mkdir(exist_ok=True)
        (ROOT / "backend" / "results" / "projection-rdf-diff.json").write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
    print("Wrote explicit two-declaration metadata projection; pinned source unchanged")

if __name__ == "__main__":
    main()
