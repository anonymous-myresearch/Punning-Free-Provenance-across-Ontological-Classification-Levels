#!/usr/bin/env python3
"""Pinned direct OWLAPI/HermiT subprocess API. Python never maps OWL objects."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import tempfile
import time

TOOLS = Path(__file__).resolve().parent
PROFILE = TOOLS.parent.parent
JAR = TOOLS.parent / "backend" / "lib" / "HermiT.jar"
PINNED_JAR_SHA256 = "97e53f519720a0a2e328556e03b806aa239347c85e57637a935e6433ed2ad3a8"
PROV = PROFILE / "dependencies" / "prov-o.ttl"
SOURCE = TOOLS / "ReasonerHarness.java"

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def _compiled(java: str, timeout: float) -> Path:
    if sha256(JAR) != PINNED_JAR_SHA256:
        raise RuntimeError("Bundled HermiT.jar differs from the pinned SHA-256")
    key = hashlib.sha256(SOURCE.read_bytes() + PINNED_JAR_SHA256.encode()).hexdigest()[:20]
    build = Path(tempfile.gettempdir()) / ("provenance-hermit-" + key)
    build.mkdir(parents=True, exist_ok=True)
    if not (build / "ReasonerHarness.class").is_file():
        # The runtime image here has jdk.compiler but no javac launcher. This is
        # the standard JDK compiler entry point, with identical classpath input.
        command = [java, "com.sun.tools.javac.Main", "-encoding", "UTF-8", "-cp", str(JAR), "-d", str(build), str(SOURCE)]
        p = subprocess.run(command, text=True, capture_output=True, timeout=timeout)
        if p.returncode:
            raise RuntimeError("Java harness compilation failed: " + p.stderr + p.stdout)
    return build

def run_reasoner(ontology_path, manifest, output_path=None, *, timeout=120, java=None, prov_variant="raw"):
    """Return JSON-compatible raw results, never promote failed work to false.

    ``manifest`` is a dict or path to its JSON serialization. See backend/README.
    ``timeout`` is a wall-clock subprocess limit, independent of HermiT's
    manifest ``task_timeout_ms``. Failure results carry status and diagnostics.
    """
    started = time.monotonic()
    stamp = datetime.now(timezone.utc).isoformat()
    ontology = Path(ontology_path).resolve()
    java = java or os.environ.get("PROV_JAVA", "java")
    result = {"schema_version": 1, "status": "processing_failure"}
    runtime = {"started_utc": stamp, "python": platform.python_version(),
               "platform": platform.platform(), "method": "direct OWLAPI ontology-file loading and HermiT OWLReasoner calls",
               "hermit_jar_sha256": PINNED_JAR_SHA256}
    try:
        if not isinstance(manifest, dict):
            manifest = json.loads(Path(manifest).read_text())
        if not isinstance(manifest, dict):
            raise ValueError("Manifest must be a JSON object")
        for field in ("entailments", "satisfiability"):
            if not isinstance(manifest.get(field, []), list):
                raise ValueError(field + " must be an array")
        encoded = json.dumps(manifest, sort_keys=True, ensure_ascii=False).encode()
        runtime["manifest_sha256"] = hashlib.sha256(encoded).hexdigest()
        runtime["ontology_sha256"] = sha256(ontology)
        if prov_variant not in {"raw", "metadata_projection"}:
            raise ValueError("prov_variant must be raw or metadata_projection")
        prov = PROV if prov_variant == "raw" else TOOLS.parent / "backend" / "prov-o-metadata-projection.ttl"
        runtime["prov_o_sha256"] = sha256(prov)
        runtime["prov_import_variant"] = prov_variant
        version = subprocess.run([java, "-version"], text=True, capture_output=True, timeout=10)
        if version.returncode:
            raise RuntimeError("Java version check failed: " + version.stderr)
        runtime["java_version"] = (version.stderr + version.stdout).strip()
        build = _compiled(java, min(timeout, 60))
        with tempfile.TemporaryDirectory(prefix="provenance-hermit-query-") as tmp:
            mpath = Path(tmp) / "manifest.json"
            mpath.write_bytes(encoded)
            command = [java, "-Xmx1g", "-cp", os.pathsep.join((str(build), str(JAR))),
                       "ReasonerHarness", str(ontology), str(mpath), str(prov)]
            p = subprocess.run(command, text=True, capture_output=True, timeout=timeout)
            runtime["process_exit_code"] = p.returncode
            if p.returncode != 0:
                result.update(status="process_failure", error={"type": "NonzeroExit", "message": p.stderr[-12000:]}, stdout=p.stdout[-12000:])
            else:
                try:
                    result = json.loads(p.stdout)
                except json.JSONDecodeError:
                    result.update(status="process_failure", error={"type": "InvalidHarnessOutput", "message": p.stdout[-12000:]})
                if p.stderr.strip():
                    result["stderr"] = p.stderr[-12000:]
    except subprocess.TimeoutExpired as e:
        result.update(status="timeout", error={"type": type(e).__name__, "message": "Subprocess exceeded wall-clock limit"})
    except (ValueError, json.JSONDecodeError) as e:
        result.update(status="manifest_failure", error={"type": type(e).__name__, "message": str(e)})
    except Exception as e:
        result.update(status="process_failure", error={"type": type(e).__name__, "message": str(e)})
    runtime["wall_ms"] = round((time.monotonic() - started) * 1000, 3)
    result["runtime"] = runtime
    if output_path:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_path).write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    return result

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("ontology")
    p.add_argument("manifest")
    p.add_argument("--output")
    p.add_argument("--timeout", type=float, default=120)
    p.add_argument("--prov-variant", choices=("raw", "metadata_projection"), default="raw")
    a = p.parse_args()
    result = run_reasoner(a.ontology, a.manifest, a.output, timeout=a.timeout, prov_variant=a.prov_variant)
    if not a.output:
        print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if (result["status"] in {"consistent", "inconsistent"}
                 and result.get("query_execution_status") == "complete") else 1

if __name__ == "__main__":
    raise SystemExit(main())
