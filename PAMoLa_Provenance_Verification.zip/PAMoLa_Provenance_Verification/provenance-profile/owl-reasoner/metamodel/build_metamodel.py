#!/usr/bin/env python3
"""E4/E5: the Glimm--Rudolph--Voelker (ISWC 2010) metamodelling encoding applied
to the unchanged canonical chart snapshots, plus the flattening mutations of E2
under that encoding and under explicit level controls.

This builder writes OWL inputs, query manifests and *predeclared* expected
answers. It never calls a reasoner and never reads reasoner output. Every
difference from the canonical graph is listed in source_manifest.json.

Construction (Glimm, Rudolph, Voelker, Def. 4 and O_meta = bound(O) u SepDom(O)
u Typing(O) u MatSubClass(O)), applied to the application module only; PROV-O is
imported unchanged through the shared backend (raw or metadata projection):

  fresh classes   Inst, Class;  fresh roles  type, subClassOf, RInst;
  one fresh individual o_C per transformed class C.
  SepDom:   Inst == not Class;  Class(o_C);  Inst(i) for named individuals i;
            for every separated role R: exists R.Top <= Inst, Top <= forall R.Inst;
            exists type.Top <= Inst, Top <= forall type.Class;
            exists subClassOf.Top <= Class, Top <= forall subClassOf.Class;
            exists RInst.Self == Inst.
  Typing:   C == exists type.{o_C}.
  MatSub:   Class and forall type^-.(exists type.{o_C}) == Class and exists subClassOf.{o_C}.

Representative-identity mapping: the canonical graph puns each definition IRI.
Its *class* use (chart1 rdf:type CrimeRateChart_v1) stays on the class IRI and
is rewritten by Typing; its *individual* use (CrimeRateChart_v1 rdf:type
StatisticalChartType, prov:wasAttributedTo, ex:approvedType, ...) is moved to
the representative o_C = meta:o_<localname>. Categories (StatisticalChartType,
SensitiveChartType) are also punned in the canonical graph; see the cases.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from rdflib import BNode, Dataset, Graph, Literal, Namespace, RDF, RDFS, URIRef
from rdflib.namespace import OWL, XSD

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent  # provenance-profile
SOURCE = ROOT / "chart-baseline" / "snapshots.trig"
EX = Namespace("https://example.org/provenance-chart/")
PROV = Namespace("http://www.w3.org/ns/prov#")
META = Namespace("urn:pamola:glimm-meta#")
CONTEXTS = ["beforeWithdrawal", "afterWithdrawal", "incompleteRegistry", "newChartType", "recategorisedType"]
T1, T2, K, KS, BUD = EX.CrimeRateChart_v1, EX.CrimeRateChart_v2, EX.StatisticalChartType, EX.SensitiveChartType, EX.BudgetChart_v1
INST, CLASS, TYPE, SUBCLASSOF, RINST = META.Inst, META.Class, META.type, META.subClassOf, META.RInst
APPLICATION_ROLES = [PROV.wasAttributedTo, PROV.wasDerivedFrom, PROV.wasRevisionOf, PROV.wasGeneratedBy,
                     PROV.qualifiedUsage, PROV.entity, PROV.hadRole, EX.approvedType]
POLICY_DATA = [EX.requiresApproval, EX.completeApprovalRegistry]


def rep(c):
    return META["o_" + str(c).rsplit("/", 1)[-1]]


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def ntriple(t):
    return " ".join(x.n3() for x in t) + " ."


def ordered_nt(g):
    return "\n".join(sorted(ntriple(t) for t in g)) + "\n"


# ---- small OWL class-expression helpers (fixed blank-node labels) -----------
class B:
    def __init__(self, g):
        self.g, self.n = g, 0

    def node(self, tag):
        self.n += 1
        return BNode(f"{tag}{self.n}")

    def lst(self, items):
        if not items:
            return RDF.nil
        nodes = [self.node("l") for _ in items]
        for i, it in enumerate(items):
            self.g.add((nodes[i], RDF.first, it))
            self.g.add((nodes[i], RDF.rest, nodes[i + 1] if i + 1 < len(nodes) else RDF.nil))
        return nodes[0]

    def restriction(self, prop, kind, value):
        r = self.node("r")
        self.g.add((r, RDF.type, OWL.Restriction))
        self.g.add((r, OWL.onProperty, prop))
        self.g.add((r, kind, value))
        return r

    def some(self, p, c):
        return self.restriction(p, OWL.someValuesFrom, c)

    def all_(self, p, c):
        return self.restriction(p, OWL.allValuesFrom, c)

    def has(self, p, i):
        return self.restriction(p, OWL.hasValue, i)

    def self_(self, p):
        return self.restriction(p, OWL.hasSelf, Literal(True))

    def inv(self, p):
        n = self.node("inv")
        self.g.add((n, OWL.inverseOf, p))
        return n

    def neg(self, c):
        n = self.node("c")
        self.g.add((n, RDF.type, OWL.Class))
        self.g.add((n, OWL.complementOf, c))
        return n

    def and_(self, *cs):
        n = self.node("c")
        self.g.add((n, RDF.type, OWL.Class))
        self.g.add((n, OWL.intersectionOf, self.lst(list(cs))))
        return n

    def oneof(self, *inds):
        n = self.node("c")
        self.g.add((n, RDF.type, OWL.Class))
        self.g.add((n, OWL.oneOf, self.lst(list(inds))))
        return n

    def sub(self, a, b):
        self.g.add((a, RDFS.subClassOf, b))

    def equiv(self, a, b):
        self.g.add((a, OWL.equivalentClass, b))

    def alldifferent(self, inds):
        n = self.node("ad")
        self.g.add((n, RDF.type, OWL.AllDifferent))
        self.g.add((n, OWL.members, self.lst(list(inds))))


def declare(g, classes, roles, data, individuals):
    for c in classes:
        g.add((c, RDF.type, OWL.Class))
    for r in roles:
        g.add((r, RDF.type, OWL.ObjectProperty))
    for d in data:
        g.add((d, RDF.type, OWL.DatatypeProperty))
    for i in individuals:
        g.add((i, RDF.type, OWL.NamedIndividual))


def canonical_split(original):
    """Return (class_uses, individual_uses, policy) from one canonical graph.

    class_uses:      [(instance, classIRI)] from rdf:type whose subject is a chart (level 0)
    individual_uses: triples whose subject is a punned definition/category IRI
    """
    definitions = {s for s, _, o in original.triples((None, RDF.type, None)) if (None, RDF.type, s) in original}
    categories = {o for s, _, o in original.triples((None, RDF.type, None)) if s in definitions}
    charts = {s for s, _, o in original.triples((None, RDF.type, None)) if o in definitions}
    return definitions, categories, charts


def transform(original, case):
    """Build one O_meta graph for the given case. Returns (graph, notes)."""
    definitions, categories, charts = canonical_split(original)
    g = Graph()
    b = B(g)
    notes = {}
    # Which named classes receive the Def.4 construction (representative, Typing, MatSubClass)
    transformed = set(definitions)
    if case in {"E4-S", "E4-S2"}:
        transformed |= categories          # uniform three-level application
    # Which roles receive the SepDom layer-separation axioms
    separated = list(APPLICATION_ROLES) if case in {"E4-S", "E4-S1"} else []
    notes["transformed_classes"] = sorted(map(str, transformed))
    notes["separated_roles"] = sorted(map(str, separated))

    individuals = set()
    for s, p, o in original:
        if p == RDF.type:
            if s in charts:                      # class use: kept, rewritten by Typing below
                g.add((s, RDF.type, o)); individuals.add(s)
            else:                                # individual use of a punned class IRI
                g.add((rep(s), RDF.type, o))
        else:
            subj = rep(s) if s in (definitions | categories) else s
            obj = rep(o) if (isinstance(o, URIRef) and o in (definitions | categories)) else o
            g.add((subj, p, obj))
            for node in (s, o):
                if isinstance(node, URIRef) and str(node).startswith(str(EX)) and node not in (definitions | categories):
                    individuals.add(node)
    reps = {rep(c) for c in definitions | categories}
    # ---- SepDom ----
    b.equiv(INST, b.neg(CLASS))
    for r in reps:
        g.add((r, RDF.type, CLASS))
    for i in individuals:
        g.add((i, RDF.type, INST))
    for R in separated:
        b.sub(b.some(R, OWL.Thing), INST)
        b.sub(OWL.Thing, b.all_(R, INST))
    b.sub(b.some(TYPE, OWL.Thing), INST)
    b.sub(OWL.Thing, b.all_(TYPE, CLASS))
    b.sub(b.some(SUBCLASSOF, OWL.Thing), CLASS)
    b.sub(OWL.Thing, b.all_(SUBCLASSOF, CLASS))
    b.equiv(INST, b.self_(RINST))
    # Categories that are NOT transformed are meta-level classes: K <= Class.
    for c in categories - transformed:
        b.sub(c, CLASS)
    # ---- Typing and MatSubClass ----
    for c in sorted(transformed):
        b.equiv(c, b.some(TYPE, b.oneof(rep(c))))
        b.equiv(b.and_(CLASS, b.all_(b.inv(TYPE), b.some(TYPE, b.oneof(rep(c))))),
                b.and_(CLASS, b.some(SUBCLASSOF, b.oneof(rep(c)))))
    declare(g, set(definitions | categories) | {INST, CLASS}, set(APPLICATION_ROLES) | {TYPE, SUBCLASSOF, RINST}, POLICY_DATA, individuals | reps)
    return g, b, notes, (definitions, categories, charts)


def add_policy(g, b, original, context, with_closure):
    """OWL encoding of the category-scoped review policy over the representatives.

    Approved_K == exists approvedType.{o_K}        (per category K)
    RequiresReview_K == K and not Approved_K
    ReviewEntity == exists type.(RequiresReview_K ...)   (cross-level rule)
    ReviewPublication == exists wasDerivedFrom.ReviewEntity
    Closure (only with_closure, only for categories whose canonical graph carries
    completeApprovalRegistry true): Approved_K == {approved members} or Nothing,
    plus AllDifferent over representatives (unique-name assumption).
    """
    definitions, categories, charts = canonical_split(original)
    review_classes = []
    for Kc in sorted(categories):
        appr, req = META["Approved_" + str(Kc).rsplit("/", 1)[-1]], META["RequiresReview_" + str(Kc).rsplit("/", 1)[-1]]
        g.add((appr, RDF.type, OWL.Class)); g.add((req, RDF.type, OWL.Class))
        b.equiv(appr, b.some(EX.approvedType, b.oneof(rep(Kc))))
        b.equiv(req, b.and_(Kc, b.neg(appr)))
        review_classes.append(req)
        complete = (Kc, EX.completeApprovalRegistry, Literal(True)) in original
        if with_closure and complete:
            approved = sorted(rep(s) for s, _, o in original.triples((None, EX.approvedType, Kc)))
            b.equiv(appr, b.oneof(*approved) if approved else OWL.Nothing)
    if with_closure:
        b.alldifferent(sorted(rep(c) for c in definitions | categories))
    for name, expr in [(META.ReviewEntity, None), (META.ReviewPublication, None)]:
        g.add((name, RDF.type, OWL.Class))
    if len(review_classes) == 1:
        target = review_classes[0]
    else:
        target = b.node("c"); g.add((target, RDF.type, OWL.Class)); g.add((target, OWL.unionOf, b.lst(review_classes)))
    b.equiv(META.ReviewEntity, b.some(TYPE, target))
    b.equiv(META.ReviewPublication, b.some(PROV.wasDerivedFrom, META.ReviewEntity))


def mutate(g, b, original, case):
    """E5 mutations, mirroring E2's flattening and the potency-step mutation."""
    definitions, categories, charts = canonical_split(original)
    cat = next(o for o in original.objects(T1, RDF.type))
    if case.startswith("E5-flat"):
        g.remove((rep(T1), RDF.type, cat))
        b.sub(T1, cat)                       # T1 <= K : the E2 mutation
        if case == "E5-flat-noinst":
            for c in charts:
                for d in list(g.objects(c, RDF.type)):
                    if d == T1:
                        g.remove((c, RDF.type, T1))
    if case == "E5-direct":
        g.add((EX.chart1, RDF.type, cat))    # D(chart1,K): the potency-step mutation


def level_control_punned(original, case):
    """E5-ctrl-pun: plain E2 (punned, flattened) plus explicit level classes on the
    punned individuals. No representative link exists, so the class axiom
    T1 <= K is untouched by the level assertions."""
    g = Graph(); b = B(g)
    for t in original:
        g.add(t)
    cat = next(o for o in original.objects(T1, RDF.type))
    g.remove((T1, RDF.type, cat)); g.add((T1, RDFS.subClassOf, cat))
    L0, L1, L2 = META.Level0, META.Level1, META.Level2
    for L in (L0, L1, L2):
        g.add((L, RDF.type, OWL.Class))
    ad = b.node("dj"); g.add((ad, RDF.type, OWL.AllDisjointClasses)); g.add((ad, OWL.members, b.lst([L0, L1, L2])))
    definitions, categories, charts = canonical_split(original)
    for c in charts: g.add((c, RDF.type, L0))
    for d in definitions: g.add((d, RDF.type, L1))
    for k in categories: g.add((k, RDF.type, L2))
    classes = set(original.objects(None, RDF.type))
    inds = set(original.subjects()) | {o for o in original.objects() if isinstance(o, URIRef) and str(o).startswith(str(EX))}
    declare(g, classes, [EX.approvedType], POLICY_DATA, inds)
    return g


CASES = {
    # id: (description, expected_consistent)
    "E4-S":   ("Strict uniform Def.4: categories transformed too (three-level), all application roles layer-separated.", False),
    "E4-S1":  ("Strict roles: categories kept meta-level (two-layer), PROV/policy roles layer-separated.", False),
    "E4-S2":  ("Strict levels: categories transformed too (three-level), roles exempted.", False),
    "E4-B":   ("Bounded faithful encoding: two layers, categories meta-level, roles exempted. No policy.", True),
    "E4-P":   ("E4-B plus the OWL review policy without closure (open world).", True),
    "E4-PC":  ("E4-B plus the OWL review policy with nominal closure for complete registries and UNA on representatives.", True),
    "E5-flat": ("E4-B with E2's flattening T1 <= K.", False),
    "E5-flat-noinst": ("E5-flat with v1's chart instances removed (shows unsatisfiability without inconsistency).", True),
    "E5-direct": ("E4-B with the potency-step mutation K(chart1).", False),
    "E5-ctrl-pun": ("Punned E2 plus disjoint explicit level classes on the punned individuals (no representative link).", True),
    "E5-ctrl-nolayer": ("E4-B flattening with K's layer left unassigned (user did not place K <= Class).", True),
}


def expectations(case, context, original):
    definitions, categories, charts = canonical_split(original)
    cat = next(o for o in original.objects(T1, RDF.type))
    oT1, oK = rep(T1), rep(cat)
    qs, exp = [], {}

    def q(i, kind, ans, **kw):
        qs.append({"id": i, "kind": kind, **{k: str(v) for k, v in kw.items()}}); exp[i] = ans

    consistent = CASES[case][1]
    if case == "E5-ctrl-pun":
        q("chart1_in_category", "class_assertion", True, individual=EX.chart1, **{"class": cat})
        q("definition_attributed_to_alice", "object_property_assertion", True, subject=T1, property=PROV.wasAttributedTo, object=EX.Alice)
        q("chart1_attributed_to_alice", "object_property_assertion", False, subject=EX.chart1, property=PROV.wasAttributedTo, object=EX.Alice)
        q("t1_subclass_of_category", "subclass", True, sub=T1, super=cat)
        sats = [T1, cat, META.Level0, META.Level1, META.Level2]
        return {"entailments": qs, "satisfiability": [{"id": "sat_" + str(c).split("/")[-1].split("#")[-1], "class": str(c)} for c in sats]}, {"consistent": True, "entailments": exp, "satisfiability": {"sat_" + str(c).split("/")[-1].split("#")[-1]: True for c in sats}}
    if not consistent:
        # Consistency is the result. Queries are still issued so that the raw
        # output records the harness's inconsistent_ontology status (no Boolean).
        q("chart1_has_definition", "class_assertion", None, individual=EX.chart1, **{"class": T1})
        q("oT1_attributed_to_alice", "object_property_assertion", None, subject=oT1, property=PROV.wasAttributedTo, object=EX.Alice)
        return {"entailments": qs, "satisfiability": [{"id": "sat_T1", "class": str(T1)}]}, {"consistent": False, "entailments": exp, "satisfiability": {"sat_T1": None}}
    # consistent E4-B/E4-P/E4-PC/E5-flat-noinst/E5-ctrl-nolayer
    flat = case in {"E5-flat-noinst", "E5-ctrl-nolayer"}
    q("chart1_type_oT1", "object_property_assertion", not case == "E5-flat-noinst", subject=EX.chart1, property=TYPE, object=oT1)
    q("chart1_has_definition", "class_assertion", not case == "E5-flat-noinst", individual=EX.chart1, **{"class": T1})
    q("oT1_in_category", "class_assertion", not flat, individual=oT1, **{"class": cat})
    q("chart1_in_category", "class_assertion", case == "E5-ctrl-nolayer", individual=EX.chart1, **{"class": cat})
    q("t1_subclass_of_category", "subclass", flat, sub=T1, super=cat)
    q("oT1_attributed_to_alice", "object_property_assertion", True, subject=oT1, property=PROV.wasAttributedTo, object=EX.Alice)
    q("chart1_attributed_to_derek", "object_property_assertion", True, subject=EX.chart1, property=PROV.wasAttributedTo, object=EX.Derek)
    q("chart1_attributed_to_alice", "object_property_assertion", False, subject=EX.chart1, property=PROV.wasAttributedTo, object=EX.Alice)
    q("chart1_derived_from_guideline", "object_property_assertion", False, subject=EX.chart1, property=PROV.wasDerivedFrom, object=EX.guideline1)
    q("oT1_derived_from_guideline", "object_property_assertion", True, subject=oT1, property=PROV.wasDerivedFrom, object=EX.guideline1)
    q("oT1_subClassOf_oT1_reflexive", "object_property_assertion", True, subject=oT1, property=SUBCLASSOF, object=oT1)
    q("oT1_subClassOf_oK", "object_property_assertion", False, subject=oT1, property=SUBCLASSOF, object=oK)
    q("oT1_is_Class", "class_assertion", True, individual=oT1, **{"class": CLASS})
    q("chart1_is_Inst", "class_assertion", True, individual=EX.chart1, **{"class": INST})
    if case in {"E4-P", "E4-PC"}:
        req = META["RequiresReview_" + str(cat).rsplit("/", 1)[-1]]
        complete = (cat, EX.completeApprovalRegistry, Literal(True)) in original
        v1_approved_here = (T1, EX.approvedType, cat) in original
        closed = case == "E4-PC" and complete
        review_v1 = closed and not v1_approved_here
        q("oT1_requires_review", "class_assertion", review_v1, individual=oT1, **{"class": req})
        q("chart1_review_entity", "class_assertion", review_v1, individual=EX.chart1, **{"class": META.ReviewEntity})
        q("chart2_review_entity", "class_assertion", review_v1, individual=EX.chart2, **{"class": META.ReviewEntity})
        q("chart3_review_entity", "class_assertion", False, individual=EX.chart3, **{"class": META.ReviewEntity})
        q("article1_review_publication", "class_assertion", review_v1, individual=EX.article1, **{"class": META.ReviewPublication})
        q("article2_review_publication", "class_assertion", False, individual=EX.article2, **{"class": META.ReviewPublication})
        if context == "newChartType":
            q("chart4_review_entity", "class_assertion", closed, individual=EX.chart4, **{"class": META.ReviewEntity})
            q("article3_review_publication", "class_assertion", closed, individual=EX.article3, **{"class": META.ReviewPublication})
        if context == "recategorisedType":
            q("oT1_still_statistically_approved", "object_property_assertion", True, subject=oT1, property=EX.approvedType, object=rep(K))
            q("oT1_not_in_statistical_review", "class_assertion", False, individual=oT1, **{"class": META["RequiresReview_StatisticalChartType"]})
    sats = [T1, cat, META.ReviewEntity] if case in {"E4-P", "E4-PC"} else [T1, cat]
    sat_exp = {}
    for c in sats:
        sid = "sat_" + str(c).split("/")[-1].split("#")[-1]
        # T1 is unsatisfiable only when the flattening meets the layer axiom K <= Class
        # (E5-flat-noinst). In E5-ctrl-nolayer that axiom is absent and T1 stays satisfiable.
        sat_exp[sid] = not (case == "E5-flat-noinst" and c == T1)
    return {"entailments": qs, "satisfiability": [{"id": "sat_" + str(c).split("/")[-1].split("#")[-1], "class": str(c)} for c in sats]}, {"consistent": True, "entailments": exp, "satisfiability": sat_exp}


def build():
    ds = Dataset(); ds.parse(SOURCE, format="trig")
    inputs, manifests = HERE / "inputs", HERE / "manifests"
    inputs.mkdir(exist_ok=True); manifests.mkdir(exist_ok=True)
    prov = {"canonical_source": str(SOURCE.relative_to(ROOT.parent)), "canonical_source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
            "construction": "Glimm, Rudolph, Voelker, ISWC 2010, Def. 4; O_meta = bound u SepDom u Typing u MatSubClass; see TRANSFORMATION.md", "cases": []}
    oracles = {"written_before_reasoner_execution": True, "expectation_source": "Authored in build_metamodel.py from the published construction; not inferred from backend results.", "cases": {}}
    for context in CONTEXTS:
        original = Graph()
        for t in ds.graph(EX[context]):
            original.add(t)
        for case, (desc, _) in CASES.items():
            if case == "E5-ctrl-pun":
                g = level_control_punned(original, case); notes = {"construction": "none (punned E2 + level classes)"}
            else:
                g, b, notes, _ = transform(original, "E4-B" if case.startswith("E5") else case)
                if case in {"E4-P", "E4-PC"}:
                    add_policy(g, b, original, context, with_closure=(case == "E4-PC"))
                if case.startswith("E5-flat") or case == "E5-direct":
                    mutate(g, b, original, case)
                if case == "E5-ctrl-nolayer":
                    cat = next(o for o in original.objects(T1, RDF.type))
                    g.remove((cat, RDFS.subClassOf, CLASS))
                    g.remove((rep(T1), RDF.type, cat)); b.sub(T1, cat)
            stem = f"{case}__{context}"
            onto = URIRef("urn:pamola:owl-metamodel:" + stem)
            g.add((onto, RDF.type, OWL.Ontology)); g.add((onto, OWL.imports, URIRef("http://www.w3.org/ns/prov-o")))
            payload = ordered_nt(g)
            (inputs / f"{stem}.ttl").write_text(payload, encoding="utf-8")
            manifest, oracle = expectations(case, context, original)
            manifest["task_timeout_ms"] = 120000
            dump(manifests / f"{stem}.json", manifest)
            oracles["cases"][stem] = {**oracle, "description": desc}
            prov["cases"].append({"id": stem, "context": str(EX[context]), "description": desc, "notes": notes,
                                  "canonical_triples": len(original), "canonical_context_sha256": hashlib.sha256(ordered_nt(original).encode()).hexdigest(),
                                  "input": f"inputs/{stem}.ttl", "input_sha256": hashlib.sha256(payload.encode()).hexdigest(),
                                  "removed_canonical_triples": sorted(ntriple(t) for t in set(original) - set(g)),
                                  "added_triples": sorted(ntriple(t) for t in set(g) - set(original))})
    dump(HERE / "source_manifest.json", prov); dump(HERE / "oracles.json", oracles)
    print(f"Built {len(prov['cases'])} metamodel inputs with predeclared oracles from five canonical contexts.")


if __name__ == "__main__":
    build()
