# E4/E5: the Glimm–Rudolph–Völker metamodelling encoding on the canonical scenario

Source construction: B. Glimm, S. Rudolph, J. Völker, *Integrated Metamodeling and
Diagnosis in OWL 2*, ISWC 2010 (LNCS 6496, pp. 257–272), Section 3, Definition 4,
and Theorem 1. The implementation in `build_metamodel.py` instantiates the core
construction on the selected class-membership fragment and declares its
application extensions below. Python builds and checks fixtures; all OWL
consistency, satisfiability and entailment answers come from HermiT
through the shared backend (`../tools/reasoner_backend.py`).

## 1. The published construction (Definition 4, Theorem 1)

For an ontology *O* with class names *O_C*, roles *O_R* and individuals *O_I*:

* fresh class names `Inst`, `Class`; fresh roles `type`, `subClassOf`, `RInst`;
  one fresh individual `o_C` for every `C ∈ O_C`;
* `O_meta = bound(O) ∪ SepDom(O) ∪ Typing(O) ∪ MatSubClass(O)` with
  * `bound(·)`: `⊤`, `¬C`, `∀R.C`, `≤n R.C` in *O* are relativised to `Inst`
    (the universal role is localised through `RInst`, `∃RInst.Self ≡ Inst`);
  * `SepDom(O)`: `Inst ≡ ¬Class`; `Class(o_C)` for every `C`; `Inst(i)` for every
    named individual; for every role `R ∈ O_R`: `∃R.⊤ ⊑ Inst`, `⊤ ⊑ ∀R.Inst`;
    `∃type.⊤ ⊑ Inst`, `⊤ ⊑ ∀type.Class`; `∃subClassOf.⊤ ⊑ Class`, `⊤ ⊑ ∀subClassOf.Class`;
  * `Typing(O)`: `C ≡ ∃type.{o_C}` for every `C ∈ O_C`;
  * `MatSubClass(O)`: `Class ⊓ ∀type⁻.∃type.{o_C} ≡ Class ⊓ ∃subClassOf.{o_C}` for every `C ∈ O_C`.
* Theorem 1: `O ⊨ C(i)` iff `O_meta ⊨ type(i, o_C)`; for named `C, D`,
  `O ⊨ C ⊑ D` iff `O_meta ⊨ subClassOf(o_C, o_D)`; `O_meta` is linear in `|O|`.
* Metaclasses (the paper's `Species`, `Order`) can be added as classes **over
  representatives**, for example `Species(o_GoldenEagle)`. The published
  construction adds one metalayer to the domain ontology, separated as `Inst`
  and `Class`; it does not provide the recursive, identity-preserving extension
  across classification levels tested in `E4-S` and `E4-S2` below.

## 2. Application to the canonical snapshots

Canonical facts: the five named graphs of `../../chart-baseline/snapshots.trig`,
unchanged (hash in `source_manifest.json`). Each definition IRI
(`CrimeRateChart_v1`, `CrimeRateChart_v2`, `BudgetChart_v1`) and each category IRI
(`StatisticalChartType`, `SensitiveChartType`) is punned in the canonical graph.

Representative-identity mapping `f`:

| canonical use | encoding |
|---|---|
| `chart1 rdf:type CrimeRateChart_v1` (class use) | kept; `Typing` makes it equivalent to `type(chart1, o_CrimeRateChart_v1)` |
| `CrimeRateChart_v1 rdf:type StatisticalChartType` (individual use) | `StatisticalChartType(o_CrimeRateChart_v1)` |
| `CrimeRateChart_v1 prov:wasAttributedTo Alice` | `o_CrimeRateChart_v1 prov:wasAttributedTo Alice` |
| `CrimeRateChart_v2 ex:approvedType StatisticalChartType` | `o_CrimeRateChart_v2 ex:approvedType o_StatisticalChartType` |
| `StatisticalChartType ex:requiresApproval true` | `o_StatisticalChartType ex:requiresApproval true` |
| remaining triples | retained, with definition/category participants mapped to their representatives wherever they occur |

`o_C` is `urn:pamola:glimm-meta#o_<localname>`. Every added and removed triple per
case is listed in `source_manifest.json`. PROV-O is imported unchanged in both of
the package's declared variants (raw; metadata projection) through the backend.
Approvals stay category-valued object-property assertions; completeness stays a
datatype assertion on the category's representative. Qualified usage and
generation facts are retained.

## 3. Cases

Three questions have to be settled before the construction can be applied to this
scenario, because the scenario has **three** ontological levels (category →
definition → chart) and because the PROV roles are used on both layers. Each
choice is a separate case; the strict readings are run so that their outcome is
observed rather than assumed. These tests add the declared representative
identity mapping and meta-level assertions to the core construction. The
inconsistent cases do not contradict Theorem 1's consistency preservation for
the published transformation within its stated scope.

| case | categories | application roles in `SepDom` | expected |
|---|---|---|---|
| `E4-S` | transformed like definitions (uniform, three-level) | separated | **inconsistent** — `Typing(K)` turns `K(o_T1)` into `type(o_T1, o_K)`, whence `Inst(o_T1)`, against `Class(o_T1)` |
| `E4-S1` | kept meta-level (`K ⊑ Class`) | separated | **inconsistent** — `wasAttributedTo(o_T1, Alice)` forces `Inst(o_T1)` through `∃R.⊤ ⊑ Inst` |
| `E4-S2` | transformed (three-level) | exempted | **inconsistent** — same clash as `E4-S` through `type` |
| `E4-B` | meta-level | exempted | consistent; the bounded faithful encoding used for everything below |
| `E4-P` | `E4-B` + OWL review policy, no closure | | consistent; review classes **not entailed** (open world) |
| `E4-PC` | `E4-B` + policy + nominal closure + UNA | | consistent; the tested named review memberships match the policy-scenario table in the five snapshots |
| `E5-flat` | `E4-B` with E2's `T1 ⊑ K` | | **inconsistent** — `T1 ≡ ∃type.{o_T1} ⊑ Inst` and `K ⊑ Class` |
| `E5-flat-noinst` | as `E5-flat`, v1's chart instances removed | | consistent, `T1` **unsatisfiable** |
| `E5-direct` | `E4-B` with `K(chart1)` (potency-step mutation) | | **inconsistent** |
| `E5-ctrl-pun` | punned E2 + disjoint `Level0/1/2` classes on the punned individuals | | consistent; `K(chart1)` **entailed** — flattening undetected |
| `E5-ctrl-nolayer` | `E4-B` flattening with `K ⊑ Class` omitted | | consistent; `K(chart1)` **entailed** — flattening undetected |

`E4-B` makes the following bounded application choices. The inconsistent
controls show why these choices matter for this implementation; they establish
neither that these are the only possible extensions nor that Glimm's approach
cannot support provenance.

1. **Two-layer application.** The category is a class over representatives (`K ⊑ Class`,
   `K(o_T1)`), as `Species(o_GoldenEagle)` is in the paper. It receives no
   representative of its own from the construction; `o_K` exists only because the
   canonical policy facts (`approvedType`, `requiresApproval`,
   `completeApprovalRegistry`) take the category as an individual. The link between
   `K` and `o_K` is **not axiomatised in this implementation**. They have distinct
   IRIs, so this is an unbridged category/class-representative pair rather than
   literal same-IRI OWL punning. A level-indexed extension was not attempted;
   the experiment establishes no impossibility result for such an extension.
2. **Layer-crossing roles.** The PROV roles and `approvedType` are excluded from
   `SepDom`'s role separation because they are used on both layers. Theorem 1 is
   stated for domain roles in `O_R` that *are* separated. The exempted
   application/meta-level roles and unchanged PROV import are extensions
   outside that theorem's scope. The published paper explicitly motivates
   provenance and permits added meta-level constraints.

## 4. The policy encoding (E4-P, E4-PC) — additions beyond the construction

Per category `K` (over representatives):

```
Approved_K        ≡ ∃approvedType.{o_K}
RequiresReview_K  ≡ K ⊓ ¬Approved_K
ReviewEntity      ≡ ∃type.(RequiresReview_K ⊔ …)      -- the cross-level rule
ReviewPublication ≡ ∃wasDerivedFrom.ReviewEntity
```

`ReviewEntity` uses the explicit `type` bridge, which punning alone does not
supply: it follows an instance to a property of its *class's representative*.
Under the encoding this is an ordinary OWL axiom. Its conclusions are still **not entailed**
in `E4-P`: `¬Approved_K` is never derivable for `o_T1` under the open world.
`E4-PC` adds, only for categories whose canonical graph carries
`completeApprovalRegistry true`,

```
Approved_K ≡ {o_C : (C approvedType K) in the snapshot}   (or ⊥ if none)
AllDifferent(o_C …)                                        (UNA on representatives)
```

i.e. the completeness certificate becomes a nominal closure axiom, and the
representatives are declared pairwise different (the paper does not state a
unique-name assumption; without it `o_T1 = o_T2` is a model). The incomplete
registry snapshot receives no closure axiom and its review classes are not
entailed. This implemented OWL baseline supplies no explicit undetermined
output, whereas the native policy reports an `approvalUndetermined` witness.
No claim is made that an OWL-based workflow could not add such an output.

This policy construction is scoped to the five supplied snapshots, in which
all relevant categories require approval. `add_policy` creates review classes
for every present category and does not test the `requiresApproval` flag. The
comparison therefore concerns the tested named review memberships, not full
equivalence to the native policy under arbitrary flags or all of its
category/agent witness outputs.

`bound(·)` relativises negation to `Inst`; the policy's negation is on the `Class`
layer and is bounded by `K ⊑ Class` instead. This is an extension outside
Theorem 1, declared here.

## 5. What the comparison shows, stated in the outcome vocabulary

* `E4-B`: the single representative `o_T1` is both the subject of attribution
  and the target of `type`; `type(chart1, o_T1)` and `wasAttributedTo(o_T1, Alice)`
  are entailed; `wasAttributedTo(chart1, Alice)` and `K(chart1)` are not entailed
  (subjects preserved, population preserved). `subClassOf(o_T1, o_T1)` is
  entailed (MatSubClass sanity), `subClassOf(o_T1, o_K)` is not.
* `E4-PC`: with closure and UNA, HermiT derives the tested named review memberships of the policy-scenario table for all
  five snapshots (v1 and its two charts and article1 after withdrawal; v1 and
  BudgetChart_v1 with chart4 and article3 in the new-type snapshot; v1 under the
  sensitive category only, its statistical approval retained, in the
  recategorised snapshot).
* `E5-flat` / `E5-direct`: the encoding's own `Inst/Class` separation rejects the
  flattening and the potency-step mutation, **as global inconsistency**, and only
  because the modeller placed `K` on the `Class` layer (`E5-ctrl-nolayer` shows
  the same mutation accepted when that placement is omitted). Level annotations
  on punned individuals (`E5-ctrl-pun`) cannot reach the class axiom and detect
  no error in this control. These are the implemented hard-constraint variants.
  Glimm et al. also propose marker-based diagnostics that locate violations
  without making the ontology inconsistent; those variants are not tested here.
* The native contract rejects the same two mutations before any view is
  generated, with a named witness (`generalisation-level` on
  `(CrimeRateChart_v1, StatisticalChartType)`; `potency-step`)
  (`../../model-integration/results/report.json`). Both approaches require
  authored level information: native elements carry potency values and the
  OWL encoding carries layer-placement axioms. The observed distinction is
  where that information is checked and how this implementation reports the
  failure, not that only one approach can constrain levels.

## 6. Integration qualification

The observations above support a bounded comparison of explicit modelling
choices. They do not establish a new metamodel semantics, an inherent OWL
inability to report diagnostic witnesses, or a complete implementation of the
native policy in OWL. The core Glimm encoding and this package's declared
extensions should remain distinguishable in any manuscript summary.

No claim is made that the encoding is impractical, undeployable or slower; the
paper's own runtimes are for a different workload. No claim is made that RDF or
SPARQL cannot express the policy.
