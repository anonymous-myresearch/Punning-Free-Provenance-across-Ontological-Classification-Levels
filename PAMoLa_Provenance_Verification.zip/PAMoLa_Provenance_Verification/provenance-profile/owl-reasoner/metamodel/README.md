# E4/E5 — established metamodel encoding (Glimm–Rudolph–Völker 2010) and flattening controls

This module implements the E4/E5 metamodel experiments. It reuses
the shared OWLAPI/HermiT backend unchanged (`../tools/reasoner_backend.py`,
pinned jar; both PROV-O import variants) and the unchanged canonical snapshots
(`../../chart-baseline/snapshots.trig`, hash recorded).

Read `TRANSFORMATION.md` for the construction and its correspondence to the
published definition.

## Run (from `provenance-profile/`, Python 3.10+, Java 17+, rdflib 7.1.4)

```sh
python3 owl-reasoner/metamodel/build_metamodel.py        # inputs, manifests, predeclared oracles
python3 owl-reasoner/metamodel/run_metamodel.py          # raw PROV-O import
python3 owl-reasoner/metamodel/run_metamodel.py --prov-variant metadata_projection
python3 owl-reasoner/metamodel/verify_metamodel.py       # re-checks reports against oracles and hashes
```

Eleven cases × five canonical contexts = 55 inputs per arm, 110 real HermiT runs.
Every raw backend result is kept in `results/<arm>/raw/`.

The report-only verifier independently compares the raw answers and statuses
with the current oracles and checks summary rows against those comparisons.
It checks the recorded oracle, query, input, canonical-source, import and reasoner
dependency hashes; complete query execution; the expected import closure; strict
DL conformance of the projected arm; and only the known two-property PROV-O
diagnostics in the raw arm. It also checks agreement of the two arms on all
reported semantic answers. A stored `matches: true` flag is insufficient.

Each arm has 30 consistent and 25 inconsistent inputs. Its 598 query statuses
comprise 251 entailed, 187 not entailed, 80 satisfiable, 5 unsatisfiable and
75 `inconsistent_ontology` results. The last category records queries that are
not given Boolean answers because their ontology is inconsistent.

## Outcomes (both import arms agree; projected arm: all 55 inputs pass the OWL 2 DL profile checker, raw arm: only the known PROV-O `IllegalPunning` diagnostics)

| case | result | meaning |
|---|---|---|
| E4-S, E4-S2 (categories transformed, three-level) | **inconsistent** ×5 | the tested uniform three-level application of the published two-layer construction is inconsistent |
| E4-S1 (PROV/policy roles layer-separated) | **inconsistent** ×5 | this cross-layer role use conflicts with the tested `SepDom` constraints; the bounded arm exempts those roles |
| E4-B (bounded adaptation: two layers, roles exempted) | consistent ×5; `type(chart1,o_v1)`, `K(o_v1)`, `wasAttributedTo(o_v1,Alice)` entailed; `K(chart1)`, `wasAttributedTo(chart1,Alice)`, `subClassOf(o_v1,o_K)` not entailed | one representative carries both roles; population and subjects preserved; the category class and its separate policy individual remain unlinked |
| E4-P (+ policy, open world) | consistent ×5; no review class entailed | the cross-level rule `ReviewEntity ≡ ∃type.RequiresReview` is expressible but inert without closure |
| E4-PC (+ nominal closure for complete registries + UNA) | consistent ×5; review set entailed exactly as in the native policy-scenario table; incomplete registry silent | a correctly closed OWL route reproduces the review set; this implemented baseline emits no explicit undetermined witness |
| E5-flat (E2 mutation `T1 ⊑ K` under E4-B) | **inconsistent** ×5 | detected, as global inconsistency, because `K ⊑ Class` was authored |
| E5-flat-noinst | consistent ×5, `CrimeRateChart_v1` **unsatisfiable** | the same detection as class unsatisfiability |
| E5-direct (`K(chart1)`, potency-step mutation) | **inconsistent** ×5 | detected, same mechanism |
| E5-ctrl-pun (punned E2 + disjoint level classes on individuals) | consistent ×5, `K(chart1)` **entailed** | level annotations on punned individuals do not reach the class axiom: undetected |
| E5-ctrl-nolayer (E5-flat without `K ⊑ Class`) | consistent ×5, `K(chart1)` **entailed** | detection depends on the modeller's layer placement |

Native comparison (from `../../model-integration/results/report.json`, not re-run
here): `flattenedGeneralisation` rejected before projection, code
`generalisation-level`, witness `(CrimeRateChart_v1, StatisticalChartType)`;
`badPotency` rejected before projection, code `potency-step`.

## Process note

The first execution used the oracles archived in `results/first-run/`. Five case
identities mismatched in each import arm (ten of the 110 runs): the predeclared oracle wrongly expected
`CrimeRateChart_v1` to be unsatisfiable in `E5-ctrl-nolayer`, where the layer
axiom that makes it unsatisfiable is deliberately absent. That is an authoring
error in the expectation, not a reasoner surprise; the oracle was corrected and
both arms re-executed. The first-run reports are retained unchanged.

## What this package does not claim

No runtime or maintenance measurement. No claim that the encoding is
undeployable. No claim that RDF or SPARQL cannot express the policy. No claim
that a level-indexed generalisation of the construction is impossible — it was
not attempted. The OWL route with closure receives full credit for the review
set; its costs are the ones observed: a two-layer limit, role exemption outside
Theorem 1, authored layer placement, nominal closure plus UNA, and silence in
the undetermined case.
