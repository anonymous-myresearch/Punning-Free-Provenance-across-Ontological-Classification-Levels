#!/usr/bin/env python3
"""Execute the E4/E5 metamodel cases with the shared OWLAPI/HermiT backend and
compare against the predeclared oracles. Raw outputs are retained verbatim.

Outcome vocabulary (kept separate, never merged):
  consistent / inconsistent          -- ontology-level, from HermiT
  entailed / not_entailed            -- per query, only when HermiT answered
  satisfiable / unsatisfiable        -- per named class
  inconsistent_ontology              -- query status when the ontology is inconsistent (no Boolean)
  import_failure / load_failure / unsupported_construct / timeout / processing_failure
An expected value of null in the oracle means: the ontology is expected to be
inconsistent, so the query must report inconsistent_ontology.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "tools"))
from reasoner_backend import run_reasoner  # noqa: E402


def read(p):
    return json.loads(p.read_text(encoding="utf-8"))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--prov-variant", choices=["raw", "metadata_projection"], default="raw")
    args = ap.parse_args()
    oracle_path = HERE / "oracles.json"
    oracle_sha = hashlib.sha256(oracle_path.read_bytes()).hexdigest()
    oracles = read(oracle_path)["cases"]
    sources = {c["id"]: c for c in read(HERE / "source_manifest.json")["cases"]}
    out = HERE / "results" / args.prov_variant
    raw_dir = out / "raw"
    raw_dir.mkdir(parents=True, exist_ok=True)
    summary = {"oracle_sha256_before_execution": oracle_sha, "prov_variant": args.prov_variant,
               "meaning_of_false": "Not entailed by this input and backend; never an asserted negative fact.",
               "meaning_of_null": "Ontology expected inconsistent; the query must carry status inconsistent_ontology.",
               "cases": []}
    failures = []
    for stem, oracle in sorted(oracles.items()):
        onto = HERE / sources[stem]["input"]
        if hashlib.sha256(onto.read_bytes()).hexdigest() != sources[stem]["input_sha256"]:
            raise RuntimeError("Input changed after manifest: " + stem)
        manifest = read(HERE / "manifests" / (stem + ".json"))
        raw = run_reasoner(onto, manifest, raw_dir / (stem + ".json"), prov_variant=args.prov_variant, timeout=300)
        actual = {q["id"]: q for q in raw.get("entailments", [])}
        sat = {q["id"]: q for q in raw.get("satisfiability", [])}
        checks = []
        for i, exp in sorted(oracle["entailments"].items()):
            a = actual.get(i, {})
            if exp is None:
                ok = a.get("status") == "inconsistent_ontology"
            else:
                ok = a.get("status") in {"entailed", "not_entailed"} and a.get("value") is exp
            checks.append({"id": i, "expected": exp, "status": a.get("status", "missing"), "actual": a.get("value"), "matches": ok})
        for i, exp in sorted(oracle["satisfiability"].items()):
            a = sat.get(i, {})
            if exp is None:
                ok = a.get("status") == "inconsistent_ontology"
            else:
                ok = a.get("status") in {"satisfiable", "unsatisfiable"} and a.get("value") is exp
            checks.append({"id": i, "expected": exp, "status": a.get("status", "missing"), "actual": a.get("value"), "matches": ok})
        cons_ok = raw.get("status") in {"consistent", "inconsistent"} and raw.get("consistency", {}).get("value") is oracle["consistent"]
        ok = cons_ok and all(c["matches"] for c in checks)
        dl = raw.get("profiles", {}).get("OWL2_DL", {})
        row = {"id": stem, "description": oracle.get("description"), "backend_status": raw.get("status"),
               "expected_consistent": oracle["consistent"], "consistency": raw.get("consistency"),
               "owl2_dl_profile": {k: dl.get(k) for k in ("in_profile", "violation_count") if k in dl} if isinstance(dl, dict) else dl,
               "swrl_rule_count": raw.get("swrl_rule_count"), "checks": checks, "semantic_match": ok,
               "raw": f"raw/{stem}.json"}
        summary["cases"].append(row)
        if not ok:
            failures.append(stem)
    summary["failures"] = failures
    summary["case_count"] = len(summary["cases"])
    summary["semantic_matches"] = sum(1 for c in summary["cases"] if c["semantic_match"])
    (out / "report.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"prov_variant": args.prov_variant, "cases": summary["case_count"], "matches": summary["semantic_matches"], "failures": failures}, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
