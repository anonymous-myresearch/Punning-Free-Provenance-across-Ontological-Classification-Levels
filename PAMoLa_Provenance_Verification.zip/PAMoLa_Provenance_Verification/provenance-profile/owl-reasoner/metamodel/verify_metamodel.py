#!/usr/bin/env python3
"""Independently check recorded E4/E5 evidence without launching HermiT.

Raw answers are compared directly with oracles; summary matches flags are
checked, never trusted. Input, query, oracle and dependency hashes bind reports
to current files. This verifies recorded evidence, not an unexecuted reasoner.
"""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def read(p):
    return json.loads(p.read_text(encoding="utf-8"))


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def keyed(items, label, problems):
    result = {item.get("id"): item for item in items}
    if None in result or len(result) != len(items):
        problems.append(label + ": duplicate or missing IDs")
    return result


def check_case(stem, oracle, manifest, row, raw, arm, expected_runtime):
    """Pure comparison of one raw result with its oracle and summary row."""
    problems = []

    def require(condition, message):
        if not condition:
            problems.append(f"{arm}/{stem}: {message}")

    expected_status = "consistent" if oracle["consistent"] else "inconsistent"
    expected_consistency = {"status": expected_status, "value": oracle["consistent"]}
    require(raw.get("status") == expected_status, "unexpected backend status")
    require(raw.get("consistency") == expected_consistency, "raw consistency differs from oracle")
    require(raw.get("query_execution_status") == "complete", "incomplete query execution")
    require(not raw.get("blocked_imports"), "blocked import")
    require(not raw.get("reasoner_warnings"), "reasoner warning")
    require(raw.get("swrl_rule_count") == 0, "unexpected SWRL extension")
    for field, expected in expected_runtime.items():
        require(raw.get("runtime", {}).get(field) == expected, f"runtime {field} differs")
    require(raw.get("reasoner") == {"name": "HermiT", "version": "1.3.8.1099"}, "reasoner identity differs")
    imports = raw.get("imports_closure", [])
    require(len(imports) == 2 and any("http://www.w3.org/ns/prov#" in i.get("ontology_iri", "") for i in imports)
            and any("urn:pamola:owl-metamodel:" + stem in i.get("ontology_iri", "") for i in imports), "unexpected import closure")

    computed = []
    for field in ("entailments", "satisfiability"):
        queries = keyed(manifest.get(field, []), f"{arm}/{stem}/{field} manifest", problems)
        answers = keyed(raw.get(field, []), f"{arm}/{stem}/{field} raw", problems)
        expected_answers = oracle[field]
        require(set(queries) == set(expected_answers), field + " manifest/oracle IDs differ")
        require(set(answers) == set(expected_answers), field + " raw/oracle IDs differ")
        for query_id, expected in sorted(expected_answers.items()):
            answer, query = answers.get(query_id, {}), queries.get(query_id, {})
            if expected is None:
                status = "inconsistent_ontology"
                require(oracle["consistent"] is False, query_id + ": null expectation on consistent input")
            elif field == "entailments":
                status = "entailed" if expected else "not_entailed"
            else:
                status = "satisfiable" if expected else "unsatisfiable"
            matches = answer.get("status") == status and answer.get("value") is expected
            require(matches, f"{query_id}: expected {status}/{expected}, got {answer.get('status')}/{answer.get('value')}")
            if field == "entailments":
                require(answer.get("kind") == query.get("kind"), query_id + ": query kind differs")
            else:
                require(answer.get("class") == query.get("class"), query_id + ": queried class differs")
            computed.append({"id": query_id, "expected": expected, "status": answer.get("status", "missing"),
                             "actual": answer.get("value"), "matches": matches})
    require(row.get("checks") == computed, "summary checks differ from independently recomputed raw checks")
    require(row.get("backend_status") == raw.get("status"), "summary backend status differs")
    require(row.get("expected_consistent") is oracle["consistent"], "summary expected consistency differs")
    require(row.get("consistency") == raw.get("consistency"), "summary consistency differs")
    require(row.get("semantic_match") is (all(c["matches"] for c in computed)
            and raw.get("consistency") == expected_consistency and raw.get("status") == expected_status), "summary semantic_match differs")
    require(row.get("swrl_rule_count") == 0, "summary SWRL count differs")

    profile = raw.get("profiles", {}).get("OWL2_DL", {})
    summary_profile = {k: profile.get(k) for k in ("in_profile", "violation_count") if k in profile}
    require(row.get("owl2_dl_profile") == summary_profile, "summary DL profile differs")
    violations = profile.get("violations", [])
    require(profile.get("violation_count") == len(violations), "DL diagnostic count differs from diagnostics")
    if arm == "metadata_projection":
        require(profile.get("in_profile") is True and not violations, "projected input is not strict OWL 2 DL")
    else:
        expected_count = 14 if stem.startswith("E5-ctrl-pun__") else 17 if stem.startswith(("E4-S__", "E4-S1__")) else 15
        require(profile.get("in_profile") is False and len(violations) == expected_count, "unexpected raw DL profile outcome")
        allowed = {"http://www.w3.org/ns/prov#specializationOf", "http://www.w3.org/ns/prov#wasRevisionOf"}
        for diagnostic in violations:
            match = re.match(r"Cannot pun between properties: <([^>]+)>", diagnostic.get("message", ""))
            require(diagnostic.get("type") == "IllegalPunning" and match is not None and match.group(1) in allowed,
                    "unrecognised raw DL diagnostic")
    return problems


def verify(root=HERE):
    profile_root, backend = root.parent.parent, root.parent / "backend"
    oracle_path = root / "oracles.json"
    oracle_sha = sha256(oracle_path)
    oracles = read(oracle_path)["cases"]
    source_manifest = read(root / "source_manifest.json")
    problems = []
    sources = keyed(source_manifest["cases"], "source manifest", problems)
    if set(sources) != set(oracles):
        problems.append("source/oracle case IDs differ")
    canonical = profile_root.parent / source_manifest["canonical_source"]
    if sha256(canonical) != source_manifest["canonical_source_sha256"]:
        problems.append("canonical snapshot hash changed")
    dependencies = read(backend / "DEPENDENCIES.json")
    jar_sha = sha256(backend / dependencies["hermit"]["jar"])
    if jar_sha != dependencies["hermit"]["sha256"]:
        problems.append("HermiT dependency hash differs")
    projection_manifest = read(backend / "metadata-projection-manifest.json")
    raw_prov = profile_root / "dependencies" / "prov-o.ttl"
    projected_prov = backend / projection_manifest["projection"]
    if sha256(raw_prov) != dependencies["prov_o"]["sha256"] or sha256(raw_prov) != projection_manifest["source_sha256"]:
        problems.append("raw PROV dependency hash differs")
    if sha256(projected_prov) != projection_manifest["projection_sha256"]:
        problems.append("projected PROV dependency hash differs")

    summary, answer_signatures = {}, {}
    for arm in ("raw", "metadata_projection"):
        report = read(root / "results" / arm / "report.json")
        rows = keyed(report["cases"], arm + " summary", problems)
        if set(rows) != set(oracles):
            problems.append(arm + ": case set differs from oracles")
        if report.get("oracle_sha256_before_execution") != oracle_sha:
            problems.append(arm + ": oracle changed after execution")
        if report.get("prov_variant") != arm:
            problems.append(arm + ": report import variant differs")
        if report.get("case_count") != len(oracles) or report.get("semantic_matches") != len(oracles) or report.get("failures") != []:
            problems.append(arm + ": report summary counts or failure list differ")
        counts, query_counts, dl_ok = Counter(), Counter(), 0
        for stem, oracle in sorted(oracles.items()):
            if stem not in sources or stem not in rows:
                continue
            source, row = sources[stem], rows[stem]
            input_sha = sha256(root / source["input"])
            if input_sha != source["input_sha256"]:
                problems.append(stem + ": input hash changed")
            manifest = read(root / "manifests" / (stem + ".json"))
            manifest_sha = hashlib.sha256(json.dumps(manifest, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
            expected_raw = f"raw/{stem}.json"
            if row.get("raw") != expected_raw:
                problems.append(arm + "/" + stem + ": raw path differs")
            raw = read(root / "results" / arm / expected_raw)
            runtime = {"prov_import_variant": arm, "hermit_jar_sha256": jar_sha, "ontology_sha256": input_sha,
                       "manifest_sha256": manifest_sha, "prov_o_sha256": sha256(raw_prov if arm == "raw" else projected_prov),
                       "process_exit_code": 0}
            problems.extend(check_case(stem, oracle, manifest, row, raw, arm, runtime))
            counts[raw.get("status")] += 1
            for field in ("entailments", "satisfiability"):
                query_counts.update(q.get("status") for q in raw.get(field, []))
            dl_ok += raw.get("profiles", {}).get("OWL2_DL", {}).get("in_profile") is True
            signature = (raw.get("consistency"), raw.get("entailments"), raw.get("satisfiability"))
            if arm == "raw":
                answer_signatures[stem] = signature
            elif signature != answer_signatures.get(stem):
                problems.append(stem + ": import-arm semantic answers differ")
        expected_counts = Counter("consistent" if o["consistent"] else "inconsistent" for o in oracles.values())
        if counts != expected_counts:
            problems.append(arm + ": observed consistency counts differ from oracle counts")
        summary[arm] = {"cases": len(rows), "consistency_outcomes": dict(counts), "query_outcomes": dict(query_counts),
                        "owl2_dl_in_profile": dl_ok}
    summary["problems"] = problems
    return summary


def main():
    try:
        summary = verify()
    except (KeyError, TypeError, ValueError, OSError) as exc:
        print(json.dumps({"problems": [f"Malformed or missing evidence: {type(exc).__name__}: {exc}"]}, indent=2))
        return 1
    print(json.dumps(summary, indent=2))
    return 1 if summary["problems"] else 0


if __name__ == "__main__":
    sys.exit(main())
