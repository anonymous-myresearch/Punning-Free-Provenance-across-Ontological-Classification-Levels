# E1--E3 reasoner controls

These are explanatory semantic controls, not a complete OWL implementation of
the paper's review policy, and not a demonstration that RDF cannot express the
example. The backend loads ontology documents directly through OWLAPI and calls
the actual HermiT reasoner. Python does not simulate OWL inference.

## Source and permitted changes

`build_controls.py` takes all triples from each of the five named graphs in
`../../chart-baseline/snapshots.trig`, including `recategorisedType`. It does not
substitute a smaller newspaper example. The attribution, derivation, revision,
qualified-usage and category-scoped approval facts remain present. In particular,
`approvedType` remains an object property whose object identifies its category;
it is not replaced with a Boolean flag. The selected Listing 1 facts are already
in these canonical contexts.

`source_manifest.json` records the canonical file and context hashes, generated
input hashes and every added or removed RDF triple. Common additions are explicit
OWL declarations, an ontology identifier, and a real import of
`http://www.w3.org/ns/prov-o`. The backend resolves that import to the unchanged,
pinned complete `../../dependencies/prov-o.ttl`; its hash is in every raw report.
There is no substituted PROV fragment.

| Control | Additional change | Expected diagnostic |
| --- | --- | --- |
| E1 | None beyond common declarations/import | Chart membership in its definition is entailed; membership in the definition's category is not entailed. Definition attribution does not entail chart attribution. |
| E1-equality | A fresh class/individual alias and `owl:sameAs` between the two individual uses | Individual equality and the alias's individual attribution are entailed; class equivalence and chart membership in the alias class are not entailed. |
| E2 | Replace only v1's asserted category membership with a subclass axiom to that same category | Category membership of v1's charts is entailed. The removed individual membership of v1 is not entailed. This is the consequence of changing the model. |
| E3 | Add one fixed-class SWRL rule that copies v1's attribution to its instances | Alice's attribution is entailed for chart1 and chart2, alongside the retained attribution to Derek. The extra responsibility comes from the added rule. |

E3's actual RDF rule represents:

```
CrimeRateChart_v1(?x) AND wasAttributedTo(CrimeRateChart_v1,?a)
    -> wasAttributedTo(?x,?a)
```

It has a fixed class predicate, not a variable ranging over class predicates. The
backend parsed exactly one SWRL rule in each E3 input and returned the expected
additional attribution on the named charts. This checks the needed supported
rule behaviour; it is not a test of unrestricted SWRL reasoning. Attribution in
PROV concerns responsibility, so the diagnostic is unwanted propagation under
this example's intended policy, not a general claim that any such responsibility
assertion would violate PROV.

## Oracles and execution

The builder writes `oracles.json` before any reasoner call. Expectations are
authored from the semantic cases in `build_controls.py`, without reading backend
results. `run_controls.py` hashes those oracles before execution, checks every
input hash, executes the exact queries in `manifests/`, and verifies the oracle
file did not change. `results/raw/` retains every direct backend result, including
imports, profile violations, reasoner identity, satisfiability, consistency,
per-query statuses, dependency hashes and execution metadata.

From the package root, with Python requirements installed and Java available:

```
python provenance-profile/owl-reasoner/controls/verify_suite.py
```

This aggregate command executes both reasoner arms and the correspondence check,
then independently validates their raw outputs, source/query/import hashes,
oracle answers, profile diagnostics and summary reports. It does not rebuild
fixtures or rewrite oracles. `--check-reports` performs the same validation over
existing reports without launching the reasoner.

The suite's successful acceptance outcome is deliberately different from the
original experimental outcome: the initial raw-import expectation of DL
conformance failed in 15 cases and remains recorded. Acceptance now requires
that **exact documented finding**, not arbitrary profile failure. The suite
checks all 14 raw DL diagnostics are the known `IllegalPunning` messages about
the same two properties, with exact counts and message fingerprints. It also
checks the known RL diagnostics, including E3's rule-extension diagnostic, and
requires the projected rule-free inputs to pass the DL checker. Unsupported
queries, changed diagnostics, nonzero subprocess exits, altered inputs or hashes,
semantic mismatches, extra imports and missing results fail the suite. A passing
suite never labels the raw import or the SWRL extensions as strict OWL 2 DL.

For explicit fixture construction and individual execution, the commands are:

```
python provenance-profile/owl-reasoner/controls/build_controls.py
python provenance-profile/owl-reasoner/controls/run_controls.py
python provenance-profile/owl-reasoner/controls/prepare_projection_oracles.py
python provenance-profile/owl-reasoner/controls/run_controls.py --prov-variant metadata_projection
python provenance-profile/owl-reasoner/controls/compare_import_variants.py
```

Each import variant has 20 consistent inputs, 340 entailment queries and 65 named-class
satisfiability queries. All semantic expectations match. Every `false` answer
means **not entailed**; no negative class-membership or negative attribution
assertion is inferred. Import failures, unsupported constructs, timeouts and
processing errors have separate statuses and cannot count as negative answers.

No input supplies a review policy. The `no_policy_review_negative_control` query
therefore records an unsurprising non-entailment, not a failed result from a
fully specified OWL policy implementation. E1--E3 do not compare maintenance
cost, prove that flattening is required by OWL, or demonstrate an architectural
advantage over a correctly constrained OWL/RDF alternative. E4 is not implemented
or approximated here.

## Important full-import profile result

**The unchanged full PROV-O import is not reported as OWL 2 DL conformant by the
bundled OWLAPI profile checker.** All 20 controls receive 14 `IllegalPunning`
diagnostics involving `prov:specializationOf` and `prov:wasRevisionOf`. The pinned
ontology explicitly declares each IRI as both an `owl:AnnotationProperty` and an
`owl:ObjectProperty`. It also uses them on an `owl:Ontology` resource as document
metadata. The full imported ontology additionally fails the OWL 2 RL profile.

The initial expectation that the 15 E1/E1-equality/E2 inputs would pass the DL
profile was not met. That expectation remains in the predeclared oracle and the
15 failures are explicit in `results/report.json`. They are not silently changed
to passing expectations. E3 uses a rule extension and was never advertised as a
strict OWL 2 DL input.

HermiT did process these full-import inputs and returned the reported answers.
Reasoner success and consistency are separate from strict profile conformance.
Consequently these raw-import reports are **not certificates of strict OWL 2 DL
conformance**. They remain unchanged as a separate experimental arm.

## Separately declared projection for the DL comparison

The backend supplies `../backend/prov-o-metadata-projection.ttl` and an exact
`../backend/metadata-projection-manifest.json`. This projection omits only the
two `rdf:type owl:AnnotationProperty` declarations for the two conflicting IRIs.
Their object-property declarations, all application vocabulary axioms, every
provenance assertion and all ontology-document history statements are retained.
No canonical chart-snapshot fact is changed, omitted or replaced. This is a
declared input projection, not a silently modified copy of the full import.

`prepare_projection_oracles.py` writes a separate prospective oracle file,
`oracles_metadata_projection.json`, without reading any backend result. It
retains every original semantic answer, expects the 15 rule-free inputs to pass
the DL profile, and continues to identify the five E3 inputs as SWRL extensions.
The projection manifest's hash is fixed before execution and checked by the
runner. This arm uses precisely the same application-input files and query
manifests as the full-import arm, differing only in which explicitly named PROV
import variant the backend loads.

The projection arm is stored in `results/metadata-projection/`. All 20 inputs
pass the backend's DL profile checker, but **only the 15 rule-free inputs are
claimed as OWL 2 DL inputs**. The five E3 inputs contain SWRL rules, a language
extension not made part of OWL 2 DL by this checker's permissive profile result.
Their rule count and extension label are explicit in every summary row.

`results/import-variant-correspondence.json` compares the identical application
input hashes, consistency results and all declared entailment and satisfiability
answers between arms. All 20 case comparisons agree. This is correspondence for
these tested queries and inputs; it does not assert RDF-semantic equivalence of
the two PROV documents or agreement for arbitrary queries. In particular, the
two omitted annotation-property declarations distinguish their RDF graphs.
