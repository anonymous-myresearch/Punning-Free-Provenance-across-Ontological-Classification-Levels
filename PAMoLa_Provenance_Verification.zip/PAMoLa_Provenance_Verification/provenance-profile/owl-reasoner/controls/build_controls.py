#!/usr/bin/env python3
"""Build declared OWL controls from the unchanged canonical RDF snapshots.

This command writes inputs and independently specified expected answers only.
It does not invoke a reasoner or inspect reasoner output.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from rdflib import BNode, Dataset, Graph, Literal, Namespace, RDF, RDFS, URIRef
from rdflib.namespace import OWL, XSD

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent.parent / "chart-baseline" / "snapshots.trig"
EX = Namespace("https://example.org/provenance-chart/")
PROV = Namespace("http://www.w3.org/ns/prov#")
SWRL = Namespace("http://www.w3.org/2003/11/swrl#")
CONTEXTS = ["beforeWithdrawal", "afterWithdrawal", "incompleteRegistry", "newChartType", "recategorisedType"]
T = EX.CrimeRateChart_v1
ALIAS = EX.CrimeRateChart_v1_alias


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def ntriple(t):
    return " ".join(x.n3() for x in t) + " ."


def ordered_nt(g):
    return "\n".join(sorted(ntriple(t) for t in g)) + "\n"


def collection(g, name, members):
    if not members:
        return RDF.nil
    nodes = [BNode(f"{name}{i}") for i in range(len(members))]
    for i, item in enumerate(members):
        g.add((nodes[i], RDF.first, item))
        g.add((nodes[i], RDF.rest, nodes[i + 1] if i + 1 < len(nodes) else RDF.nil))
    return nodes[0]


def add_swrl(g):
    """One deliberately class-specific propagation rule; no class variables."""
    x, a = EX.ruleVariable_x, EX.ruleVariable_agent
    g.add((x, RDF.type, SWRL.Variable))
    g.add((a, RDF.type, SWRL.Variable))
    c, p, h, rule = (BNode(n) for n in ["bodyClass", "bodyAttribution", "headAttribution", "propagateAttribution"])
    for atom in [p, h]:
        g.add((atom, RDF.type, SWRL.IndividualPropertyAtom))
        g.add((atom, SWRL.propertyPredicate, PROV.wasAttributedTo))
    g.add((c, RDF.type, SWRL.ClassAtom))
    g.add((c, SWRL.classPredicate, T))
    g.add((c, SWRL.argument1, x))
    g.add((p, SWRL.argument1, T))
    g.add((p, SWRL.argument2, a))
    g.add((h, SWRL.argument1, x))
    g.add((h, SWRL.argument2, a))
    g.add((rule, RDF.type, SWRL.Imp))
    g.add((rule, SWRL.body, collection(g, "bodyList", [c, p])))
    g.add((rule, SWRL.head, collection(g, "headList", [h])))


def manifest_and_expected(context, case, category):
    qs, expected = [], {}
    def q(identifier, kind, answer, **kw):
        qs.append({"id": identifier, "kind": kind, **{k: str(v) for k, v in kw.items()}})
        expected[identifier] = answer
    q("chart1_has_definition", "class_assertion", True, individual=EX.chart1, **{"class": T})
    q("definition_in_current_category", "class_assertion", case != "E2", individual=T, **{"class": category})
    q("chart1_in_current_category", "class_assertion", case == "E2", individual=EX.chart1, **{"class": category})
    q("definition_attributed_to_alice", "object_property_assertion", True, subject=T, property=PROV.wasAttributedTo, object=EX.Alice)
    q("chart1_attributed_to_derek", "object_property_assertion", True, subject=EX.chart1, property=PROV.wasAttributedTo, object=EX.Derek)
    q("chart1_attributed_to_alice", "object_property_assertion", case == "E3", subject=EX.chart1, property=PROV.wasAttributedTo, object=EX.Alice)
    q("chart2_attributed_to_alice", "object_property_assertion", case == "E3", subject=EX.chart2, property=PROV.wasAttributedTo, object=EX.Alice)
    q("definition_derived_from_guideline", "object_property_assertion", True, subject=T, property=PROV.wasDerivedFrom, object=EX.guideline1)
    q("chart1_derived_from_data", "object_property_assertion", True, subject=EX.chart1, property=PROV.wasDerivedFrom, object=EX.data1)
    q("chart1_derived_from_guideline", "object_property_assertion", False, subject=EX.chart1, property=PROV.wasDerivedFrom, object=EX.guideline1)
    q("article1_derived_from_chart1", "object_property_assertion", True, subject=EX.article1, property=PROV.wasDerivedFrom, object=EX.chart1)
    q("approval_category_v2", "object_property_assertion", True, subject=EX.CrimeRateChart_v2, property=EX.approvedType, object=EX.StatisticalChartType)
    q("approval_category_v1_statistical", "object_property_assertion", context in {"beforeWithdrawal", "recategorisedType"}, subject=T, property=EX.approvedType, object=EX.StatisticalChartType)
    q("approval_category_v1_current", "object_property_assertion", context == "beforeWithdrawal", subject=T, property=EX.approvedType, object=category)
    q("registry_complete", "data_property_assertion", context != "incompleteRegistry", subject=category, property=EX.completeApprovalRegistry, value="true", datatype=XSD.boolean)
    # These inputs intentionally contain no review policy. This is a negative
    # control, never a test that a complete OWL policy implementation has failed.
    q("no_policy_review_negative_control", "class_assertion", False, individual=EX.chart1, **{"class": EX.RequiresReview})
    if case == "E1-equality":
        q("individual_equality", "same_individual", True, left=T, right=ALIAS)
        q("class_equivalence", "equivalent_classes", False, left=T, right=ALIAS)
        q("chart1_has_alias_class", "class_assertion", False, individual=EX.chart1, **{"class": ALIAS})
        q("alias_individual_attribution", "object_property_assertion", True, subject=ALIAS, property=PROV.wasAttributedTo, object=EX.Alice)
    classes = [T, category, EX.RequiresReview] + ([ALIAS] if case == "E1-equality" else [])
    manifest = {"entailments": qs, "satisfiability": [{"id": "satisfiable_" + str(c).rsplit("/", 1)[-1], "class": str(c)} for c in classes]}
    oracle = {"consistent": True, "entailments": expected, "satisfiability": {s["id"]: True for s in manifest["satisfiability"]}, "owl2_dl_expected": case != "E3", "policy_present": False}
    return manifest, oracle


def build():
    ds = Dataset()
    ds.parse(SOURCE, format="trig")
    inputs = HERE / "inputs"
    manifests = HERE / "manifests"
    inputs.mkdir(exist_ok=True)
    manifests.mkdir(exist_ok=True)
    provenance = {"canonical_source": str(SOURCE.relative_to(HERE.parent.parent.parent)), "canonical_source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(), "cases": []}
    oracles = {"written_before_reasoner_execution": True, "expectation_source": "Authored expectations in build_controls.py; not inferred from backend results.", "cases": {}}
    for context in CONTEXTS:
        original = Graph()
        for triple in ds.graph(EX[context]):
            original.add(triple)
        categories = list(original.objects(T, RDF.type))
        if len(categories) != 1:
            raise ValueError(f"Expected one canonical category for {context}: {categories}")
        category = categories[0]
        for case in ["E1", "E1-equality", "E2", "E3"]:
            stem = f"{case}__{context}"
            g = Graph()
            for triple in original:
                g.add(triple)
            # Every change to the canonical graph appears in source_manifest.json.
            ontology = URIRef("urn:pamola:owl-controls:" + stem)
            g.add((ontology, RDF.type, OWL.Ontology))
            g.add((ontology, OWL.imports, URIRef("http://www.w3.org/ns/prov-o")))
            classes = set(original.objects(None, RDF.type))
            for c in classes | {EX.RequiresReview}:
                g.add((c, RDF.type, OWL.Class))
            for node in set(original.subjects()) | {o for o in original.objects() if isinstance(o, URIRef) and str(o).startswith(str(EX))}:
                g.add((node, RDF.type, OWL.NamedIndividual))
            for prop in [EX.requiresApproval, EX.completeApprovalRegistry]:
                g.add((prop, RDF.type, OWL.DatatypeProperty))
            g.add((EX.approvedType, RDF.type, OWL.ObjectProperty))
            if case == "E1-equality":
                g.add((ALIAS, RDF.type, OWL.Class))
                g.add((ALIAS, RDF.type, OWL.NamedIndividual))
                g.add((T, OWL.sameAs, ALIAS))
            if case == "E2":
                g.remove((T, RDF.type, category))
                g.add((T, RDFS.subClassOf, category))
            if case == "E3":
                add_swrl(g)
            # N-Triples is also a Turtle document. Fixed blank-node labels and
            # sorted triples avoid serializer order and blank-node randomness.
            payload = ordered_nt(g)
            target = inputs / f"{stem}.ttl"
            target.write_text(payload, encoding="utf-8")
            manifest, oracle = manifest_and_expected(context, case, category)
            dump(manifests / f"{stem}.json", manifest)
            oracles["cases"][stem] = oracle
            additions = sorted(ntriple(t) for t in set(g) - set(original))
            removals = sorted(ntriple(t) for t in set(original) - set(g))
            provenance["cases"].append({"id": stem, "context": str(EX[context]), "canonical_triples": len(original), "canonical_context_sha256": hashlib.sha256(ordered_nt(original).encode()).hexdigest(), "input": str(target.relative_to(HERE)), "input_sha256": hashlib.sha256(payload.encode()).hexdigest(), "current_category": str(category), "added_triples": additions, "removed_triples": removals, "rule": "CrimeRateChart_v1(?x) AND wasAttributedTo(CrimeRateChart_v1,?a) -> wasAttributedTo(?x,?a)" if case == "E3" else None})
    dump(HERE / "source_manifest.json", provenance)
    dump(HERE / "oracles.json", oracles)
    print(f"Built {len(provenance['cases'])} controls and predeclared oracles from five canonical contexts.")


if __name__ == "__main__":
    build()
