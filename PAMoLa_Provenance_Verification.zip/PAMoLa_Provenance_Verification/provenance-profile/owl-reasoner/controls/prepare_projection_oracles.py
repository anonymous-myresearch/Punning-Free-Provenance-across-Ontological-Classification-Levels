#!/usr/bin/env python3
"""Write prospective oracles for the explicitly declared PROV-O projection.

No backend report or reasoner result is read by this command. All original
semantic expectations are retained. The 15 rule-free inputs are now expected to
pass the DL profile. The five E3 inputs remain explicitly labelled SWRL extensions
regardless of the profile checker's treatment of rules.
"""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
source = HERE / "oracles.json"
manifest = HERE.parent / "backend" / "metadata-projection-manifest.json"
original = json.loads(source.read_text(encoding="utf-8"))
result = {
    "written_before_reasoner_execution": True,
    "expectation_source": "Prospectively authored projection expectations; all original semantic oracle answers retained without reading backend results.",
    "original_oracles_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "projection_manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(),
    "profile_expectation": "The 15 rule-free controls should pass OWL 2 DL. E3 is a SWRL extension; no strict OWL 2 DL claim or checker expectation is made for those five inputs.",
    "cases": original["cases"],
}
for identifier, case in result["cases"].items():
    case["checker_dl_expectation"] = True if not identifier.startswith("E3__") else None
    case["strict_owl2_dl_claim"] = not identifier.startswith("E3__")
target = HERE / "oracles_metadata_projection.json"
target.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print("Wrote prospective projection oracles for 15 rule-free inputs and 5 explicit SWRL extensions.")
