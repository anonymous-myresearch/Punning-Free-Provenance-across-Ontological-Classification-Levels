#!/usr/bin/env python3
"""Execute the E1--E3 predeclared controls with the shared OWLAPI backend.

Raw backend errors are not converted to negative entailment answers. Profile
conformance is reported separately from consistency and semantic oracle checks.
"""
from __future__ import annotations

import hashlib
import json
import argparse
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "tools"))
from reasoner_backend import run_reasoner


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prov-variant", choices=["raw", "metadata_projection"], default="raw")
    args = parser.parse_args()
    projected = args.prov_variant == "metadata_projection"
    oracle_path = HERE / ("oracles_metadata_projection.json" if projected else "oracles.json")
    oracle_sha = hashlib.sha256(oracle_path.read_bytes()).hexdigest()
    oracle_document = read(oracle_path)
    oracles = oracle_document["cases"]
    if projected:
        projection_manifest = HERE.parent / "backend" / "metadata-projection-manifest.json"
        if hashlib.sha256(projection_manifest.read_bytes()).hexdigest() != oracle_document["projection_manifest_sha256"]:
            raise RuntimeError("Projection manifest changed after prospective oracles were written")
    sources = {c["id"]: c for c in read(HERE / "source_manifest.json")["cases"]}
    results_dir = HERE / "results" / "metadata-projection" if projected else HERE / "results"
    raw_dir = results_dir / "raw"
    raw_dir.mkdir(parents=True, exist_ok=True)
    summary = {
        "oracle_sha256_before_execution": oracle_sha,
        "prov_variant": args.prov_variant,
        "meaning_of_false": "Not entailed by this input and backend; never an asserted negative fact.",
        "review_negative_control": "No review policy is included. Absence of a review entailment is not evidence against a full OWL policy solution.",
        "profile_warning": "A separately declared PROV-O projection omitting exactly two annotation-property declarations is imported; the unchanged full-import controls are retained separately." if projected else "Unmodified full PROV-O is imported. Profile diagnostics must not be silently repaired or confused with reasoning success.",
        "cases": [],
    }
    failures = []
    for stem, oracle in sorted(oracles.items()):
        ontology = HERE / sources[stem]["input"]
        actual_sha = hashlib.sha256(ontology.read_bytes()).hexdigest()
        if actual_sha != sources[stem]["input_sha256"]:
            raise RuntimeError("Input changed after its manifest: " + stem)
        manifest_path = HERE / "manifests" / (stem + ".json")
        manifest = read(manifest_path)
        raw = run_reasoner(ontology, manifest, raw_dir / (stem + ".json"), prov_variant=args.prov_variant)
        actual = {q["id"]: q for q in raw.get("entailments", [])}
        sat_actual = {q["id"]: q for q in raw.get("satisfiability", [])}
        checks = []
        for identifier, expected in sorted(oracle["entailments"].items()):
            a = actual.get(identifier, {})
            ok = a.get("status") in {"entailed", "not_entailed"} and a.get("value") is expected
            checks.append({"id": identifier, "expected": expected, "status": a.get("status", "missing"), "actual": a.get("value"), "matches": ok})
        sat_checks = []
        for identifier, expected in sorted(oracle["satisfiability"].items()):
            a = sat_actual.get(identifier, {})
            ok = a.get("status") in {"satisfiable", "unsatisfiable"} and a.get("value") is expected
            sat_checks.append({"id": identifier, "expected": expected, "status": a.get("status", "missing"), "actual": a.get("value"), "matches": ok})
        consistent = raw.get("consistency", {}).get("value") is oracle["consistent"]
        semantic_match = raw.get("status") == "consistent" and consistent and all(c["matches"] for c in checks + sat_checks)
        row = {
            "id": stem,
            "input_sha256": actual_sha,
            "backend_status": raw.get("status"),
            "reasoner": raw.get("reasoner"),
            "swrl_rule_count": raw.get("swrl_rule_count"),
            "imports_closure": raw.get("imports_closure"),
            "consistency": raw.get("consistency"),
            "profiles": raw.get("profiles"),
            "entailments": checks,
            "satisfiability": sat_checks,
            "semantic_oracles_match": semantic_match,
            "strict_dl_profile_expected_in_initial_oracle": oracle["owl2_dl_expected"],
            "strict_dl_profile_expectation_met": (raw.get("profiles", {}).get("OWL2_DL", {}).get("in_profile") is True) if oracle["owl2_dl_expected"] else None,
            "strict_owl2_dl_claim": projected and oracle["owl2_dl_expected"] and raw.get("profiles", {}).get("OWL2_DL", {}).get("in_profile") is True and raw.get("swrl_rule_count") == 0,
            "rule_language_extension": "SWRL; supported named-input control, not an OWL 2 DL syntax claim" if stem.startswith("E3__") else None,
            "strict_dl_conformance_conditions_met": raw.get("profiles", {}).get("OWL2_DL", {}).get("in_profile") is True and raw.get("swrl_rule_count") == 0,
        }
        if not semantic_match:
            failures.append(stem)
        summary["cases"].append(row)
        print(stem + ": " + str(raw.get("status")) + "; semantic oracles " + ("match" if semantic_match else "FAIL") + "; OWL2_DL=" + str(raw.get("profiles", {}).get("OWL2_DL", {}).get("in_profile")), flush=True)
    if hashlib.sha256(oracle_path.read_bytes()).hexdigest() != oracle_sha:
        raise RuntimeError("Oracles changed during execution")
    summary["totals"] = {
        "cases": len(summary["cases"]),
        "consistent": sum(c["consistency"] and c["consistency"].get("value") is True for c in summary["cases"]),
        "semantic_oracle_matches": sum(c["semantic_oracles_match"] for c in summary["cases"]),
        "entailment_queries": sum(len(c["entailments"]) for c in summary["cases"]),
        "satisfiability_queries": sum(len(c["satisfiability"]) for c in summary["cases"]),
        "owl2_dl_in_profile": sum(c["profiles"] and c["profiles"]["OWL2_DL"]["in_profile"] for c in summary["cases"]),
        "initial_strict_dl_expectation_failures": sum(c["strict_dl_profile_expectation_met"] is False for c in summary["cases"]),
        "strict_dl_conformance_conditions_met": sum(c["strict_dl_conformance_conditions_met"] for c in summary["cases"]),
        "swrl_extension_inputs": sum(c["swrl_rule_count"] == 1 for c in summary["cases"]),
    }
    summary["status"] = "semantic_oracle_failure" if failures else ("semantic_oracles_match_with_profile_nonconformance" if summary["totals"]["owl2_dl_in_profile"] < len(summary["cases"]) else "semantic_oracles_match_with_explicit_rule_extensions")
    summary["semantic_failures"] = failures
    (results_dir / "report.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary["totals"], sort_keys=True))
    # This is a semantic-oracle runner, not a certificate of DL conformance.
    # Its explicit status and profile diagnostics retain conformance failures.
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
