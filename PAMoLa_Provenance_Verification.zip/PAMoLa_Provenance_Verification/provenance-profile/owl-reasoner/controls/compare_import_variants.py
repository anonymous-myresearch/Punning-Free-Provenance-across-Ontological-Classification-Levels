#!/usr/bin/env python3
"""Compare tested query answers, never assert whole-graph semantic equivalence."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
projection_manifest = json.loads((HERE.parent / "backend" / "metadata-projection-manifest.json").read_text())
raw = json.loads((HERE / "results" / "report.json").read_text())
projected = json.loads((HERE / "results" / "metadata-projection" / "report.json").read_text())
a = {c["id"]: c for c in raw["cases"]}
b = {c["id"]: c for c in projected["cases"]}
if set(a) != set(b):
    raise SystemExit("Case sets differ")
cases = []
for identifier in sorted(a):
    x, y = a[identifier], b[identifier]
    raw_backend = json.loads((HERE / "results" / "raw" / (identifier + ".json")).read_text())
    projected_backend = json.loads((HERE / "results" / "metadata-projection" / "raw" / (identifier + ".json")).read_text())
    def answers(c, key):
        return {v["id"]: {k: v.get(k) for k in ["status", "actual", "expected"]} for v in c[key]}
    row = {
        "id": identifier,
        "identical_application_input_hash": x["input_sha256"] == y["input_sha256"],
        "same_consistency_result": x["consistency"] == y["consistency"],
        "same_entailment_answers_and_statuses": answers(x, "entailments") == answers(y, "entailments"),
        "same_satisfiability_answers_and_statuses": answers(x, "satisfiability") == answers(y, "satisfiability"),
        "both_semantic_oracles_match": x["semantic_oracles_match"] and y["semantic_oracles_match"],
        "raw_import_hash_matches_manifest": raw_backend["runtime"]["prov_o_sha256"] == projection_manifest["source_sha256"],
        "projection_import_hash_matches_manifest": projected_backend["runtime"]["prov_o_sha256"] == projection_manifest["projection_sha256"],
        "raw_dl_checker_in_profile": x["profiles"]["OWL2_DL"]["in_profile"],
        "projection_dl_checker_in_profile": y["profiles"]["OWL2_DL"]["in_profile"],
        "swrl_extension": y["swrl_rule_count"] == 1,
    }
    row["matches"] = all(row[k] for k in ["identical_application_input_hash", "same_consistency_result", "same_entailment_answers_and_statuses", "same_satisfiability_answers_and_statuses", "both_semantic_oracles_match", "raw_import_hash_matches_manifest", "projection_import_hash_matches_manifest"])
    cases.append(row)
report = {
    "scope": "Agreement of the declared 340 entailment and 65 satisfiability query results and consistency results over these 20 identical application inputs only; no equivalence of the full RDF graphs or arbitrary queries is asserted.",
    "cases": cases,
    "all_tested_answers_match": all(c["matches"] for c in cases),
    "case_count": len(cases),
    "raw_prov_sha256": projection_manifest["source_sha256"],
    "projection_prov_sha256": projection_manifest["projection_sha256"],
}
target = HERE / "results" / "import-variant-correspondence.json"
target.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(f"Tested-answer correspondence: {sum(c['matches'] for c in cases)}/{len(cases)} cases.")
raise SystemExit(0 if report["all_tested_answers_match"] else 1)
