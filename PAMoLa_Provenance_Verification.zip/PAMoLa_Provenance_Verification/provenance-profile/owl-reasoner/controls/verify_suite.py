#!/usr/bin/env python3
"""Run and verify both reasoner-control arms, retaining the original finding.

Default: execute both arms and their correspondence check before validation.
--check-reports: validate the existing reports without launching the backend.
Neither mode rebuilds inputs, rewrites oracles, or edits the PROV documents.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HERE = Path(__file__).resolve().parent
RESULTS = HERE / "results"
ROOT = HERE.parent.parent.parent
CONTEXTS = {"beforeWithdrawal", "afterWithdrawal", "incompleteRegistry", "newChartType", "recategorisedType"}
CASES = {f"{kind}__{context}" for kind in ["E1", "E1-equality", "E2", "E3"] for context in CONTEXTS}
PINNED_JAR_SHA256 = "97e53f519720a0a2e328556e03b806aa239347c85e57637a935e6433ed2ad3a8"

# These are acceptance criteria for the now-documented profile finding, not
# replacements for the original pre-execution semantic/profile expectations.
# Fingerprints fix every diagnostic message, rather than accepting arbitrary
# failures with a convenient type or a successful process exit.
RAW_DL_DIAGNOSTICS_SHA256 = "4bc0b9396feb4dc0a2f4f21afc91bfb12a4452038ea793769a107344edb375cd"
RL_DIAGNOSTICS_SHA256 = {
    ("raw", False): "b4c56e0decf4a97194a543649e1750040d2febf38021e93ecd701b6294156f10",
    ("raw", True): "f86f8958b5697505e5a08b195c78e1b6ddab386c941b4513b76e96d276d45e28",
    ("metadata_projection", False): "fbbf0914d6830914d7533b0572975a64831db04dfe1b76a0e3c5548cb6bcbbc8",
    ("metadata_projection", True): "fb9d2851b363cd5ddec8c4611ce17f6512e86782d351764d0ada7bbe920bb5b1",
}


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def require(condition, description):
    if not condition:
        raise ValueError(description)


def check_profile(raw, projected, swrl, label):
    profiles = raw["profiles"]
    require(set(profiles) == {"OWL2_DL", "OWL2_RL"}, label + ": unexpected profile set")
    dl = profiles["OWL2_DL"]
    if projected:
        require(dl == {"in_profile": True, "violation_count": 0, "violations": []}, label + ": projected DL profile changed")
    else:
        require(dl["in_profile"] is False and dl["violation_count"] == 14 and len(dl["violations"]) == 14, label + ": raw DL profile finding changed")
        counts = Counter()
        for v in dl["violations"]:
            require(v["type"] == "IllegalPunning", label + ": unexpected DL violation type")
            match = re.match(r"Cannot pun between properties: <(http://www\.w3\.org/ns/prov#(?:specializationOf|wasRevisionOf))>", v["message"])
            require(match is not None, label + ": unexpected punning subject/message")
            counts[match.group(1)] += 1
        require(counts == {"http://www.w3.org/ns/prov#specializationOf": 6, "http://www.w3.org/ns/prov#wasRevisionOf": 8}, label + ": unexpected punning diagnostic counts")
        require(json_digest(dl["violations"]) == RAW_DL_DIAGNOSTICS_SHA256, label + ": a raw DL diagnostic changed")
    rl = profiles["OWL2_RL"]
    expected = Counter({"UseOfNonSuperClassExpression": 7})
    if not projected:
        expected["IllegalPunning"] = 14
    if swrl:
        expected["UseOfIllegalAxiom"] = 1
    require(rl["in_profile"] is False and rl["violation_count"] == sum(expected.values()), label + ": RL finding changed")
    require(Counter(v["type"] for v in rl["violations"]) == expected, label + ": unexpected RL violation")
    variant = "metadata_projection" if projected else "raw"
    diagnostics = rl["violations"]
    if swrl:
        # The single rule diagnostic includes its owning ontology IRI. Only
        # that known case identifier is normalised, never the rule or error.
        identifier = label.split(":", 1)[1]
        diagnostics = [dict(v, message=v["message"].replace("urn:pamola:owl-controls:" + identifier, "urn:pamola:owl-controls:E3__CONTROL")) for v in diagnostics]
    require(json_digest(diagnostics) == RL_DIAGNOSTICS_SHA256[(variant, swrl)], label + ": an RL diagnostic changed")


def check_arm(projected, sources, projection):
    variant = "metadata_projection" if projected else "raw"
    directory = RESULTS / "metadata-projection" if projected else RESULTS
    oracle_path = HERE / ("oracles_metadata_projection.json" if projected else "oracles.json")
    oracle_document = load(oracle_path)
    oracles = oracle_document["cases"]
    require(set(oracles) == CASES, variant + ": oracle case set changed")
    report = load(directory / "report.json")
    require(report["prov_variant"] == variant, variant + ": incorrect report label")
    require(report["oracle_sha256_before_execution"] == digest(oracle_path), variant + ": oracle hash changed after execution")
    require(report["semantic_failures"] == [], variant + ": semantic failures were reported")
    rows = {c["id"]: c for c in report["cases"]}
    require(len(report["cases"]) == 20 and set(rows) == CASES, variant + ": result case set changed")
    if projected:
        require(oracle_document["original_oracles_sha256"] == digest(HERE / "oracles.json"), "Projection oracles no longer refer to unchanged original oracles")
        require(oracle_document["projection_manifest_sha256"] == digest(HERE.parent / "backend" / "metadata-projection-manifest.json"), "Projection manifest changed after prospective oracles")
    queries, sat_queries = 0, 0
    for identifier in sorted(CASES):
        label = variant + ":" + identifier
        swrl = identifier.startswith("E3__")
        row, oracle = rows[identifier], oracles[identifier]
        raw = load(directory / "raw" / (identifier + ".json"))
        manifest = load(HERE / "manifests" / (identifier + ".json"))
        runtime = raw["runtime"]
        require(raw["status"] == "consistent" and raw["consistency"] == {"status": "consistent", "value": True}, label + ": backend/consistency failure")
        require(not raw.get("error") and raw["blocked_imports"] == [] and runtime["process_exit_code"] == 0, label + ": backend/import/process failure")
        require(runtime["prov_import_variant"] == variant, label + ": wrong PROV variant loaded")
        require(runtime["prov_o_sha256"] == projection["projection_sha256" if projected else "source_sha256"], label + ": incorrect imported PROV hash")
        require(runtime["hermit_jar_sha256"] == PINNED_JAR_SHA256, label + ": backend dependency hash changed")
        require(raw["reasoner"]["name"] == "HermiT" and raw["reasoner"]["version"] == "1.3.8.1099", label + ": unexpected reasoner/version")
        payload = json.dumps(manifest, sort_keys=True, ensure_ascii=False).encode()
        require(runtime["manifest_sha256"] == hashlib.sha256(payload).hexdigest(), label + ": query manifest changed")
        require(runtime["ontology_sha256"] == sources[identifier]["input_sha256"] == row["input_sha256"], label + ": ontology hash differs")
        require(len(raw["imports_closure"]) == 2 and any("<http://www.w3.org/ns/prov#>" in x["ontology_iri"] and "<http://www.w3.org/ns/prov-o-20130430>" in x["ontology_iri"] for x in raw["imports_closure"]), label + ": expected full import missing or extra imports present")
        require(raw["swrl_rule_count"] == (1 if swrl else 0), label + ": unexpected rule count")
        check_profile(raw, projected, swrl, label)
        for key, allowed in [("entailments", {"entailed", "not_entailed"}), ("satisfiability", {"satisfiable", "unsatisfiable"})]:
            actual = {q["id"]: q for q in raw[key]}
            summary = {q["id"]: q for q in row[key]}
            expected = oracle[key]
            require(len(actual) == len(raw[key]) and set(actual) == set(expected) == set(summary), label + ": query IDs changed")
            for qid, expectation in expected.items():
                answer, saved = actual[qid], summary[qid]
                require(answer["status"] in allowed and answer.get("value") is expectation and not answer.get("error"), label + ": semantic query failed: " + qid)
                require(saved["status"] == answer["status"] and saved["actual"] is expectation and saved["expected"] is expectation and saved["matches"] is True, label + ": summary differs from backend/oracle: " + qid)
        queries += len(raw["entailments"])
        sat_queries += len(raw["satisfiability"])
        require(row["profiles"] == raw["profiles"] and row["semantic_oracles_match"] is True, label + ": summary profile/semantic mismatch")
        require(row["strict_owl2_dl_claim"] is (projected and not swrl), label + ": invalid strict-DL claim")
        require(row["strict_dl_conformance_conditions_met"] is (projected and not swrl), label + ": invalid strict-DL classification")
        require(row["strict_dl_profile_expected_in_initial_oracle"] is (not swrl), label + ": original/prospective expectation was relabelled")
        require(row["strict_dl_profile_expectation_met"] is (None if swrl else projected), label + ": profile expectation outcome changed")
        require(bool(row["rule_language_extension"]) is swrl, label + ": rule extension label missing or spurious")
    require(queries == 340 and sat_queries == 65, variant + ": query counts changed")
    expected_totals = {"cases": 20, "consistent": 20, "semantic_oracle_matches": 20, "entailment_queries": 340, "satisfiability_queries": 65, "owl2_dl_in_profile": 20 if projected else 0, "initial_strict_dl_expectation_failures": 0 if projected else 15, "strict_dl_conformance_conditions_met": 15 if projected else 0, "swrl_extension_inputs": 5}
    require(report["totals"] == expected_totals, variant + ": reported totals differ from validated results")
    require(report["status"] == ("semantic_oracles_match_with_explicit_rule_extensions" if projected else "semantic_oracles_match_with_profile_nonconformance"), variant + ": unexpected aggregate status")
    return {"variant": variant, "semantic_cases": 20, "entailment_queries": queries, "satisfiability_queries": sat_queries, "initial_unmet_dl_expectations_retained": 0 if projected else 15, "strict_dl_inputs": 15 if projected else 0, "swrl_extensions": 5}


def validate():
    provenance = load(HERE / "source_manifest.json")
    require(digest(ROOT / provenance["canonical_source"]) == provenance["canonical_source_sha256"], "Canonical source changed")
    sources = {c["id"]: c for c in provenance["cases"]}
    require(len(provenance["cases"]) == 20 and set(sources) == CASES, "Source case set changed")
    for identifier, source in sources.items():
        require(digest(HERE / source["input"]) == source["input_sha256"], "Generated control input changed: " + identifier)
    projection_path = HERE.parent / "backend" / "metadata-projection-manifest.json"
    projection = load(projection_path)
    backend = projection_path.parent
    require(digest(backend / projection["source"]) == projection["source_sha256"], "Raw PROV source hash changed")
    require(digest(backend / projection["projection"]) == projection["projection_sha256"], "PROV projection hash changed")
    require(digest(backend / "lib" / "HermiT.jar") == PINNED_JAR_SHA256, "Reasoner jar changed")
    expected_removals = {("http://www.w3.org/ns/prov#" + p, "http://www.w3.org/1999/02/22-rdf-syntax-ns#type", "http://www.w3.org/2002/07/owl#AnnotationProperty") for p in ["specializationOf", "wasRevisionOf"]}
    require(projection["added_triples"] == [] and {(t["subject"], t["predicate"], t["object"]) for t in projection["removed_triples"]} == expected_removals and len(projection["removed_triples"]) == 2 and projection["source_unchanged"] is True, "Unexpected projection transformation")
    arms = [check_arm(False, sources, projection), check_arm(True, sources, projection)]
    comparison = load(RESULTS / "import-variant-correspondence.json")
    require(comparison["case_count"] == 20 and comparison["all_tested_answers_match"] is True, "Import comparison failed")
    require({c["id"] for c in comparison["cases"]} == CASES and len(comparison["cases"]) == 20, "Comparison case set changed")
    for case in comparison["cases"]:
        require(all(case[k] is True for k in ["matches", "identical_application_input_hash", "same_consistency_result", "same_entailment_answers_and_statuses", "same_satisfiability_answers_and_statuses", "both_semantic_oracles_match", "raw_import_hash_matches_manifest", "projection_import_hash_matches_manifest"]), "Comparison mismatch: " + case["id"])
    return arms


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check-reports", action="store_true", help="Validate existing outputs without executing reasoner processes")
    args = parser.parse_args()
    results = {"status": "failed", "mode": "existing_reports" if args.check_reports else "executed", "meaning": "Acceptance of the exactly documented finding does not erase the 15 original raw-import profile-expectation failures or claim raw strict-DL conformance."}
    try:
        if not args.check_reports:
            transcript = []
            commands = [[sys.executable, str(HERE / "run_controls.py")], [sys.executable, str(HERE / "run_controls.py"), "--prov-variant", "metadata_projection"], [sys.executable, str(HERE / "compare_import_variants.py")]]
            for command in commands:
                process = subprocess.run(command, text=True, capture_output=True, timeout=300)
                transcript.append("COMMAND: " + " ".join(command) + "\nEXIT: " + str(process.returncode) + "\n" + process.stdout + process.stderr)
                RESULTS.mkdir(exist_ok=True)
                (RESULTS / "suite-execution.log").write_text("\n".join(transcript), encoding="utf-8")
                require(process.returncode == 0, "Control command failed; see results/suite-execution.log")
        results["arms"] = validate()
        results["status"] = "passed_with_documented_initial_profile_finding"
        results["tested_answer_correspondence_cases"] = 20
    except Exception as error:
        results["error"] = {"type": type(error).__name__, "message": str(error)}
    RESULTS.mkdir(exist_ok=True)
    (RESULTS / "suite-verification.json").write_text(json.dumps(results, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if results["status"] == "failed":
        print("OWL control suite FAILED: " + results["error"]["message"], file=sys.stderr)
        return 1
    print("OWL control suite passed: 40 semantic cases, 680 entailment and 130 satisfiability answers; 20 import comparisons. The 15 initial raw DL-profile expectation failures remain recorded; only 15 projected rule-free inputs claim strict DL conformance.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
