#!/usr/bin/env python3
"""Repeat the I1 export/PROV-role regression in independent hash-seeded processes.

Uses the existing checked native reader, OWL exporter, deterministic RDF writer
and real reasoner backend. It does not duplicate their implementation or modify
native sources, canonical snapshots, semantic oracles or the archived failure.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
MODULE = HERE.parent.parent
sys.path.insert(0, str(MODULE))
import verify_i1 as integration  # noqa: E402


def one_seed():
    seed = os.environ["PYTHONHASHSEED"]
    output = HERE / ("seed-" + seed)
    output.mkdir(exist_ok=True)
    external = integration.load_external()
    nodes, atoms, model, mapping, history, targets = integration.read_source(
        MODULE / "models" / "beforeWithdrawal.fhas", external)
    canonical = integration.canonical_projection(model, mapping, history)
    dataset = integration.Dataset()
    dataset.parse(integration.PROFILE / "chart-baseline" / "snapshots.trig", format="trig")
    expected = dataset.graph(integration.EX.beforeWithdrawal)
    if set(canonical) != set(expected):
        raise AssertionError("Canonical application facts changed")
    graph = integration.export_owl(nodes, atoms, model, mapping, canonical)
    document = output / "beforeWithdrawal.ttl"
    integration.write_rdf_graph(document, graph)
    manifest = json.loads((HERE / "beforeWithdrawal-manifest.json").read_text())
    results = []
    for arm in ("raw", "metadata_projection"):
        response = integration.reasoner_backend.run_reasoner(
            document, manifest, output / (arm + ".json"), prov_variant=arm)
        answer = next(q for q in response["entailments"]
                      if q["id"] == "revision_entails_derivation")
        if response["status"] != "consistent" or answer["status"] != "entailed" or answer.get("value") is not True:
            raise AssertionError(f"{seed}/{arm}: revision consequence not entailed")
        in_profile = response["profiles"]["OWL2_DL"]["in_profile"]
        if in_profile is not (arm == "metadata_projection"):
            raise AssertionError(f"{seed}/{arm}: unexpected DL-profile result")
        results.append({"arm": arm, "status": response["status"],
                        "revision_entails_derivation": answer,
                        "owl2_dl": in_profile,
                        "dl_violations": response["profiles"]["OWL2_DL"]["violation_count"]})
    return {"hash_seed": seed, "input_sha256": hashlib.sha256(document.read_bytes()).hexdigest(),
            "generated_triples": len(graph), "canonical_triples": len(canonical),
            "canonical_facts_unchanged": True, "results": results}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--single", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.single:
        print(json.dumps(one_seed()))
        return 0
    results = []
    for seed in ("1", "17", "101"):
        env = os.environ.copy()
        env["PYTHONHASHSEED"] = seed
        process = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--single"],
                                 env=env, text=True, capture_output=True)
        if process.returncode:
            sys.stderr.write(process.stdout + process.stderr)
            return process.returncode
        results.append(json.loads(process.stdout))
    if len({r["input_sha256"] for r in results}) != 1:
        raise AssertionError("Export bytes differ across hash seeds")
    report = {"seeds": results, "stable_input_bytes": True, "semantic_oracle_unchanged": True}
    (HERE / "seed-probes.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"independent_hash_seeds": 3, "real_reasoner_runs": 6,
                      "stable_input_bytes": True, "canonical_facts_unchanged": True,
                      "input_sha256": results[0]["input_sha256"], "failures": []}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
