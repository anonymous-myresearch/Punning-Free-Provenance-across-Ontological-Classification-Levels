# I1: real DL inference returned to a native provenance policy

This module tests an implemented integration path:

    written native model and OWL constructor atoms
      -> generated OWL/RDF document with pinned PROV-O import
      -> direct OWLAPI/HermiT reasoning
      -> separately written and reparsed native DL-answer atoms
      -> a separate DL-guarded native provenance policy

It is a bounded reference integration, **not the official PAMoLa runtime**, a
complete OWL/native translator, or a complete LML implementation. It makes no
claim that RDF/SPARQL cannot express the policy, that arbitrary Datalog cannot
implement DL reasoning, or that this prototype has a maintenance advantage.

## Run

From the complete provenance-profile directory, with Python 3, Java, and the
package's pinned dependencies available:

```sh
python3 integration-run/build_integration.py
python3 integration-run/verify_i1.py
```

Python dependencies are RDFLib 7.1.4 and owlrl 7.1.4. The shared backend is
`../owl-reasoner/tools/reasoner_backend.py`; its pinned JAR, Java harness,
versions, import mapping and process status handling are documented there.
Python does not use Owlready2's object model or reinterpret punned OWL objects.
The verifier imports neither this model writer nor the earlier model writer.

## Logical task and native source

The native source explicitly represents these axioms:

* Chart is equivalent to PublicSourceChart union RestrictedSourceChart.
* PublicSourceChart is a subclass of ReviewEligibleChart.
* RestrictedSourceChart is a subclass of ReviewEligibleChart.
* Each example chart-definition class is a subclass of Chart.

The task is subsumption: does Chart, and consequently each definition class,
have to be a subclass of ReviewEligibleChart? Both branches of the defining
union are covered in the full source. The target subsumptions are not asserted.
The source does not make the two definition classes equivalent to each other.

These are controlled coverage axioms, not a claim about a real newspaper's
source policy. Eligibility is separate from approval withdrawal and review.

The schema is carried by native Atoms using existing SemanticWeb profile
constructors: Class, Declaration, Import, ObjectUnionOf, EquivalentClasses and
SubClassOf. Arguments bind to native elements or constructor occurrences and
fill the exact existing signature Parameters. Variadic ClassExpressions
arguments retain separate ordered occurrences. The verifier resolves those
signatures from `../dependencies/SemanticWeb_Profile_Candidate.fhas`; it rejects
unsupported constructors, malformed arities, wrong roles and references.
It does not append the coverage axioms independently in Python.

Class syntax occurrences refer to existing native element identities. The
export uses those elements' exact persistent IRIs. The OWL view can use legal
class/individual punning; the native source has one element in both roles.

## Complete canonical evidence

The five original contexts are retained: beforeWithdrawal, afterWithdrawal,
incompleteRegistry, newChartType and recategorisedType. Their native sources
generate exactly the asserted triples in the corresponding graph of
`../chart-baseline/snapshots.trig`, using the same
`https://example.org/provenance-chart/` participant IRIs.

The comparison covers every canonical direct classification, positive approval,
approval requirement, completeness certificate and PROV assertion. It includes
the four qualification/generation statements about plotting1, usage1, data1 and
plottedData, in addition to the thirteen attribution/derivation/revision facts.
The new-chart context has three further provenance facts. The generated OWL
document contains this asserted graph plus explicit OWL declarations and the
source-authored coverage axioms. The canonical graphs themselves are not edited.

Generated OWL documents use deterministic full-IRI Turtle (`results/*.ttl`),
with canonical blank-node labels and sorted triples. The exporter explicitly
declares each signature-checked application PROV predicate as an object property.
These declarations are view plumbing; they add no recorded history or coverage
axioms.

Native fixed-step potency, required attribute correspondence, durability and
category-bound approval interpretation use the earlier bounded native contract.
The four additional PROV predicate forms are independently signature-checked and
retained; they are not silently discarded because the old analysis uses only
three history relations.

## DL answers and separate policy

The real reasoner answers named-class subsumption queries. Accepted answers are
written as native `dlSubClassOf(C,T,R)` Atoms, with signature-bound Arguments,
then independently reparsed before becoming analysis inputs. Asserted direct
classification stays separate from inferred DL subsumption.

The original five native chart rules are unchanged. The new module has one
additional native rule, also decoded from written FHAS:

```text
dlReviewWitness(C,X,T,K,A) :-
  reviewType(C,T,K), directType(C,X,T), attributed(C,T,A),
  dlSubClassOf(C,T,R), policyTarget(C,R).
```

It asks for the old withdrawal-review condition **and** a DL-entailed eligibility
guard, retaining classifier T and its attributed agent A in the witness. It
asserts no attribution or derivation about X. `policyTarget` is an explicit
native input, not a hidden Python choice of the guard class.

An absent DL entailment is reported as `not_entailed`. It does not assert
ineligibility, approval or a negative class membership. Original review and
approvalUndetermined outputs remain available independently of this additional
policy.

## Non-RL dependency and provenance controls

The runner independently applies owlrl's standard OWL 2 RL/RDF rules to the
generated RDF plus the same imported PROV vocabulary. That closure does not
derive the queried coverage subsumptions, whereas HermiT derives them for the
full source. This is an observed dependency on reasoning beyond that particular
rule set; an OWL profile warning alone is not used as the evidence.

Six additional positive/negative reasoner checks preserve the distinction
between classifier and chart histories. They check the definition's attribution
to Alice and derivation from guideline1, the chart's attribution to Derek, and
the absence of entailed propagation of Alice/guideline1 onto chart1. They also
check a genuine imported PROV axiom consequence: wasRevisionOf(v2,v1) entails
wasDerivedFrom(v2,v1). This inferred derivation is not copied into recorded
native history. The same checks run against the independent RL/RDF closure.

The omitted-branch source removes only the native RestrictedSourceChart to
ReviewEligibleChart subclass axiom. The DL target then is not entailed and the
additional guarded witnesses are absent, while the original review outputs
remain. `oracles.json` provides a finite counterinterpretation for the selected
coverage axioms: Chart and RestrictedSourceChart contain w, while
PublicSourceChart and ReviewEligibleChart are empty. The runner checks every
remaining coverage axiom against it. This is not presented as a complete model
of the imported PROV ontology; the real reasoner independently checks the full
ontology's non-entailment.

## Raw PROV-O and explicit DL import projection

Every accepted source is run twice. The first import is the untouched bundled
PROV-O file. Its OWLAPI profile diagnostics are retained, including illegal
object/annotation property punning reported for specializationOf and
wasRevisionOf. A successful HermiT run on that input is not labelled strict
OWL 2 DL conformance.

The second run uses the shared backend's explicit metadata projection. Its
manifest removes exactly two rdf:type owl:AnnotationProperty declarations;
all document-history assertions and application class/property axioms remain.
The source bytes remain untouched. The exact triple delta and both hashes are in
`../owl-reasoner/backend/metadata-projection-manifest.json`. The projected import
must pass the OWL 2 DL profile check for the accepted I1 cases. Both import
variants must give the same expected subsumption and provenance test outcomes.

Deleting annotation-property declarations is an explicit change to the RDF
input. The experiment does not claim unrestricted RDF semantic equivalence of
the two imports. It checks the stated application inputs and queries, and
reports the import variant on each real execution.

A full-check regression exposed parsing sensitivity before those explicit
application-role declarations were present: one RDF/XML serialisation caused
the raw import to classify the application's revision assertion as an annotation,
so its derivation consequence was not entailed. The strict DL projection retained
the expected answer. `regressions/raw-role-declarations/` preserves that input,
manifest and both actual reports. The corrected exporter retains the semantic
oracles unchanged; independent processes with hash seeds 1, 17 and 101 generate
byte-identical Turtle and entail the revision consequence under both import
variants. The raw import still receives its profile diagnostics. These probes
check the stated boundary; they do not establish general raw-import guarantees.

## Controls and results

| Native source | Expected result |
|---|---|
| beforeWithdrawal | Coverage entailed; no withdrawal-review witness. |
| afterWithdrawal | Coverage entailed; guarded witnesses for chart1 and chart2 under v1. |
| incompleteRegistry | Coverage entailed; old approvalUndetermined remains; no guarded review. |
| newChartType | The unchanged coverage/export/policy mechanisms also select chart4 under BudgetChart_v1. |
| recategorisedType | Retained Statistical approval does not approve Sensitive; guarded witnesses retain the Sensitive category. |
| omittedBranch | Coverage not entailed; no guarded witnesses; recorded history and direct typing unchanged. |
| reclassifiedChart | One native declared-type edit moves chart1 to v2; only chart2 remains a guarded review witness; all recorded histories unchanged. |
| badPotency | Rejected before OWL export as potency-step. |
| malformedUnion | Rejected before OWL export as constructor-arity. |

`results/report.json` gives exact counts, complete witnesses, per-source hashes,
canonical triple differences and raw/projected profile diagnostics. The real
reasoner reports are separate for each import variant. OWL documents, selected
canonical graphs, query manifests and returned native views are included.

The runner treats import errors, unsupported execution, inconsistent ontology,
unsatisfiable queried class, partial query execution and process failures as
failures. It never turns them into a successful empty result. Finite checks do
not establish complete OWL/native round-tripping, performance superiority,
automatic edit provenance capture or official runtime execution.
