#!/usr/bin/env python3
"""Execute I1: native constructor atoms -> OWL -> HermiT -> native policy.

Neither model constructor is imported. This is a bounded integration runner,
not the official PAMoLa execution service or a complete OWL/native importer.
"""
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
import csv,hashlib,json,sys
import rdflib,owlrl
from rdflib import Graph,Dataset,URIRef,BNode,Literal,Namespace,RDF,RDFS,OWL
from rdflib.collection import Collection
from rdflib.compare import to_canonical_graph

HERE=Path(__file__).resolve().parent
PROFILE=HERE.parent
for directory in ['tools','model-integration','reference-analysis','chart-baseline','owl-reasoner/tools']:
    sys.path.insert(0,str(PROFILE/directory))
import fhas_reference as native
import verify_integration as bounded
import reference_analysis as reference
import reasoner_backend

ROOT='Ordium.IntegrationExample'
BASE='Ordium.Profile.Provenance.DLIntegration'
SW='Ordium.Profile.SemanticWeb.constructor'
PV='Ordium.Profile.Provenance.vocab.prov'
EX=Namespace('https://example.org/provenance-chart/')
PROV=Namespace('http://www.w3.org/ns/prov#')
OLD_OUTPUTS=('classifierProvenance','reviewType','reviewEntity','reviewPublication','approvalUndetermined')
SUPPORTED={'Class','Declaration','Import','ObjectUnionOf','SubClassOf','EquivalentClasses'}

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def demand(condition,code,*witness):
    if not condition:raise bounded.ContractError(code,*map(str,witness))
def local(fq):
    demand(fq.startswith(ROOT+'.'),'nonlocal-native-participant',fq)
    return fq[len(ROOT)+1:]
def rows_json(rows,mapping):return sorted([[str(mapping[v]) for v in row] for row in rows])
def triple_json(triples):return sorted([[str(x) for x in row] for row in triples])
def write_rdf_graph(path,graph):
    """Deterministic full-IRI Turtle, with canonical blank-node labels."""
    triples=to_canonical_graph(graph)
    Path(path).write_text('\n'.join(sorted(' '.join(term.n3() for term in row)+' .' for row in triples))+'\n')

def load_external():
    result={}
    for path in sorted((PROFILE/'dependencies').glob('*.fhas')):result.update(native.read_fhas(path))
    result.update(native.read_fhas(PROFILE/'Provenance_Profile_Candidate.fhas'))
    result.update(native.read_fhas(PROFILE/'chart-analysis/Chart_Analysis_Profile.fhas'))
    result.update(native.read_fhas(HERE/'DL_Integration_Policy.fhas'))
    return result

def read_constructor_atoms(nodes,external):
    """Validate source atom signatures against the included SemanticWeb profile."""
    all_nodes={**external,**nodes};atoms={}
    for fq,node in nodes.items():
        if node['badge']!='AO' or not fq.startswith(ROOT+'.owlOverlay.'):continue
        predicate=node['props'].get('hasPredicate','')
        demand(predicate.startswith(SW+'.'),'unsupported-overlay-predicate',fq,predicate)
        name=predicate[len(SW)+1:]
        demand(name in SUPPORTED,'unsupported-constructor',fq,name)
        demand(predicate in external,'unresolved-constructor',fq,predicate)
        parameters=[n for n in external[predicate]['children'] if n['badge']=='PM']
        args=native.ordered_children(node,'AG','AG')
        variable=name in {'ObjectUnionOf','EquivalentClasses'}
        demand(len(args)>=2 if variable else len(args)==len(parameters),'constructor-arity',fq)
        targets=[]
        for i,arg in enumerate(args):
            parameter=parameters[0 if variable else i]
            demand(arg['props'].get('fills')==parameter['fqn'],'constructor-role',arg['fqn'],parameter['fqn'])
            target=arg['props'].get('bindsTo')
            demand(target in all_nodes,'constructor-reference',arg['fqn'],target)
            targets.append(target)
        atoms[fq]=(name,targets)
    demand(atoms,'missing-overlay-constructors')
    for fq,(name,targets) in atoms.items():
        if name=='Class':demand(targets[0] in nodes and 'hasPID' in nodes[targets[0]]['props'],'class-reference-not-native-element',fq)
        elif name=='Import':
            demand(all_nodes[targets[0]]['badge']=='LI','import-not-iri-literal',fq)
            demand(all_nodes[targets[0]]['props'].get('hasLexeme')=='http://www.w3.org/ns/prov-o#','unexpected-import',fq)
        else:
            for target in targets:demand(target in atoms,'constructor-expression-reference',fq,target)
    return atoms

def read_source(path,external):
    nodes=native.read_fhas(path);atoms=read_constructor_atoms(nodes,external)
    vocab={r['owner_fqn']:URIRef(r['iri']) for r in csv.DictReader((PROFILE/'VOCABULARY.tsv').open(),delimiter='\t')}
    all_nodes={**external,**nodes};history=[];extra_prov=set()
    for fq,node in nodes.items():
        if node['badge']!='AO' or not node['props'].get('hasPredicate','').startswith(PV+'.'):continue
        predicate,values=bounded.native_fact(node,all_nodes)
        demand(predicate in vocab and len(values)==2,'unsupported-recorded-provenance',fq)
        demand(all(v in nodes for v in values),'nonlocal-recorded-participant',fq)
        history.append((values[0],vocab[predicate],values[1]))
        if predicate.rsplit('.',1)[-1] not in bounded.STANDARD.values():extra_prov.add(fq)
    # The earlier interpreter owns just the three original analysis relations.
    # Additional canonical PROV atoms are independently validated and retained.
    excluded=[ROOT+'.owlOverlay',ROOT+'.integrationInputs',*extra_prov]
    contract_nodes={fq:n for fq,n in nodes.items() if not any(fq==x or fq.startswith(x+'.') for x in excluded)}
    model=bounded.interpret(contract_nodes,external)
    mapping=bounded.term_map(nodes)
    targets=[]
    for fq,node in nodes.items():
        if node['badge']=='AO' and fq.startswith(ROOT+'.integrationInputs.'):
            predicate,values=bounded.native_fact(node,all_nodes)
            demand(predicate==BASE+'.internal.policyTarget','unsupported-integration-input',fq)
            demand(values[0]==model['context'],'integration-context',fq)
            targets.append(values)
    demand(len(targets)==1,'policy-target-cardinality')
    return nodes,atoms,model,mapping,history,targets

def canonical_projection(model,mapping,history):
    graph=Graph()
    for _,x,t in model['facts']['directType']:graph.add((mapping[x],RDF.type,mapping[t]))
    for x,p,y in history:graph.add((mapping[x],p,mapping[y]))
    for _,x,k in model['facts']['approvedType']:graph.add((mapping[x],EX.approvedType,mapping[k]))
    for p in ['requiresApproval','completeApprovalRegistry']:
        for _,k in model['facts'][p]:graph.add((mapping[k],EX[p],Literal(True)))
    return graph

def export_owl(nodes,atoms,model,mapping,canonical):
    """Execute the selected constructor-to-RDF mapping on written native atoms."""
    graph=Graph();graph+=canonical
    ontology=URIRef(str(mapping[ROOT])+':owl-view')
    graph.add((ontology,RDF.type,OWL.Ontology))
    visiting=set();memo={}
    def expression(fq):
        demand(fq not in visiting,'cyclic-class-expression',fq)
        if fq in memo:return memo[fq]
        visiting.add(fq);name,targets=atoms[fq]
        if name=='Class':value=mapping[targets[0]]
        elif name=='ObjectUnionOf':
            value=BNode('union_'+hashlib.sha256(fq.encode()).hexdigest()[:16]);head=BNode('list_'+hashlib.sha256(fq.encode()).hexdigest()[:16])
            graph.add((value,RDF.type,OWL.Class));graph.add((value,OWL.unionOf,head))
            Collection(graph,head,[expression(t) for t in targets])
        else:raise bounded.ContractError('non-class-expression',fq,name)
        visiting.remove(fq);memo[fq]=value;return value
    for fq,(name,targets) in atoms.items():
        if name=='Import':graph.add((ontology,OWL.imports,URIRef(nodes[targets[0]]['props']['hasLexeme'])))
        elif name=='Declaration':
            demand(atoms[targets[0]][0]=='Class','unsupported-declaration',fq)
            graph.add((expression(targets[0]),RDF.type,OWL.Class))
        elif name=='SubClassOf':graph.add((expression(targets[0]),RDFS.subClassOf,expression(targets[1])))
        elif name=='EquivalentClasses':
            expressions=[expression(t) for t in targets]
            for first,second in zip(expressions,expressions[1:]):graph.add((first,OWL.equivalentClass,second))
        elif name in {'Class','ObjectUnionOf'}:expression(fq)
    # Explicit OWL declarations are view plumbing for the preserved ABox. The
    # nontrivial logical axioms above come exclusively from native constructors.
    for fq in model['entities']:graph.add((mapping[fq],RDF.type,OWL.NamedIndividual))
    # State the application predicate roles explicitly. The unchanged raw
    # PROV import declares two predicates in conflicting annotation/object
    # roles; relying on its role inference made RDF/XML load order observable.
    # These are declarations for already signature-checked native history,
    # not new historical assertions or logical coverage assumptions.
    for predicate in set(canonical.predicates()):
        if str(predicate).startswith(str(PROV)):
            graph.add((predicate,RDF.type,OWL.ObjectProperty))
    graph.add((EX.approvedType,RDF.type,OWL.ObjectProperty))
    for p in [EX.requiresApproval,EX.completeApprovalRegistry]:graph.add((p,RDF.type,OWL.DatatypeProperty))
    return graph

def decode_policy(external):
    module=native.read_fhas(HERE/'DL_Integration_Policy.fhas')
    native.BASE=BASE
    _,owners=native.interface_table(HERE/'INTERFACES.tsv')
    rules=native.decode_rules(module,owners,{**external,**module});native.safety_and_strata(rules)
    decoded=[]
    def atom(a):
        demand(all(t.kind=='variable' for t in a.args),'nonvariable-policy-fragment',a.predicate)
        return a.predicate,tuple(t.value for t in a.args)
    for r in rules:decoded.append((atom(r.head),[(a.negated,atom(a)) for a in r.body]))
    demand(len(decoded)==1 and decoded[0][0][0]=='dlReviewWitness','separate-policy-contract')
    return decoded

def write_returned_view(path,triples):
    """Write/reparse the actual DL answers as native atoms, preserving IDs."""
    def node(badge,props,children=(),depth=0):
        pad='  '*depth
        parts=[k+' '+(json.dumps(v) if quoted else v) for k,v,quoted in props]
        parts += [node(b,p,c,depth+1).lstrip() for b,p,c in children]
        return pad+badge+' {'+(',\n'+pad+'  ').join(parts)+'}'
    root=ROOT+'.returnedDL';children=[]
    for i,values in enumerate(sorted(triples),1):
        fq=root+'.F'+str(i);args=[];pred=BASE+'.internal.dlSubClassOf'
        for j,value in enumerate(values,1):
            props=[('hasName','AG_'+str(j),True),('bindsTo',value,False),('fills',pred+'.P'+str(j),False)]
            if j>1:props.append(('follows',fq+'.AG_'+str(j-1),False))
            args.append(('AG',props,[]))
        children.append(('AO',[('hasName','F'+str(i),True),('hasPredicate',pred,False)],args))
    path.write_text(node('EN',[('hasName','returnedDL',True),('hasFQN',root,True)],children)+'\n')

def counterinterpretation(atoms,nodes,oracle):
    sets={ROOT+'.'+k:set(v) for k,v in oracle.items() if isinstance(v,list) and k!='domain'}
    def ext(fq):
        name,targets=atoms[fq]
        if name=='Class':return sets.get(targets[0],set())
        demand(name=='ObjectUnionOf','countermodel-expression',fq)
        return set().union(*(ext(t) for t in targets))
    checks=0
    for fq,(name,targets) in atoms.items():
        if name=='SubClassOf':demand(ext(targets[0])<=ext(targets[1]),'counterinterpretation-gci',fq);checks+=1
        elif name=='EquivalentClasses':demand(all(ext(t)==ext(targets[0]) for t in targets[1:]),'counterinterpretation-definition',fq);checks+=1
    demand(not sets[ROOT+'.Chart']<=sets[ROOT+'.ReviewEligibleChart'],'counterinterpretation-target')
    return checks

def main():
    results=HERE/'results';results.mkdir(exist_ok=True)
    external=load_external();chart_rules=bounded.decode_rules(external);policy=decode_policy(external)
    oracles=json.loads((HERE/'oracles.json').read_text())
    dataset=Dataset();dataset.parse(PROFILE/'chart-baseline/snapshots.trig',format='trig')
    canonical_before=set(dataset.quads((None,None,None,None)))
    reports=[];accepted={};old_query_checks=0;counterchecks=0
    prov_variants={'raw':Graph().parse(PROFILE/'dependencies/prov-o.ttl',format='turtle'),
                   'metadata_projection':Graph().parse(PROFILE/'owl-reasoner/backend/prov-o-metadata-projection.ttl',format='turtle')}
    for case in oracles['cases']:
        case_id=case['id'];source=HERE/'models'/f'{case_id}.fhas';source_hash=digest(source)
        try:nodes,atoms,model,mapping,history,targets=read_source(source,external)
        except bounded.ContractError as error:
            demand(case.get('error')==error.code,'unexpected-source-rejection',case_id,error.code)
            reports.append({'id':case_id,'status':'rejected-before-export','code':error.code,'witness':error.witness,'source_sha256':source_hash});continue
        demand('error' not in case,'expected-source-rejection-not-raised',case_id)
        canonical=canonical_projection(model,mapping,history)
        reference_graph=dataset.graph(EX[case['canonical']]);removed=set(reference_graph)-set(canonical);added=set(canonical)-set(reference_graph)
        expected_removed={(EX.chart1,RDF.type,EX.CrimeRateChart_v1)} if case_id=='reclassifiedChart' else set()
        expected_added={(EX.chart1,RDF.type,EX.CrimeRateChart_v2)} if case_id=='reclassifiedChart' else set()
        demand(removed==expected_removed and added==expected_added,'canonical-fact-difference',case_id,triple_json(removed),triple_json(added))
        graph=export_owl(nodes,atoms,model,mapping,canonical)
        path=results/f'{case_id}.ttl';write_rdf_graph(path,graph)
        write_rdf_graph(results/f'{case_id}-canonical.ttl',canonical)
        query_names=['Chart','CrimeRateChart_v1','CrimeRateChart_v2']+(['BudgetChart_v1'] if ROOT+'.BudgetChart_v1' in nodes else [])
        target=targets[0][1]
        manifest={'entailments':[{'id':n,'kind':'subclass','sub':str(mapping[ROOT+'.'+n]),'super':str(mapping[target])} for n in query_names]+
                  [{'id':q['id'],'kind':'object_property_assertion','property':str(PROV[q['predicate']]),'subject':str(EX[q['subject']]),'object':str(EX[q['object']])} for q in oracles['provenance_entailments']],
                  'satisfiability':[{'id':'Chart','class':str(EX.Chart)}]}
        (results/f'{case_id}-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
        responses={variant:reasoner_backend.run_reasoner(path,manifest,results/f'{case_id}-{variant}-reasoner.json',prov_variant=variant)
                   for variant in ['raw','metadata_projection']}
        for variant,response in responses.items():
            demand(response['status']=='consistent','reasoner-processing-status',case_id,variant,response['status'],response.get('error'))
            demand(response.get('query_execution_status')=='complete','reasoner-query-execution',case_id,variant)
            demand(not response.get('blocked_imports'),'blocked-import',case_id,variant)
            demand(len(response['imports_closure'])>=2,'missing-prov-import',case_id,variant)
            demand(all(r['status'] in {'entailed','not_entailed'} for r in response['entailments']),'reasoner-query-status',case_id,variant)
            checked={r['id']:r for r in response['entailments']}
            demand(all(checked[n]['value']==case['entailed'] for n in query_names),'unexpected-dl-entailment',case_id,variant)
            for q in oracles['provenance_entailments']:
                demand(checked[q['id']]['value']==q['entailed'],'provenance-entailment-oracle',case_id,variant,q['id'])
            demand(all(s['value'] for s in response['satisfiability']),'unexpected-unsatisfiable-class',case_id,variant)
        response=responses['metadata_projection']
        demand(response['profiles']['OWL2_DL']['in_profile'],'projected-prov-owl2-dl-profile',case_id)
        # Report raw profile diagnostics rather than treating an import/parser
        # tolerance as a semantic result. Profile acceptance is a separate gate.
        by_id={r['id']:r for r in response['entailments']}
        rl_variants={}
        for variant,prov in prov_variants.items():
            closure=Graph();closure+=graph;closure+=prov
            owlrl.DeductiveClosure(owlrl.OWLRL_Semantics,axiomatic_triples=False,datatype_axioms=False).expand(closure)
            rl_variants[variant]={n:(mapping[ROOT+'.'+n],RDFS.subClassOf,mapping[target]) in closure for n in query_names}
            demand(not any(rl_variants[variant].values()),'unexpected-rl-subsumption',case_id,variant)
            for q in oracles['provenance_entailments']:
                got=(EX[q['subject']],PROV[q['predicate']],EX[q['object']]) in closure
                demand(got==q['entailed'],'rl-provenance-oracle',case_id,variant,q['id'])
        demand((EX.Chart,RDFS.subClassOf,EX.ReviewEligibleChart) not in graph,'target-subsumption-asserted',case_id)
        returned={(model['context'],ROOT+'.'+n,target) for n in query_names if by_id[n]['value']}
        return_path=results/f'{case_id}-returned-DL.fhas';write_returned_view(return_path,returned)
        parsed_return=native.read_fhas(return_path);recovered=set()
        for fq,node in parsed_return.items():
            if node['badge']=='AO':
                predicate,values=bounded.native_fact(node,{**external,**nodes,**parsed_return})
                demand(predicate==BASE+'.internal.dlSubClassOf','unexpected-returned-predicate',fq);recovered.add(values)
        demand(recovered==returned,'returned-view-roundtrip',case_id)
        inputs=deepcopy(model['facts']);facts=deepcopy(inputs);reference.evaluate(chart_rules,facts)
        old_outputs={p:set(facts[p]) for p in OLD_OUTPUTS}
        selected=Dataset();selected.graph(mapping[model['context']]).__iadd__(canonical)
        for p,filename in bounded.QUERIES.items():
            got={tuple(row) for row in selected.query((PROFILE/'chart-baseline'/filename).read_text())}
            wanted={tuple(mapping[v] for v in row) for row in facts[p]}
            demand(got==wanted,'old-query-parity',case_id,p);old_query_checks+=1
        facts['dlSubClassOf']=recovered;facts['policyTarget']=set(targets)
        before_policy=deepcopy(facts);reference.evaluate(policy,facts)
        witnesses=sorted([[local(v) for v in row[1:]] for row in facts['dlReviewWitness']])
        demand(witnesses==sorted(case['witnesses']),'new-policy-oracle',case_id,witnesses)
        for p,values in before_policy.items():demand(facts[p]==values,'new-policy-input-mutation',case_id,p)
        for p,values in old_outputs.items():demand(facts[p]==values,'old-output-mutation',case_id,p)
        demand(digest(source)==source_hash,'native-source-mutation',case_id)
        if case_id=='omittedBranch':counterchecks=counterinterpretation(atoms,nodes,oracles['omitted_branch_counterinterpretation'])
        report={'id':case_id,'status':'accepted','source_sha256':source_hash,
                'canonical_context':case['canonical'],'canonical_triples':len(canonical),'recorded_prov_assertions':len(history),
                'canonical_difference':{'removed':triple_json(removed),'added':triple_json(added)},
                'native_constructor_atoms':len(atoms),'generated_owl_triples':len(graph),
                'generated_owl_document':str(path.relative_to(HERE)),
                'generated_owl_syntax':'deterministic full-IRI Turtle with canonical blank-node labels',
                'generated_owl_sha256':digest(path),
                'schema_and_declaration_additions':len(set(graph)-set(canonical)),
                'dl_query_results':{n:by_id[n]['status'] for n in query_names},'rl_subsumption_results':rl_variants,
                'raw_owl2_dl_profile':responses['raw']['profiles']['OWL2_DL'],
                'projected_prov_owl2_dl_profile':response['profiles']['OWL2_DL'],
                'projected_prov_owl2_rl_profile':response['profiles']['OWL2_RL'],
                'provenance_entailment_results':{q['id']:by_id[q['id']]['status'] for q in oracles['provenance_entailments']},
                'old_five_rule_outputs':{p:sorted([[local(v) for v in row[1:]] for row in old_outputs[p]]) for p in OLD_OUTPUTS},
                'returned_native_tuples':len(recovered),'dl_review_witnesses':witnesses,
                'missing_guard_interpretation':'not_entailed; no DL-guarded witness, no assertion of ineligibility or approval' if not case['entailed'] else None}
        reports.append(report);accepted[case_id]={'history':set(history),'direct':model['direct'],'inputs':inputs,'report':report}
    demand(set(dataset.quads((None,None,None,None)))==canonical_before,'canonical-dataset-mutation')
    for name in ['omittedBranch','reclassifiedChart']:
        demand(accepted[name]['history']==accepted['afterWithdrawal']['history'],'control-history-mutation',name)
    report={'scope':'I1 bounded native constructor export, direct OWLAPI/HermiT execution, separate returned native semantic view and additional native policy. Not official PAMoLa runtime/full OWL or LML implementation.',
            'native_sources':len(reports),'accepted_sources':len(accepted),'rejected_sources':len(reports)-len(accepted),
            'canonical_context_preservation_checks':5,'old_five_rule_sparql_checks':old_query_checks,
            'new_native_policy_rules':len(policy),'new_policy_oracle_checks':len(accepted),
            'returned_view_roundtrip_checks':len(accepted),'recorded_history_control_checks':2,
            'dl_subsumption_checks_per_prov_variant':sum(len(x['report']['dl_query_results']) for x in accepted.values()),
            'prov_entailment_checks_per_prov_variant':len(accepted)*len(oracles['provenance_entailments']),
            'prov_import_variants':2,
            'rl_subsumption_checks_per_prov_variant':sum(len(x['report']['rl_subsumption_results']['raw']) for x in accepted.values()),
            'rl_prov_entailment_checks_per_prov_variant':len(accepted)*len(oracles['provenance_entailments']),
            'coverage_counterinterpretation_axiom_checks':counterchecks,
            'all_raw_owl2_dl_profiles_accepted':all(x['report']['raw_owl2_dl_profile']['in_profile'] for x in accepted.values()),
            'all_projected_prov_owl2_dl_profiles_accepted':all(x['report']['projected_prov_owl2_dl_profile']['in_profile'] for x in accepted.values()),
            'versions':{'rdflib':rdflib.__version__,'owlrl':owlrl.__version__},
            'sha256':{'canonical_snapshots':digest(PROFILE/'chart-baseline/snapshots.trig'),'prov_o':digest(PROFILE/'dependencies/prov-o.ttl'),
                      'prov_o_projection':digest(PROFILE/'owl-reasoner/backend/prov-o-metadata-projection.ttl'),
                      'prov_o_projection_manifest':digest(PROFILE/'owl-reasoner/backend/metadata-projection-manifest.json'),
                      'semanticweb_profile':digest(PROFILE/'dependencies/SemanticWeb_Profile_Candidate.fhas'),
                      'original_five_rules':digest(PROFILE/'chart-analysis/Chart_Analysis_Profile.fhas'),'separate_policy':digest(HERE/'DL_Integration_Policy.fhas')},
            'failures':[],'cases':reports}
    (results/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))

if __name__=='__main__':main()
