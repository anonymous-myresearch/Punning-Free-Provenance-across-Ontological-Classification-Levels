#!/usr/bin/env python3
"""Write native I1 sources and a separate DL-guarded native policy.

The verifier imports neither this writer nor the earlier model writer.
"""
from copy import deepcopy
from pathlib import Path
import csv,json,sys

HERE=Path(__file__).resolve().parent
PROFILE=HERE.parent
sys.path.insert(0,str(PROFILE/'model-integration'))
from build_models import Node,Ref,entity,approval,fact,child,base_model,ROOT,CORE,PV,CHART
sys.path.insert(0,str(PROFILE/'reference-analysis'))
import reference_analysis as reference

BASE='Ordium.Profile.Provenance.DLIntegration'
SW='Ordium.Profile.SemanticWeb.constructor'
EX='https://example.org/provenance-chart/'
CONTEXTS=['beforeWithdrawal','afterWithdrawal','incompleteRegistry','newChartType','recategorisedType']
SIGNATURES={'Class':['IRI'],'Declaration':['Entity'],'Import':['DocumentIRI'],
            'ObjectUnionOf':['ClassExpressions'],'EquivalentClasses':['ClassExpressions'],
            'SubClassOf':['SubClassExpression','SuperClassExpression']}

def constructor(parent,name,predicate,targets):
    node=parent.add(Node('AO',name,hasPredicate=Ref(SW+'.'+predicate)))
    for i,target in enumerate(targets,1):
        role=SIGNATURES[predicate][0 if predicate in {'ObjectUnionOf','EquivalentClasses'} else i-1]
        props={'bindsTo':Ref(target),'fills':Ref(SW+'.'+predicate+'.'+role)}
        if i>1:props['follows']=Ref(ROOT+'.owlOverlay.'+name+'.AG_'+str(i-1))
        node.add(Node('AG','AG_'+str(i),**props))
    return node

def add_overlay(model,omit=False,malformed=False):
    for name in ['Chart','PublicSourceChart','RestrictedSourceChart','ReviewEligibleChart']:
        entity(model,name,1)
    graph=model.add(Node('EN','owlOverlay',hasLinguisticType=Ref(CORE+'.Entity')))
    document=graph.add(Node('DV','provDocument',ofDataType=Ref(CORE+'.DataType.IRI')))
    document.add(Node('LI','lexeme',hasLexeme='http://www.w3.org/ns/prov-o#'))
    constructor(graph,'importPROV','Import',[ROOT+'.owlOverlay.provDocument.lexeme'])
    classes=['StatisticalChartType','CrimeRateChart_v1','CrimeRateChart_v2','Chart',
             'PublicSourceChart','RestrictedSourceChart','ReviewEligibleChart']
    if any(c.props['hasName']=='SensitiveChartType' for c in model.children):classes.append('SensitiveChartType')
    if any(c.props['hasName']=='BudgetChart_v1' for c in model.children):classes.append('BudgetChart_v1')
    for name in classes:
        constructor(graph,'class_'+name,'Class',[ROOT+'.'+name])
        constructor(graph,'declaration_'+name,'Declaration',[ROOT+'.owlOverlay.class_'+name])
    union=['PublicSourceChart'] if malformed else ['PublicSourceChart','RestrictedSourceChart']
    constructor(graph,'sourceCoverage','ObjectUnionOf',[ROOT+'.owlOverlay.class_'+n for n in union])
    for name in ['CrimeRateChart_v1','CrimeRateChart_v2']+(['BudgetChart_v1'] if 'BudgetChart_v1' in classes else []):
        constructor(graph,'chart_'+name,'SubClassOf',[ROOT+'.owlOverlay.class_'+name,ROOT+'.owlOverlay.class_Chart'])
    constructor(graph,'coverageAxiom','EquivalentClasses',[ROOT+'.owlOverlay.class_Chart',ROOT+'.owlOverlay.sourceCoverage'])
    constructor(graph,'publicPolicy','SubClassOf',[ROOT+'.owlOverlay.class_PublicSourceChart',ROOT+'.owlOverlay.class_ReviewEligibleChart'])
    if not omit:
        constructor(graph,'restrictedPolicy','SubClassOf',[ROOT+'.owlOverlay.class_RestrictedSourceChart',ROOT+'.owlOverlay.class_ReviewEligibleChart'])
    inputs=model.add(Node('EN','integrationInputs'))
    fact(inputs,'target',BASE+'.internal.policyTarget',['Analysis','ReviewEligibleChart'],ROOT+'.integrationInputs',False)

def canonical(context):
    model=base_model()
    # Extend the earlier source to retain all seventeen canonical PROV assertions.
    for name in ['plotting1','usage1','plottedData']:entity(model,name)
    graph=child(model,'recordedProvenance')
    for i,(p,s,o) in enumerate([('wasGeneratedBy','chart1','plotting1'),('qualifiedUsage','plotting1','usage1'),('entity','usage1','data1'),('hadRole','usage1','plottedData')],14):
        fact(graph,'F'+str(i),PV+'.'+p,[s,o],ROOT+'.recordedProvenance')
    if context=='beforeWithdrawal':child(child(model,'CrimeRateChart_v1'),'statisticalApproval').props['hasValue']=Ref(CORE+'.DataType.Boolean.True')
    elif context=='incompleteRegistry':
        child(child(model,'CrimeRateChart_v1'),'statisticalApproval').props['hasValue']=Ref(CORE+'.DataType.SpecialValue.unknown')
        child(model,'certificates').children=[]
    elif context=='newChartType':
        t=entity(model,'BudgetChart_v1',1,'StatisticalChartType');approval(t,'statisticalApproval',0,False)
        for name,typ in [('chart4','BudgetChart_v1'),('article3',None),('guideline3',None),('Elena',None)]:entity(model,name,0,typ)
        for i,(p,s,o) in enumerate([('wasAttributedTo','BudgetChart_v1','Elena'),('wasDerivedFrom','BudgetChart_v1','guideline3'),('wasDerivedFrom','article3','chart4')],20):
            fact(graph,'F'+str(i),PV+'.'+p,[s,o],ROOT+'.recordedProvenance')
    elif context=='recategorisedType':
        k=entity(model,'SensitiveChartType',2);approval(k,'sensitiveApproval',1)
        t=child(model,'CrimeRateChart_v1');t.props['hasDeclaredType']=Ref(ROOT+'.SensitiveChartType')
        child(t,'statisticalApproval').props['hasValue']=Ref(CORE+'.DataType.Boolean.True');approval(t,'sensitiveApproval',0,False)
        fact(child(model,'certificates'),'completeSensitive',CHART+'.internal.completeApprovalRegistry',['Analysis','SensitiveChartType'],ROOT+'.certificates',False)
    for node in model.children:
        if 'hasPID' in node.props:node.props['hasPID']=EX+(context if node.props['hasName']=='Analysis' else node.props['hasName'])
    return model

def build_policy():
    rules=reference.parse_rules(HERE/'rules.dl')
    root=Node('EN','DLIntegration',hasFQN=BASE,hasCustodian=Ref('Ordium.Profile.Provenance'),hasLinguisticType=Ref(CORE+'.Entity'))
    internal=root.add(Node('EN','internal'));rows=[]
    arities={p:len(v) for h,b in rules for p,v in [h]+[a for _,a in b]}
    local={'dlSubClassOf','policyTarget','dlReviewWitness'}
    owners={p:(BASE if p in local else CHART)+'.internal.'+p for p in arities}
    for p,arity in sorted(arities.items()):
        if p in local:
            node=internal.add(Node('OM',p))
            for i in range(1,arity+1):
                props={'hasType':Ref('Ordium')}
                if i>1:props['follows']=Ref(owners[p]+'.P'+str(i-1))
                node.add(Node('PM','P'+str(i),**props))
        rows.append({'alias':p,'owner_fqn':owners[p],'arity':arity,'role':'derived' if p=='dlReviewWitness' else 'input'})
    rc=root.add(Node('EN','rule'))
    for i,(head,body) in enumerate(rules,1):
        rp=BASE+'.rule.R'+str(i);node=rc.add(Node('AO','R'+str(i),hasPredicate=Ref(owners[head[0]])))
        variables=sorted({v for p,vs in [head]+[a for _,a in body] for v in vs})
        def args(target,vs,path):
            for j,v in enumerate(vs,1):
                props={'bindsTo':Ref(rp+'.'+v),'fills':Ref(rp+'.'+v)}
                if j>1:props['follows']=Ref(path+'.AG_'+str(j-1))
                target.add(Node('AG','AG_'+str(j),**props))
        args(node,head[1],rp)
        for j,(neg,(p,vs)) in enumerate(body,1):
            props={'hasPredicate':Ref(owners[p])}
            if j>1:props['follows']=Ref(rp+'.AO_'+str(j-1))
            if neg:props['isNegated']=Ref('true')
            sub=node.add(Node('AO','AO_'+str(j),**props));args(sub,vs,rp+'.AO_'+str(j))
        for v in variables:node.add(Node('PM',v,hasType=Ref('Ordium')))
    (HERE/'DL_Integration_Policy.fhas').write_text(root.render()+'\n')
    with (HERE/'INTERFACES.tsv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=['alias','owner_fqn','arity','role'],delimiter='\t');writer.writeheader();writer.writerows(rows)

def build():
    (HERE/'models').mkdir(exist_ok=True)
    sources={}
    for context in CONTEXTS:
        model=canonical(context);add_overlay(model);sources[context]=model
    for name,opts in [('omittedBranch',{'omit':True}),('malformedUnion',{'malformed':True})]:
        model=canonical('afterWithdrawal');add_overlay(model,**opts);sources[name]=model
    model=deepcopy(sources['afterWithdrawal']);child(model,'chart1').props['hasDeclaredType']=Ref(ROOT+'.CrimeRateChart_v2');sources['reclassifiedChart']=model
    model=deepcopy(sources['afterWithdrawal']);child(model,'chart1').props['hasPotency']=Ref('1');sources['badPotency']=model
    for name,model in sources.items():
        # Added class elements also use the canonical participant namespace.
        for node in model.children:
            if 'hasPID' in node.props and node.props['hasName']!='Analysis':node.props['hasPID']=EX+node.props['hasName']
        (HERE/'models'/f'{name}.fhas').write_text(model.render()+'\n')
    build_policy()
    print(json.dumps({'native_sources':len(sources),'canonical_contexts':len(CONTEXTS),'separate_native_policy_rules':1}))

if __name__=='__main__':build()
