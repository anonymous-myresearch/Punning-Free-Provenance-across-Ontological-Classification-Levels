# Positioning and primary sources

- Atkinson & Kühne (2003), Model-Driven Development: A Metamodeling Foundation. DOI 10.1109/MS.2003.1231149. OCA distinguishes linguistic and ontological classification. Our Core.Entity binding is specific to PAMoLa, not a requirement on all OCA implementations.
- Glimm, Rudolph & Völker (2010), Integrated Metamodeling and Diagnosis in OWL 2. https://www.cs.ox.ac.uk/files/3129/paper.pdf . Directly motivates metamodeling with provenance and explains punning separation. Supplies an OWL axiomatic remedy and diagnostics. We must compare with that solution, not claim OWL cannot express cross-level analysis.
- Eckert, Pfeffer & Völker (2010), Towards Interoperable Metadata Provenance. https://ceur-ws.org/Vol-670/paper_3.pdf . Discusses weak metamodeling and integrated reasoning. Predates PROV 2013; not a contemporary finding that no provenance standard exists.
- Missier et al. (2013), D-PROV. https://www.usenix.org/system/files/conference/tapp13/tapp13-final3.pdf . Adds process structure and Datalog conformance analysis. Its provenance perspectives are not ontological classification levels. Credit prior rule-based workflow validation.
- Alter et al. (2025), Bridging the Gap Between Process and Procedural Provenance for Statistical Data. https://doi.org/10.2218/ijdc.v19i1.947 . Explains loss of internal transformation detail in process provenance. The present profile does not implement their procedural semantics.

The strongest new claim is native integration of an authoritative OCA/LML/TRD model with standard provenance, explicit cross-level diagnostics and a profile binding. The tests do not establish first-ever cross-level reasoning, universal Semantic Web implementation, or measured superiority over equivalent RDF/OWL encodings.

## Revised main example (18 October 2026)

The W3C PROV Primer's newspaper crime-statistics chart motivates the main example.
It already presents object-centred, agent-centred and process-centred provenance.
The maintained chart classifier, its approval policy and the review witnesses are
our synthetic extension. The classifier is not a rendering template or dataset
series, and its revision is not another classification level.
Source: https://www.w3.org/TR/prov-primer/, sections 1 and 3.

The independent RDF/SPARQL baseline returns the same answers as the native
fragment. The contribution concerns authoritative native classification and
explicit subject-preserving provenance analysis, not an inability of RDF to
store or query classifier provenance.
