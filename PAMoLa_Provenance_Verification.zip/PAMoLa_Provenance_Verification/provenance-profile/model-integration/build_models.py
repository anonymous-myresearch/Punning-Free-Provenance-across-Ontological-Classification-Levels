#!/usr/bin/env python3
"""Write bounded native models. Verification does not import this constructor."""
from collections import OrderedDict
from copy import deepcopy
from pathlib import Path
import json

HERE=Path(__file__).resolve().parent
ROOT='Ordium.IntegrationExample'
CHART='Ordium.Profile.Provenance.ChartAnalysis'
PV='Ordium.Profile.Provenance.vocab.prov'
CORE='Ordium.Core'
class Ref(str): pass
class Node:
    def __init__(self,badge,name,**props):
        self.badge=badge;self.props=OrderedDict(hasName=name,**props);self.children=[]
    def add(self,n):self.children.append(n);return n
    def render(self,depth=0):
        pad='  '*depth
        parts=[k+' '+(str(v) if isinstance(v,Ref) else json.dumps(v)) for k,v in self.props.items()]
        parts += [c.render(depth+1).lstrip() for c in self.children]
        return pad+self.badge+' {'+(',\n'+pad+'  ').join(parts)+'}'

def entity(parent,name,potency=0,declared=None,path=None):
    props={'hasLinguisticType':Ref(CORE+'.Entity'),'hasPotency':Ref(str(potency)),
           'hasPID':f'urn:pamola:integration:{path or name}'}
    if declared:props['hasDeclaredType']=Ref(ROOT+'.'+declared)
    return parent.add(Node('EN',name,**props))
def approval(parent,name,durability,value=None):
    props={'hasLinguisticType':Ref(CORE+'.Attribute'),
           'hasDataType':Ref(CORE+'.DataType.Boolean'),
           'hasDurability':Ref(str(durability))}
    if value is not None:
        props['hasValue']=Ref(CORE+'.DataType.'+('SpecialValue.unknown' if value=='unknown' else 'Boolean.'+str(value).title()))
    return parent.add(Node('AT',name,**props))
def fact(parent,name,predicate,values,parent_path,standard=True):
    n=parent.add(Node('AO',name,hasPredicate=Ref(predicate)))
    for i,v in enumerate(values,1):
        props={'bindsTo':Ref(ROOT+'.'+v),
               'fills':Ref(predicate+'.'+(('subject' if i==1 else 'object') if standard else 'P'+str(i)))}
        if i>1:props['follows']=Ref(parent_path+'.'+name+'.AG_'+str(i-1))
        n.add(Node('AG','AG_'+str(i),**props))
def generalisation(parent,sub,sup,name='generalisation'):
    n=parent.add(Node('IC',name,hasLinguisticType=Ref(CORE+'.Intercalation'),isGeneralisation=Ref('true')))
    for role,target in [('subclassifier',sub),('superclassifier',sup)]:
        n.add(Node('PA',role,hasLinguisticType=Ref(CORE+'.Participation'),hasRoleName=role,hasRelatum=Ref(ROOT+'.'+target)))
    return n
def child(root,name):return next(n for n in root.children if n.props['hasName']==name)
def base_model():
    root=Node('EN','IntegrationExample',hasFQN=ROOT,hasCustodian=Ref('Ordium'),hasLinguisticType=Ref(CORE+'.Entity'),hasPID='urn:pamola:integration:model')
    k=entity(root,'StatisticalChartType',2);approval(k,'statisticalApproval',1)
    for name,value in [('CrimeRateChart_v1',False),('CrimeRateChart_v2',True)]:
        t=entity(root,name,1,'StatisticalChartType');approval(t,'statisticalApproval',0,value)
    for name,typ in [('chart1','CrimeRateChart_v1'),('chart2','CrimeRateChart_v1'),('chart3','CrimeRateChart_v2')]:
        entity(root,name,0,typ)
    for name in ['article1','article2','guideline1','guideline2','Alice','Chen','Derek','data1','data2','data3','Analysis']:
        entity(root,name)
    graph=root.add(Node('EN','recordedProvenance',hasLinguisticType=Ref(CORE+'.Entity')))
    triples=[('wasAttributedTo','CrimeRateChart_v1','Alice'),('wasAttributedTo','CrimeRateChart_v2','Chen'),
             ('wasAttributedTo','chart1','Derek'),('wasAttributedTo','chart2','Derek'),('wasAttributedTo','chart3','Derek'),
             ('wasDerivedFrom','CrimeRateChart_v1','guideline1'),('wasDerivedFrom','CrimeRateChart_v2','guideline2'),
             ('wasDerivedFrom','chart1','data1'),('wasDerivedFrom','chart2','data2'),('wasDerivedFrom','chart3','data3'),
             ('wasDerivedFrom','article1','chart1'),('wasDerivedFrom','article2','chart3'),
             ('wasRevisionOf','CrimeRateChart_v2','CrimeRateChart_v1')]
    for i,(p,s,o) in enumerate(triples,1):fact(graph,'F'+str(i),PV+'.'+p,[s,o],ROOT+'.recordedProvenance')
    certificates=root.add(Node('EN','certificates',hasLinguisticType=Ref(CORE+'.Entity')))
    fact(certificates,'completeStatistical',CHART+'.internal.completeApprovalRegistry',
         ['Analysis','StatisticalChartType'],ROOT+'.certificates',False)
    return root
def build():
    models={}
    models['base']=base_model()
    m=deepcopy(models['base']);child(m,'chart1').props['hasDeclaredType']=Ref(ROOT+'.CrimeRateChart_v2');models['reclassifiedChart']=m
    m=deepcopy(models['base']);child(child(m,'CrimeRateChart_v1'),'statisticalApproval').props['hasValue']=Ref(CORE+'.DataType.Boolean.True');models['approvalGranted']=m
    m=deepcopy(models['base']);child(child(m,'CrimeRateChart_v1'),'statisticalApproval').props['hasValue']=Ref(CORE+'.DataType.SpecialValue.unknown');child(m,'certificates').children=[];models['incompleteRegistry']=m
    m=deepcopy(models['base']);t=entity(m,'BudgetChart_v1',1,'StatisticalChartType');approval(t,'statisticalApproval',0,False)
    for name,typ in [('chart4','BudgetChart_v1'),('article3',None),('guideline3',None),('Elena',None)]:entity(m,name,0,typ)
    g=child(m,'recordedProvenance')
    for i,(p,s,o) in enumerate([('wasAttributedTo','BudgetChart_v1','Elena'),('wasDerivedFrom','BudgetChart_v1','guideline3'),('wasDerivedFrom','article3','chart4')],20):
        fact(g,'F'+str(i),PV+'.'+p,[s,o],ROOT+'.recordedProvenance')
    models['newClassifier']=m
    m=deepcopy(models['base'])
    for folder,typ in [('A','CrimeRateChart_v1'),('B','CrimeRateChart_v2')]:
        parent=entity(m,folder);entity(parent,'chart',0,typ,path=folder+'.chart')
    models['namespaceCollision']=m
    m=deepcopy(models['base']);generalisation(m,'CrimeRateChart_v2','CrimeRateChart_v1');models['explicitSpecialisation']=m
    m=deepcopy(models['base']);k=entity(m,'SensitiveChartType',2);approval(k,'sensitiveApproval',1)
    t=child(m,'CrimeRateChart_v1');t.props['hasDeclaredType']=Ref(ROOT+'.SensitiveChartType')
    child(t,'statisticalApproval').props['hasValue']=Ref(CORE+'.DataType.Boolean.True')
    approval(t,'sensitiveApproval',0,False)
    fact(child(m,'certificates'),'completeSensitive',CHART+'.internal.completeApprovalRegistry',
         ['Analysis','SensitiveChartType'],ROOT+'.certificates',False)
    models['recategorisedClassifier']=m
    m=deepcopy(models['base']);child(m,'chart1').props['hasPotency']=Ref('1');models['badPotency']=m
    m=deepcopy(models['base']);child(m,'CrimeRateChart_v1').children=[];models['missingRequiredAttribute']=m
    m=deepcopy(models['base']);generalisation(m,'CrimeRateChart_v1','StatisticalChartType');models['flattenedGeneralisation']=m
    m=deepcopy(models['base']);child(child(m,'CrimeRateChart_v1'),'statisticalApproval').props['hasDurability']=Ref('1');models['badDurability']=m
    m=deepcopy(models['base']);child(child(m,'CrimeRateChart_v1'),'statisticalApproval').props['hasValue']=Ref(CORE+'.DataType.SpecialValue.unknown');models['falseCompleteness']=m
    m=deepcopy(models['base']);generalisation(m,'CrimeRateChart_v1','CrimeRateChart_v1');models['selfGeneralisation']=m
    # Two differently named retained features have schemas in the same OLD
    # category. Both become the same policy observation (owner, category),
    # although neither is required by this owner's current Sensitive category.
    m=deepcopy(models['recategorisedClassifier'])
    approval(child(m,'StatisticalChartType'),'alternativeStatisticalApproval',1)
    approval(child(m,'CrimeRateChart_v1'),'alternativeStatisticalApproval',0,False)
    t=child(m,'CrimeRateChart_v2');t.props['hasDeclaredType']=Ref(ROOT+'.SensitiveChartType')
    approval(t,'sensitiveApproval',0,True)
    models['duplicateRetainedApproval']=m
    (HERE/'models').mkdir(exist_ok=True)
    for name,model in models.items():(HERE/'models'/f'{name}.fhas').write_text(model.render()+'\n')
    print(json.dumps({'native_models_written':len(models)}))
if __name__=='__main__':build()

