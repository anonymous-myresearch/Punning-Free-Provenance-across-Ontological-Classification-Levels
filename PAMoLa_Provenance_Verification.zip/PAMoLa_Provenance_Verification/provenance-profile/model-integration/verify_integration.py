#!/usr/bin/env python3
"""Independent bounded native-contract interpreter, projection and query parity.

No builder import. This executes the stated finite contract and decoded chart
rules, not the official PAMoLa runtime or the complete LML/TRD profiles.
"""
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
import csv,hashlib,json,sys
import rdflib
from rdflib import Dataset,Literal,Namespace,RDF,RDFS,URIRef

HERE=Path(__file__).resolve().parent
PROFILE=HERE.parent
sys.path.insert(0,str(PROFILE/'tools'))
sys.path.insert(0,str(PROFILE/'reference-analysis'))
import fhas_reference as native
import reference_analysis as reference
ROOT='Ordium.IntegrationExample'
CORE='Ordium.Core'
BASE='Ordium.Profile.Provenance.ChartAnalysis'
PV='Ordium.Profile.Provenance.vocab.prov'
EX=Namespace('https://example.org/provenance-chart/')
PROV=Namespace('http://www.w3.org/ns/prov#')
NATIVE=Namespace('urn:pamola:projection:')
STANDARD={'derived':'wasDerivedFrom','attributed':'wasAttributedTo','revisionOf':'wasRevisionOf'}
QUERIES={'classifierProvenance':'classifier-provenance.rq','reviewType':'review-type.rq',
         'reviewEntity':'review-entity.rq','reviewPublication':'review-publication.rq',
         'approvalUndetermined':'approval-undetermined.rq'}
OUTPUTS=set(QUERIES)

class ContractError(Exception):
    def __init__(self,code,*witness):
        self.code=code;self.witness=witness;super().__init__(code+': '+', '.join(witness))
def demand(ok,code,*witness):
    if not ok:raise ContractError(code,*witness)
def fqn(name):return ROOT+'.'+name
def direct_attributes(node):
    return [n for n in node['children'] if n['badge']=='AT']
def signature(attr):
    return (attr['props']['hasName'],attr['props'].get('hasDataType'))
def number(node,key):
    value=node['props'].get(key)
    demand(value is not None and str(value).isdigit(),'missing-nonnegative-scalar',node['fqn'],key)
    return int(value)
def native_fact(node,all_nodes):
    pred=node['props']['hasPredicate']
    demand(pred in all_nodes,'unresolved-predicate',node['fqn'],pred)
    args=native.ordered_children(node,'AG','AG')
    params=[n for n in all_nodes[pred]['children'] if n['badge']=='PM']
    demand(len(args)==len(params),'predicate-arity',node['fqn'])
    values=[]
    for arg,param in zip(args,params):
        demand(arg['props'].get('fills')==param['fqn'],'argument-role',arg['fqn'])
        values.append(arg['props']['bindsTo'])
    return pred,tuple(values)

def interpret(nodes,external):
    """Validate declared scalar contract and extract its policy interface."""
    all_nodes={**external,**nodes}
    context=fqn('Analysis')
    entities={fq:n for fq,n in nodes.items() if n['badge']=='EN' and 'hasPotency' in n['props']}
    demand(context in entities,'missing-context',context)
    for fq,n in entities.items():
        demand(n['props'].get('hasLinguisticType')==CORE+'.Entity','linguistic-kind',fq)
        number(n,'hasPotency')
    reference_props=native.REFERENCE_PROPERTIES|{'hasDeclaredType','hasDataType','hasRelatum'}
    for fq,n in nodes.items():
        for key,value in n['props'].items():
            if key in reference_props:demand(value in all_nodes,'unresolved-reference',fq,key,value)
    direct=set()
    for fq,n in entities.items():
        if 'hasDeclaredType' in n['props']:
            t=n['props']['hasDeclaredType']
            demand(t in entities,'declared-type-not-entity',fq,t)
            demand(number(entities[t],'hasPotency')==number(n,'hasPotency')+1,'potency-step',fq,t)
            direct.add((fq,t))
    # Attribute applicability uses the requiredClassifierAttribute and durability
    # decrement clauses of the included LML profile. Extra local attributes are
    # allowed; they do not acquire a different category when the owner is retyped.
    for x,t in sorted(direct,key=lambda edge:(-number(entities[edge[1]],'hasPotency'),edge)):
        for upper in direct_attributes(entities[t]):
            upper_d=number(upper,'hasDurability')
            if upper_d<=0:continue
            lower=[a for a in direct_attributes(entities[x]) if signature(a)==signature(upper)]
            demand(len(lower)==1,'missing-required-attribute',x,upper['fqn'])
            demand(number(lower[0],'hasDurability')==upper_d-1,'durability-step',lower[0]['fqn'],upper['fqn'])
    schemas={}
    for k,node in entities.items():
        for attr in direct_attributes(node):
            demand(attr['props'].get('hasLinguisticType')==CORE+'.Attribute','attribute-kind',attr['fqn'])
            if number(attr,'hasDurability')>0:
                demand(number(attr,'hasDurability')==1,'unsupported-schema-depth',attr['fqn'])
                demand(attr['props'].get('hasDataType')==CORE+'.DataType.Boolean','unsupported-schema-datatype',attr['fqn'])
                demand(signature(attr) not in schemas,'ambiguous-schema',attr['fqn'])
                schemas[signature(attr)]=k
    facts=defaultdict(set)
    facts['directType']={(context,x,t) for x,t in direct}
    for k in schemas.values():facts['requiresApproval'].add((context,k))
    approval_observations={}
    for owner,node in entities.items():
        for attr in direct_attributes(node):
            sig=signature(attr)
            if number(attr,'hasDurability')!=0 or sig not in schemas:continue
            k=schemas[sig]  # Independent of the owner's CURRENT declared type.
            value=attr['props'].get('hasValue')
            demand(value in {CORE+'.DataType.Boolean.True',CORE+'.DataType.Boolean.False',CORE+'.DataType.SpecialValue.unknown'},'missing-approval-value',attr['fqn'])
            demand((owner,k) not in approval_observations,'duplicate-approval-observation',owner,k)
            approval_observations[(owner,k)]=value
            if value==CORE+'.DataType.Boolean.True':facts['approvedType'].add((context,owner,k))
    for fq,n in nodes.items():
        if n['badge']!='AO':continue
        p,values=native_fact(n,all_nodes)
        if p.startswith(PV+'.'):
            tail=p.rsplit('.',1)[-1]
            alias=next((a for a,v in STANDARD.items() if v==tail),None)
            demand(alias is not None,'unsupported-provenance-predicate',p)
            facts[alias].add((context,*values))
        elif p==BASE+'.internal.completeApprovalRegistry':
            demand(values[0]==context,'certificate-context',fq)
            facts['completeApprovalRegistry'].add(values)
        else:raise ContractError('unsupported-source-predicate',p)
    # An explicit certificate is required. The finite interpreter additionally
    # checks known values for all definitions in that sealed native source.
    for c,k in facts['completeApprovalRegistry']:
        for x,t in direct:
            if t==k:
                value=approval_observations.get((x,k))
                demand(value in {CORE+'.DataType.Boolean.True',CORE+'.DataType.Boolean.False'},'completeness-unknown',x,k)
    special=set()
    for fq,node in nodes.items():
        if node['badge']!='IC':continue
        demand(node['props'].get('isGeneralisation')=='true','unsupported-intercalation',fq)
        roles={p['props'].get('hasRoleName'):p['props'].get('hasRelatum') for p in node['children'] if p['badge']=='PA'}
        demand(set(roles)=={'subclassifier','superclassifier'},'generalisation-roles',fq)
        x,t=roles['subclassifier'],roles['superclassifier']
        demand(x in entities and t in entities,'generalisation-endpoint',fq)
        demand(x!=t,'generalisation-cycle',x,t)
        demand(number(entities[x],'hasPotency')==number(entities[t],'hasPotency'),'generalisation-level',x,t)
        special.add((x,t))
    closure={(x,x) for x in entities}|special
    changed=True
    while changed:
        nxt=closure|{(a,d) for a,b in closure for c,d in closure if b==c}
        changed=nxt!=closure;closure=nxt
    demand(not any(x!=t and (t,x) in closure for x,t in special),'generalisation-cycle')
    conforms={(x,u) for x,t in direct for a,u in closure if a==t}
    return {'context':context,'facts':facts,'direct':direct,'specialisation':special,'conforms':conforms,'entities':entities,'approval_observations':approval_observations}

def term_map(nodes):
    mapping={fq:URIRef(n['props'].get('hasPID','urn:pamola:fqn:'+fq)) for fq,n in nodes.items()}
    demand(len(set(mapping.values()))==len(mapping),'noninjective-term-map')
    return mapping

def project(model,nodes):
    """Generate RDF solely from accepted native content and the derived interface."""
    mapping=term_map(nodes);c=model['context'];dataset=Dataset();graph=dataset.graph(mapping[c])
    facts=model['facts']
    for _,x,t in facts['directType']:graph.add((mapping[x],RDF.type,mapping[t]))
    for alias,term in STANDARD.items():
        for _,x,y in facts[alias]:graph.add((mapping[x],PROV[term],mapping[y]))
    for _,x,k in facts['approvedType']:graph.add((mapping[x],EX.approvedType,mapping[k]))
    for relation in ('requiresApproval','completeApprovalRegistry'):
        for _,k in facts[relation]:graph.add((mapping[k],EX[relation],Literal(True)))
    for x,t in model['specialisation']:graph.add((mapping[x],RDFS.subClassOf,mapping[t]))
    for x,n in model['entities'].items():
        graph.add((mapping[x],NATIVE.linguisticType,URIRef('urn:pamola:core:Entity')))
    return dataset,mapping

def decode_rules(external):
    native.BASE=BASE
    module=native.read_fhas(PROFILE/'chart-analysis/Chart_Analysis_Profile.fhas')
    aliases,owners=native.interface_table(PROFILE/'chart-analysis/INTERFACES.tsv')
    rules=native.decode_rules(module,owners,{**external,**module})
    native.safety_and_strata(rules)
    def atom(a):
        demand(all(t.kind=='variable' for t in a.args),'nonvariable-analysis-fragment',a.predicate)
        return a.predicate,tuple(t.value for t in a.args)
    decoded=[(atom(r.head),[(a.negated,atom(a)) for a in r.body]) for r in rules]
    demand({r.head.predicate for r in rules}==OUTPUTS,'analysis-output-contract')
    return decoded

def roundtrip_interface(dataset,mapping,model):
    reverse={v:k for k,v in mapping.items()};c=model['context'];graph=dataset.graph(mapping[c])
    got=defaultdict(set)
    for x,_,t in graph.triples((None,RDF.type,None)):got['directType'].add((c,reverse[x],reverse[t]))
    for alias,term in STANDARD.items():
        for x,_,y in graph.triples((None,PROV[term],None)):got[alias].add((c,reverse[x],reverse[y]))
    for x,_,k in graph.triples((None,EX.approvedType,None)):got['approvedType'].add((c,reverse[x],reverse[k]))
    for name in ('requiresApproval','completeApprovalRegistry'):
        for k in graph.subjects(EX[name],Literal(True)):got[name].add((c,reverse[k]))
    for name in ('directType',*STANDARD,'approvedType','requiresApproval','completeApprovalRegistry'):
        demand(got[name]==model['facts'][name],'projection-roundtrip',name)
    return 7

def outputs(facts,context):
    return {p:sorted([list(row[1:]) for row in facts[p] if row[0]==context]) for p in QUERIES}
def run():
    external={}
    for path in sorted((PROFILE/'dependencies').glob('*.fhas')):external.update(native.read_fhas(path))
    external.update(native.read_fhas(PROFILE/'Provenance_Profile_Candidate.fhas'))
    external.update(native.read_fhas(PROFILE/'chart-analysis/Chart_Analysis_Profile.fhas'))
    rules=decode_rules(external)
    oracle=json.loads((HERE/'oracles.json').read_text())
    reports=[];accepted={};comparisons=0;projection_checks=0;source_checks=0
    (HERE/'results').mkdir(exist_ok=True)
    for case in oracle['cases']:
        name=case['id'];path=HERE/'models'/f'{name}.fhas';nodes=native.read_fhas(path)
        source_digest=hashlib.sha256(path.read_bytes()).hexdigest()
        try:model=interpret(nodes,external)
        except ContractError as error:
            demand(case.get('error')==error.code,'unexpected-rejection',name,error.code)
            reports.append({'id':name,'status':'rejected-before-projection','code':error.code,'witness':error.witness,'source_sha256':source_digest})
            continue
        demand('error' not in case,'expected-rejection-not-raised',name)
        before=deepcopy(model['facts']);facts=deepcopy(before);reference.evaluate(rules,facts)
        for p,rows in before.items():demand(facts[p]==rows,'input-mutation',name,p)
        source_checks+=1
        actual=outputs(facts,model['context'])
        expected={p:sorted([[fqn(x) for x in row] for row in case['outputs'][p]]) for p in QUERIES}
        demand(actual==expected,'native-oracle',name)
        comparisons+=len(QUERIES)
        dataset,mapping=project(model,nodes);projection_checks+=roundtrip_interface(dataset,mapping,model)
        reverse={v:k for k,v in mapping.items()}
        rdf_answers={p:[] for p in QUERIES}
        rdf_before=set(dataset.quads((None,None,None,None)))
        for p,filename in QUERIES.items():
            for row in dataset.query((PROFILE/'chart-baseline'/filename).read_text()):
                demand(row[0]==mapping[model['context']],'query-context',name)
                rdf_answers[p].append([reverse[value] for value in row[1:]])
            rdf_answers[p].sort()
            demand(rdf_answers[p]==actual[p],'rdf-query-parity',name,p)
            comparisons+=1
        demand(set(dataset.quads((None,None,None,None)))==rdf_before,'rdf-query-mutation',name)
        # Persist the projected snapshot; this is generated data, not a separately
        # authored RDF baseline. The same policy queries consume the same evidence.
        (HERE/'results'/f'{name}.trig').write_text(dataset.serialize(format='trig'))
        accepted[name]={'model':model,'outputs':actual,'rdf_quads':rdf_before,'mapping':mapping}
        reports.append({'id':name,'status':'accepted','source_sha256':source_digest,
                        'outputs':actual,'rdf_query_outputs':rdf_answers,
                        'projected_triples':len(list(dataset.quads((None,None,None,None))))})
    # Meaningful change contracts, independent from the complete tuple oracles.
    history_names=tuple(STANDARD)
    invariant_cases=['reclassifiedChart','approvalGranted','incompleteRegistry','namespaceCollision','explicitSpecialisation','recategorisedClassifier']
    history_preservation=0
    for name in invariant_cases:
        for p in history_names:
            demand(accepted[name]['model']['facts'][p]==accepted['base']['model']['facts'][p],'history-changed',name,p)
            history_preservation+=1
    # A retained old view genuinely differs after one native type reassignment.
    stale=accepted['base']['rdf_quads']!=accepted['reclassifiedChart']['rdf_quads']
    demand(stale,'stale-view-not-distinguished')
    x=fqn('chart1');t1=fqn('CrimeRateChart_v1');t2=fqn('CrimeRateChart_v2')
    demand((x,t2) in accepted['reclassifiedChart']['model']['direct'] and (x,t1) not in accepted['reclassifiedChart']['model']['direct'],'reclassification-refresh')
    # Direct typing is not transitively closed, even though conformance follows
    # an explicitly authored same-level specialisation in its separate view.
    demand((fqn('chart3'),t1) not in accepted['base']['model']['conforms'],'revision-implies-specialisation')
    demand((fqn('chart3'),t1) in accepted['explicitSpecialisation']['model']['conforms'],'specialisation-conformance')
    demand((fqn('chart3'),t1) not in accepted['explicitSpecialisation']['model']['direct'],'specialisation-implies-direct')
    m=accepted['namespaceCollision']['mapping']
    demand(m[fqn('A.chart')]!=m[fqn('B.chart')],'namespace-collision')
    # Retained historical category approval remains scoped to its schema owner.
    rec=accepted['recategorisedClassifier']['model'];c=rec['context']
    demand((c,t1,fqn('StatisticalChartType')) in rec['facts']['approvedType'],'lost-old-category-approval')
    demand((c,t1,fqn('SensitiveChartType')) not in rec['facts']['approvedType'],'approval-relabelled')
    report={'scope':'Bounded native-contract reference interpreter and generated RDF policy-query parity; not official PAMoLa runtime, full LML/TRD conformance, automatic provenance capture or maintenance/performance superiority.',
            'native_source_snapshots':len(reports),'accepted_snapshots':len(accepted),
            'rejected_snapshots':len(reports)-len(accepted),'decoded_analysis_rules':len(rules),
            'complete_output_checks':comparisons,'native_oracle_output_checks':len(accepted)*len(QUERIES),
            'rdf_query_parity_checks':len(accepted)*len(QUERIES),'projection_roundtrip_relation_checks':projection_checks,
            'native_input_preservation_checks':source_checks,'history_preservation_relation_checks':history_preservation,
            'stale_projection_difference_detected':stale,'source_rule_sha256':hashlib.sha256((PROFILE/'chart-analysis/Chart_Analysis_Profile.fhas').read_bytes()).hexdigest(),
            'classification_contract_source_sha256':hashlib.sha256((PROFILE/'dependencies/LML_Profile_v1_0_0_FirstExecutableSlice.fhas').read_bytes()).hexdigest(),
            'failures':[],'cases':reports}
    (HERE/'results/report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
if __name__=='__main__':run()

