# Native-model interpretation and controlled changes

This module addresses a narrower question than expressive power: can one selected
native model supply classification, feature scope and recorded provenance to an
unchanged policy analysis and an ordinary RDF/SPARQL consumer?

It is a **bounded reference interpreter**, not the official PAMoLa runtime or
full LML/TRD conformance. The two answer routes consume the same accepted source.
There is no claim that RDF cannot express the contract, that RDF needs a manually
duplicated model, or that this experiment measures maintenance effort/performance.

## Run

From the complete provenance-profile directory:

    python3 model-integration/build_models.py
    python3 model-integration/verify_integration.py

Python 3 and the package's pinned RDFLib 7.1.4 are required. The verifier does not
import the builder. It reads written FHAS with the independent parser, interprets
the contract below, decodes the current five chart rules, and executes the same
five stored SPARQL queries as chart-baseline/.

## Authored source and selected interpretation

Every snapshot is a complete source clade in models/. Definitions and charts are
Entities of the same linguistic Core.Entity kind. Their distinct native PIDs
supply injective RDF term mappings. Full native references are retained throughout;
no identifier is truncated to its last local name.

The base model contains:

- StatisticalChartType at potency 2, with statisticalApproval:Boolean durability 1.
- CrimeRateChart_v1 and CrimeRateChart_v2 at potency 1, directly classified by that
  category, with corresponding statisticalApproval attributes of durability 0.
  v1 is explicitly false and v2 explicitly true.
- chart1/chart2 at potency 0 directly classified by v1, and chart3 by v2.
- Thirteen recorded PROV facts: definition and chart attributions/derivations,
  article derivations, and the explicitly separate v2-to-v1 revision.
- A supplied completeness certificate for the selected native approval registry.

The contract checks native references, linguistic kinds, fixed-step potency and
the required scalar attribute correspondence before projecting analysis inputs.
The required attribute must have the same name and datatype and durability one
less than its classifier's declaration. Durability-zero approval on a definition
therefore does not require an approval attribute on charts. The test interprets
Boolean true/false and an explicit unknown observation; it does not copy an upper
attribute's value.

The source for these selected checks is the included LML profile:

| Selected check | Native rule occurrence |
|---|---|
| Classifier potency = instance potency + 1 | LML.rule.typePotencyMayHold_3 and typePotencyMayFail_3, under fixedStepPotencyActive |
| Attribute applicability when upper durability > 0 | LML.rule.requiredClassifierAttribute_2 |
| Correspondence by semantic feature name and datatype | LML.rule.sameAttributeSignature_2 and correspondingAttribute_2 |
| Durability decrements at the required step | LML.rule.durabilityStepViolation_2 |

Those clauses are the source of the finite interpreter's stated contract. The
complete completion-based LML program, every modelling style, unsupported feature
forms and the official execution services are not claimed to run here.

Explicit generalisation uses an Intercalation with named subclassifier and
superclassifier Participations. The selected binding requires equal potency and
an acyclic graph. This is a declared bounded relationship interface, not evidence
of complete TRD or Participation-classification implementation. Its conformance
view can follow that separately recorded specialisation while direct typing
remains unclosed. A revision statement never creates specialisation.

## Approval scope is independent of current categorisation

Schema attributes have distinct semantic names: statisticalApproval and
sensitiveApproval. A true local attribute supplies approval for the category
owning that schema, independently of the local element's current declared type.

The adapter rejects duplicate approval observations for an owner/category before
any value can overwrite another. The negative duplicateRetainedApproval model
uses two differently named attributes whose schemas belong to the same retained
old category. This exposes a policy-observation collision without introducing
duplicate native names or malformed FQNs.

The recategorisedClassifier snapshot moves v1 to SensitiveChartType. It retains
true statisticalApproval, supplies false sensitiveApproval, and is correctly
selected for review under the latter category. The adapter does not relabel an
old approval by joining its value to the new direct classifier.

A completeness certificate is an explicit input. The finite contract additionally
checks that each definition in the sealed native category has a known Boolean
observation for that schema. An unknown value with a retained certificate is
rejected. This cannot establish completeness of an unobserved external registry.
A failed registry retrieval remains a processing failure, not an incomplete-data
snapshot; no live retrieval service is implemented by this module.

## Projection and comparison

Accepted native sources generate an RDF named graph:

- direct native classification becomes ordinary asserted rdf:type;
- recorded PROV predicates retain their exact standard IRIs and subjects;
- approvedType is an explicit type-category pair;
- requiresApproval and completeApprovalRegistry are graph-local Boolean facts;
- linguistic typing uses a separate native projection predicate;
- explicit specialisation becomes rdfs:subClassOf.

No RDFS closure is added to the selected direct-type evidence. Queries use
ordinary RDF graph matching. The same native element receives one RDF term in
its classifier, instance and provenance roles, as RDF itself already permits.

The verifier checks an inverse projection for **seven analysis input relations**:
direct classification, derivation, attribution, revision, scoped approval,
approval requirements and completeness. This proves preservation/completeness
only for that finite interface, not reconstruction of the entire native model,
durability declarations, statement-occurrence identities or all RDF semantics.

The comparison is intentionally strong: the RDF route uses the same generated
source view and policy interpretation. Both routes get the same answers. The
experiment demonstrates a common interpreted source and a reproducible view
contract; it does not manufacture a weak manually maintained RDF alternative.

## Controlled source changes and complete output oracles

oracles.json contains independently stated complete expected relations and
rejection codes. Each accepted snapshot checks all five output relations against
that oracle and against the SPARQL result. The chart rules are decoded once and
remain unchanged throughout.

| Snapshot | Native change and observable result |
|---|---|
| base | v1, chart1/chart2 and article1 require review. |
| reclassifiedChart | One hasDeclaredType edit moves chart1 to v2; chart2 remains under review and article1 leaves the review set. Recorded histories are identical. |
| approvalGranted | One native approval value changes false to true; review witnesses disappear, with histories unchanged. |
| incompleteRegistry | Unknown approval and no completeness certificate produce an explicit approvalUndetermined witness. |
| newClassifier | A budget-chart definition, chart and article use the same interpretation and rules. |
| namespaceCollision | A.chart and B.chart have identical final local names but distinct native PIDs and query results. |
| explicitSpecialisation | A separate same-potency generalisation changes conformance without changing direct typing or review. |
| recategorisedClassifier | Retained approval for the old category does not approve the new category. |
| badPotency | Rejected before projection: an instance violates the fixed-step contract. |
| missingRequiredAttribute | Rejected before projection: a required approval attribute is absent. |
| flattenedGeneralisation | Rejected before projection: replacing a cross-level classification with generalisation violates the selected equal-potency generalisation contract. |
| badDurability | Rejected before projection: attribute durability does not decrement. |
| falseCompleteness | Rejected before projection: unknown approval contradicts the supplied completeness certificate. |
| selfGeneralisation | Rejected before projection: an explicitly authored generalisation has the same subclassifier and superclassifier. |
| duplicateRetainedApproval | Rejected before projection: two retained approval features map to the same owner/category observation, independently of current categorisation. |

All fifteen sources pass their declared expected outcome: eight accepted models
and seven expected rejections. The accepted models pass 40 complete native output
checks, 40 RDF/SPARQL parity checks and 56 input-interface round-trip comparisons.
The analysis preserves native inputs in all eight accepted snapshots. Eighteen
recorded-history relation comparisons verify exact preservation across the six
history-preserving edits. Further assertions check the specialisation/direct-type
distinction, category-bound approval and local-name collision preservation.

The retained base projection is compared with the regenerated reclassified
projection and is shown to differ. This is a controlled stale-view difference,
not an implemented production cache invalidation service.

results/report.json records the source digests, decoded-rule digest, expected
rejections and full answers. results/*.trig are generated accepted RDF views.

