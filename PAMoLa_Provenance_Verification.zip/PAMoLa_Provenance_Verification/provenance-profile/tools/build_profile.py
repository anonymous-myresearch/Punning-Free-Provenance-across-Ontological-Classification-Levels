"""Build a thin Provenance construction candidate from standard terms and paper rules."""
from pathlib import Path
from collections import OrderedDict
import csv, json, re, sys
import rdflib
from rdflib import Graph, URIRef, RDF, OWL

ROOT=Path(__file__).resolve().parents[1]
BASE='Ordium.Profile.Provenance'
SW='Ordium.Profile.SemanticWeb'
PROV='http://www.w3.org/ns/prov#'
PP='http://purl.org/net/p-plan#'
class Ref(str): pass
class Node:
    def __init__(self, badge, name, **props):
        self.badge=badge; self.props=OrderedDict(hasName=name, **props); self.children=[]
    def add(self,n): self.children.append(n); return n
    def render(self,depth=0):
        pad='  '*depth
        parts=[k+' '+(str(v) if isinstance(v,Ref) else json.dumps(v,ensure_ascii=False)) for k,v in self.props.items()]
        parts += [c.render(depth+1).lstrip() for c in self.children]
        return pad+self.badge+' {'+(',\n'+pad+'  ').join(parts)+'}'

def write_tsv(name,rows,fields):
    with (ROOT/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,delimiter='\t');w.writeheader();w.writerows(rows)

def main():
    root=Node('EN','Provenance',hasFQN=BASE,hasCustodian=Ref('Ordium.Profile'),hasLinguisticType=Ref('Ordium.Core.Entity'),hasNote='Candidate 1: standard provenance vocabulary and bounded cross-level diagnostics; no new Core category. Not official-runtime certified.')
    lexical=root.add(Node('EN','lexical'))
    vocab=root.add(Node('EN','vocab'))
    ontology=Graph().parse(ROOT/'dependencies/prov-o.ttl',format='turtle')
    kinds={OWL.Class:'Class',OWL.ObjectProperty:'ObjectProperty',OWL.DatatypeProperty:'DatatypeProperty',OWL.AnnotationProperty:'AnnotationProperty',RDF.Property:'Property'}
    terms={str(s):kinds[t] for s,_,t in ontology.triples((None,RDF.type,None)) if str(s).startswith(PROV) and t in kinds}
    for n in ('Activity','Entity','Step','Plan','Variable'):terms[PP+n]='Class'
    for n in ('correspondsToStep','correspondsToVariable','isInputVarOf'):terms[PP+n]='ObjectProperty'
    rows=[]
    for prefix, ns in [('prov',PROV),('pplan',PP)]:
        group=vocab.add(Node('EN',prefix))
        for iri,kind in sorted(terms.items()):
            if not iri.startswith(ns):continue
            name=iri[len(ns):];key=prefix+'_'+name;fqn=BASE+'.vocab.'+prefix+'.'+name
            dv=lexical.add(Node('DV',key,ofDataType=Ref('Ordium.Core.DataType.IRI')))
            dv.add(Node('LI','lexeme',hasLexeme=iri))
            n=group.add(Node('OM',name,hasNote='Standard '+kind+' identity; this declaration alone does not execute ontology axioms.'))
            ward=n.add(Node('MK','auxiliary',hasTag=Ref('Ordium.Core.DataType.WardRole.auxiliary')))
            ward.add(Node('MK','iri',hasTag=Ref(SW+'.Reference.IRI'),refersTo=Ref(BASE+'.lexical.'+key+'.lexeme')))
            if kind!='Class':
                n.add(Node('PM','subject',hasType=Ref('Ordium')))
                n.add(Node('PM','object',hasType=Ref('Ordium'),follows=Ref(fqn+'.subject')))
            rows.append(dict(iri=iri,kind=kind,owner_fqn=fqn,source='PROV-O snapshot' if prefix=='prov' else 'P-Plan 1.1 selected terms'))
    write_tsv('VOCABULARY.tsv',rows,['iri','kind','owner_fqn','source'])
    text='\n'.join(x.split('#')[0] for x in (ROOT/'reference-analysis/rules.dl').read_text().splitlines())
    def atom(t):
        p,args=re.fullmatch(r'(\w+)\(([^()]*)\)',t.strip()).groups()
        return p,tuple(x.strip() for x in args.split(','))
    rules=[]
    for clause in text.split('.'):
        if not clause.strip():continue
        head,body=clause.split(':-')
        rules.append((atom(head),[(bool(neg),atom(a)) for neg,a in re.findall(r'(not\s+)?(\w+\([^()]*\))',body)]))
    arities={p:len(args) for h,b in rules for p,args in [h]+[a for _,a in b]}
    heads={h[0] for h,b in rules}
    internal=root.add(Node('EN','internal',hasNote='Context-qualified analysis views; these names are not new PROV predicates. Inputs require authoritative adapters.'))
    interfaces=[]
    for p,arity in sorted(arities.items()):
        n=internal.add(Node('OM',p))
        for i in range(arity):
            props={'hasType':Ref('Ordium')}
            if i:props['follows']=Ref(BASE+'.internal.'+p+'.P'+str(i))
            n.add(Node('PM','P'+str(i+1),**props))
        interfaces.append(dict(alias=p,owner_fqn=BASE+'.internal.'+p,arity=arity,role='derived' if p in heads else 'input'))
    write_tsv('INTERFACES.tsv',interfaces,['alias','owner_fqn','arity','role'])
    rc=root.add(Node('EN','rule'))
    projection=[]
    for i,(h,b) in enumerate(rules,1):
        rp=BASE+'.rule.R'+str(i)
        n=rc.add(Node('AO','R'+str(i),hasPredicate=Ref(BASE+'.internal.'+h[0])))
        variables=sorted({v for p,args in [h]+[a for _,a in b] for v in args})
        def args(parent,vs,path):
            for j,v in enumerate(vs,1):
                props={'bindsTo':Ref(rp+'.'+v),'fills':Ref(rp+'.'+v)}
                if j>1:props['follows']=Ref(path+'.AG_'+str(j-1))
                parent.add(Node('AG','AG_'+str(j),**props))
        args(n,h[1],rp)
        for j,(neg,(p,vs)) in enumerate(b,1):
            props={'hasPredicate':Ref(BASE+'.internal.'+p)}
            if j>1:props['follows']=Ref(rp+'.AO_'+str(j-1))
            if neg:props['isNegated']=Ref('true')
            child=n.add(Node('AO','AO_'+str(j),**props));args(child,vs,rp+'.AO_'+str(j))
        for v in variables:n.add(Node('PM',v,hasType=Ref('Ordium')))
        def fmt(a):return a[0]+'('+','.join('?'+v for v in a[1])+')'
        projection.append(fmt(h)+' :- '+', '.join(('not ' if neg else '')+fmt(a) for neg,a in b)+'.')
    (ROOT/'Provenance_Profile_Candidate.fhas').write_text('// Native construction candidate; input adapters are specified separately.\n'+root.render()+'\n')
    (ROOT/'Provenance_Profile_Candidate.dl').write_text('\n'.join(projection)+'\n')
    ex=Node('EN','ProvenanceExample',hasFQN='Ordium.ProvenanceExample',hasCustodian=Ref('Ordium'))
    eb='Ordium.ProvenanceExample'
    for name,typ in [('ConversionKind',None),('CSVConversion','ConversionKind'),('run42','CSVConversion'),('input17',None),('Alice',None),('Bob',None),('conversionStep',None),('inputVariable',None)]:
        props={'hasLinguisticType':Ref('Ordium.Core.Entity')}
        if typ:props['hasDeclaredType']=Ref(eb+'.'+typ)
        ex.add(Node('EN',name,**props))
    graph=ex.add(Node('EN','graph',hasNote='Selected asserted graph; native type edges remain model structure.'))
    for i,(p,a,b) in enumerate([('prov.used','run42','input17'),('prov.wasAttributedTo','CSVConversion','Alice'),('prov.wasAssociatedWith','run42','Bob'),('pplan.correspondsToStep','run42','conversionStep'),('pplan.correspondsToVariable','input17','inputVariable'),('pplan.isInputVarOf','inputVariable','conversionStep')],1):
        pred=BASE+'.vocab.'+p;n=graph.add(Node('AO','F'+str(i),hasPredicate=Ref(pred)))
        n.add(Node('AG','subject',bindsTo=Ref(eb+'.'+a),fills=Ref(pred+'.subject')))
        n.add(Node('AG','object',bindsTo=Ref(eb+'.'+b),fills=Ref(pred+'.object'),follows=Ref(eb+'.graph.F'+str(i)+'.subject')))
    (ROOT/'examples/Classifier_Provenance.fhas').write_text(ex.render()+'\n')
    print(json.dumps({'standard_terms':len(terms),'prov_terms':sum(x.startswith(PROV) for x in terms),'rules':len(rules),'interfaces':len(arities)}))
if __name__=='__main__':main()
