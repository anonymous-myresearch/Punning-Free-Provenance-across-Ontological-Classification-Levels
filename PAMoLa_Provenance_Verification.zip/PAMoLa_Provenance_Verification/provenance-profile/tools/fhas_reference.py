#!/usr/bin/env python3
"""Independent checks of the SemanticWeb native FHAS construction candidate.

This reads the emitted FHAS, interface table and textual Datalog. It deliberately
does not import the construction model or its component modules. The evaluator
is a finite test oracle only, not a proposed PAMoLa execution service.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from dataclasses import dataclass
import json
import operator
from pathlib import Path
import re
import sys

BASE = 'Ordium.Profile.SemanticWeb'
ROOT = Path(__file__).resolve().parents[1]
BUILTINS = {'eq': operator.eq, 'neq': operator.ne, 'lt': operator.lt,
            'le': operator.le, 'gt': operator.gt, 'ge': operator.ge}
OPS = {'=': 'eq', '==': 'eq', '!=': 'neq', '<': 'lt', '<=': 'le',
       '>': 'gt', '>=': 'ge'}
REFERENCE_PROPERTIES = {'hasPredicate', 'bindsTo', 'fills', 'follows',
                        'hasCustodian', 'hasType', 'hasLinguisticType',
                        'ofDataType', 'hasTag', 'refersTo', 'hasResult',
                        'hasTarget', 'invokes', 'requestedBy'}


class CheckError(Exception):
    pass


def check(condition, message):
    if not condition:
        raise CheckError(message)


class FhasParser:
    """Small recursive-descent parser for the scalar-property FHAS used here."""
    def __init__(self, text, label='<FHAS>'):
        self.label = label
        self.tokens = []
        pattern = re.compile(r'\s+|//[^\n]*|"(?:\\.|[^"\\])*"|[{},]|[^\s{},"]+')
        pos = 0
        for match in pattern.finditer(text):
            check(not text[pos:match.start()].strip(),
                  f'{label}: unrecognised syntax near offset {pos}')
            token = match.group()
            pos = match.end()
            if not token.isspace() and not token.startswith('//'):
                self.tokens.append(token)
        check(not text[pos:].strip(), f'{label}: trailing unrecognised syntax')
        self.i = 0

    def take(self):
        check(self.i < len(self.tokens), f'{self.label}: unexpected end')
        token = self.tokens[self.i]
        self.i += 1
        return token

    def node(self):
        badge = self.take()
        check(re.fullmatch(r'[A-Z]{2}', badge), f'{self.label}: invalid badge {badge}')
        check(self.take() == '{', f'{self.label}: expected opening brace')
        props, children = {}, []
        while self.i < len(self.tokens) and self.tokens[self.i] != '}':
            check(self.i + 1 < len(self.tokens), f'{self.label}: incomplete node')
            if self.tokens[self.i + 1] == '{':
                children.append(self.node())
            else:
                key, value = self.take(), self.take()
                check(key not in props, f'{self.label}: duplicate property {key}')
                check(value not in ('{', '}', ','), f'{self.label}: missing value for {key}')
                props[key] = json.loads(value) if value.startswith('"') else value
            check(self.i < len(self.tokens), f'{self.label}: missing closing brace')
            if self.tokens[self.i] == ',':
                self.i += 1
            else:
                check(self.tokens[self.i] == '}', f'{self.label}: expected comma near {self.tokens[self.i]}')
        check(self.take() == '}', f'{self.label}: missing closing brace')
        return {'badge': badge, 'props': props, 'children': children}

    def parse(self):
        nodes = []
        while self.i < len(self.tokens):
            nodes.append(self.node())
        return nodes


def index_nodes(roots):
    nodes = {}
    def visit(node, parent):
        props = node['props']
        name = props.get('hasName')
        check(isinstance(name, str) and name, 'Every candidate node must have a local name')
        fqn = props.get('hasFQN', parent + '.' + name if parent else name)
        check(fqn not in nodes, f'Duplicate FQN: {fqn}')
        node['fqn'], node['parent'] = fqn, parent
        nodes[fqn] = node
        for child in node['children']:
            visit(child, fqn)
    for root in roots:
        visit(root, '')
    return nodes


def read_fhas(path):
    return index_nodes(FhasParser(path.read_text(), str(path)).parse())


def find_sources(root):
    """Use present local sources; absence is an explicit verification limit."""
    places = [root, *root.parents]
    bundled = root / 'dependencies'
    if bundled.exists():
        present = [bundled / name for name in (
            'PAMoLa_Core_Source.fhas',
            'TransitiveRelationDimensions_Profile_v1_0_0.fhas',
            'LML_Profile_v1_0_0_FirstExecutableSlice.fhas',
            'ModelingStyle_v1_0_0.fhas') if (bundled / name).exists()]
        if any(path.name == 'PAMoLa_Core_Source.fhas' for path in present):
            return present
    found = []
    for parent in places:
        core = parent / 'semanticweb-source' / 'pamola-core(1).fhas'
        if core.exists():
            found.append(core)
            break
    for parent in places:
        dep = parent / 'mlt-dependencies' / 'lml-pack'
        if dep.exists():
            found.extend(sorted(dep.glob('**/TransitiveRelationDimensions_Profile_v1_0_0.fhas')))
            found.extend(sorted(dep.glob('**/ModelingStyle_Profile_v1_0_0.fhas')))
            break
    return list(dict.fromkeys(found))


def external_inventory(root, notes):
    external, properties, badges = {'Ordium', 'Ordium.Profile'}, set(), {'OM'}
    core_nodes = {}
    for path in find_sources(root):
        try:
            nodes = read_fhas(path)
        except (CheckError, ValueError) as exc:
            notes.append(f'LIMIT: source parse not available for {path.name}: {exc}')
            continue
        external.update(nodes)
        notes.append(f'Source checked: {path.name} ({len(nodes)} native nodes)')
        if 'Ordium.Core' in nodes:
            core_nodes = nodes
            for fqn, node in nodes.items():
                if node['badge'] != 'OM':
                    continue
                note = node['props'].get('hasNote', '')
                if note.startswith('type '):
                    properties.add(node['props']['hasName'])
                badge = re.search(r'\bbadge ([A-Z]{2})\b', note)
                if badge:
                    badges.add(badge.group(1))
    if not core_nodes:
        notes.append('LIMIT: actual Core source was unavailable; property/badge provenance not checked.')
    return external, properties, badges, core_nodes


def interface_table(path):
    with path.open(newline='') as stream:
        rows = list(csv.DictReader(stream, delimiter='\t'))
    check(rows, 'Empty predicate interface table')
    aliases, owners = {}, {}
    for row in rows:
        alias = row.get('alias') or row.get('name') or row.get('predicate')
        fqn = row.get('owner_fqn') or row.get('fqn')
        check(alias and fqn, 'Interface table needs alias/name and owner_fqn columns')
        check(alias not in aliases, f'Duplicate interface alias: {alias}')
        check(fqn not in owners, f'Duplicate interface owner: {fqn}')
        row = {**row, 'alias': alias, 'owner_fqn': fqn, 'arity': int(row['arity'])}
        aliases[alias], owners[fqn] = row, row
    return aliases, owners


@dataclass(frozen=True)
class Term:
    kind: str
    value: object


@dataclass(frozen=True)
class Atom:
    predicate: str
    args: tuple
    negated: bool = False
    builtin: bool = False


@dataclass(frozen=True)
class Rule:
    name: str
    head: Atom
    body: tuple


def native_constant(fqn, nodes):
    node = nodes.get(fqn)
    if node and node['badge'] == 'DV':
        dtype = node['props'].get('ofDataType', node['parent'])
        literals = [c['props']['hasLexeme'] for c in node['children']
                    if c['badge'] == 'LI' and 'hasLexeme' in c['props']]
        if len(literals) == 1:
            lexeme = str(literals[0])
            if dtype.endswith('.Integer') and re.fullmatch(r'-?\d+', lexeme):
                return Term('integer', int(lexeme))
            if dtype.endswith('.Boolean') and lexeme in ('true', 'false'):
                return Term('boolean', lexeme == 'true')
    return Term('constant', fqn)


def ordered_children(node, badge, stem):
    children = [c for c in node['children'] if c['badge'] == badge]
    by_name = {c['props']['hasName']: c for c in children}
    expected = [f'{stem}_{i}' for i in range(1, len(children) + 1)]
    check(set(by_name) == set(expected), f'{node["fqn"]}: expected contiguous {stem} names')
    result = [by_name[name] for name in expected]
    for i, child in enumerate(result):
        expected_follow = result[i - 1]['fqn'] if i else None
        check(child['props'].get('follows') == expected_follow,
              f'{child["fqn"]}: incorrect or missing follows ordering')
    return result


def decode_rules(nodes, owners, all_nodes):
    rules = []
    for fqn, node in nodes.items():
        if node['badge'] != 'AO' or node['parent'] != BASE + '.rule':
            continue
        # Predicate declarations are separate from rule occurrences. Only a
        # declaration with no Arguments/body/Parameters is excluded here.
        if not any(c['badge'] in ('AG', 'AO', 'PM') for c in node['children']):
            continue
        parameters = {c['fqn']: c for c in node['children'] if c['badge'] == 'PM'}
        def decode(atom):
            ref = atom['props'].get('hasPredicate')
            check(ref in owners, f'{atom["fqn"]}: predicate absent from interface: {ref}')
            row = owners[ref]
            args = []
            for arg in ordered_children(atom, 'AG', 'AG'):
                binding = arg['props'].get('bindsTo')
                check(binding is not None, f'{arg["fqn"]}: missing bindsTo')
                if binding in parameters:
                    check(arg['props'].get('fills') == binding, f'{arg["fqn"]}: variable fills differs from bindsTo')
                    args.append(Term('variable', parameters[binding]['props']['hasName']))
                else:
                    check(not (binding in nodes and nodes[binding]['badge'] == 'PM'),
                          f'{arg["fqn"]}: variable escapes its owning rule')
                    args.append(native_constant(binding, all_nodes))
            check(len(args) == row['arity'], f'{atom["fqn"]}: arity differs from predicate interface')
            builtin = atom['props'].get('isExplicit') == 'false'
            check(builtin == (row['alias'] in BUILTINS), f'{atom["fqn"]}: builtin marker does not match comparison predicate')
            return Atom(row['alias'], tuple(args), atom['props'].get('isNegated') == 'true', builtin)
        head = decode(node)
        check(not head.negated and not head.builtin, f'{fqn}: invalid rule head')
        body = tuple(decode(child) for child in ordered_children(node, 'AO', 'AO'))
        rules.append(Rule(node['props']['hasName'], head, body))
    check(rules, 'No native rule occurrences decoded')
    return rules


def split_top(text, separator=','):
    result, start, depth, quote, angle, escape = [], 0, 0, False, False, False
    for i, char in enumerate(text):
        if escape:
            escape = False
            continue
        if quote and char == '\\':
            escape = True
            continue
        if char == '"' and not angle:
            quote = not quote
        elif not quote:
            if char == '<' and i + 1 < len(text) and text[i+1].isalpha():
                angle = True
            elif char == '>' and angle:
                angle = False
            elif not angle:
                if char == '(':
                    depth += 1
                elif char == ')':
                    depth -= 1
                elif char == separator and depth == 0:
                    result.append(text[start:i].strip())
                    start = i + 1
    result.append(text[start:].strip())
    return result


def parse_term(text):
    text = text.strip()
    if re.fullmatch(r'\?[A-Za-z_][A-Za-z0-9_]*', text):
        return Term('variable', text[1:])
    if re.fullmatch(r'-?\d+', text):
        return Term('integer', int(text))
    if text in ('true', 'false'):
        return Term('boolean', text == 'true')
    if text.startswith('<') and text.endswith('>'):
        return Term('constant', text[1:-1])
    if text.startswith('"'):
        return Term('string', json.loads(text))
    check(re.fullmatch(r'Ordium(?:\.[A-Za-z_][A-Za-z0-9_]*)+', text), f'Unrecognised projection term: {text}')
    return Term('constant', text)


def parse_atom(text):
    text = text.strip()
    negated = text.startswith('not ') or text.startswith('!')
    if text.startswith('not '):
        text = text[4:].strip()
    elif text.startswith('!'):
        text = text[1:].strip()
    match = re.fullmatch(r'([A-Za-z_][A-Za-z0-9_]*)\((.*)\)', text)
    if match:
        alias, arguments = match.groups()
        args = tuple(parse_term(t) for t in split_top(arguments)) if arguments.strip() else ()
        return Atom(alias, args, negated, alias in BUILTINS)
    match = re.fullmatch(r'(.+?)\s+(==|!=|<=|>=|=|<|>)\s+(.+)', text)
    check(match is not None, f'Unrecognised projection atom: {text}')
    left, op, right = match.groups()
    return Atom(OPS[op], (parse_term(left), parse_term(right)), negated, True)


def parse_projection(path):
    rules = []
    for number, raw in enumerate(path.read_text().splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith(('%', '#', '//')):
            continue
        check(line.endswith('.'), f'{path.name}:{number}: rule must end with period')
        line = line[:-1]
        if ':-' in line:
            head, body = line.split(':-', 1)
            body = tuple(parse_atom(atom) for atom in split_top(body))
        else:
            head, body = line, ()
        rules.append(Rule(f'line_{number}', parse_atom(head), body))
    return rules


def variables(atom):
    return {t.value for t in atom.args if t.kind == 'variable'}


def safety_and_strata(rules):
    predicates = {a.predicate for r in rules for a in (r.head, *r.body) if not a.builtin}
    strata = {p: 0 for p in predicates}
    for rule in rules:
        bound = set()
        for atom in rule.body:
            if atom.negated or atom.builtin:
                check(variables(atom) <= bound, f'{rule.name}: unsafe ordered negative/builtin variables {variables(atom)-bound}')
            else:
                bound.update(variables(atom))
        check(variables(rule.head) <= bound, f'{rule.name}: unsafe head variables {variables(rule.head)-bound}')
    for _ in range(len(predicates) + 1):
        changed = False
        for rule in rules:
            for atom in rule.body:
                if atom.builtin:
                    continue
                layer = strata[atom.predicate] + int(atom.negated)
                if strata[rule.head.predicate] < layer:
                    strata[rule.head.predicate] = layer
                    changed = True
        if not changed:
            return strata
    raise CheckError('Unstratified negative predicate dependency cycle')


def value(term, environment):
    return environment[term.value] if term.kind == 'variable' else term.value


def evaluate(rules, edb, max_rounds=200, max_facts=100000):
    """Finite, function-free reference evaluation of independently decoded rules."""
    strata = safety_and_strata(rules)
    facts = defaultdict(set, {p: {tuple(row) for row in rows} for p, rows in edb.items()})
    rounds = 0
    def match(atom, environment):
        if atom.builtin:
            args = [value(t, environment) for t in atom.args]
            test = BUILTINS[atom.predicate](*args)
            return [environment] if (not test if atom.negated else test) else []
        if atom.negated:
            row = tuple(value(t, environment) for t in atom.args)
            return [] if row in facts[atom.predicate] else [environment]
        results = []
        for row in tuple(facts[atom.predicate]):
            check(len(row) == len(atom.args), f'Fixture arity mismatch for {atom.predicate}')
            bound = dict(environment)
            for term, actual in zip(atom.args, row):
                if term.kind == 'variable' and term.value not in bound:
                    bound[term.value] = actual
                elif value(term, bound) != actual:
                    break
            else:
                results.append(bound)
        return results
    for layer in range(max(strata.values(), default=0) + 1):
        selected = [r for r in rules if strata[r.head.predicate] == layer]
        changed = True
        while changed:
            rounds += 1
            check(rounds <= max_rounds, 'Reference evaluator exceeded finite round limit')
            changed = False
            for rule in selected:
                environments = [{}]
                for atom in rule.body:
                    environments = [next_env for env in environments for next_env in match(atom, env)]
                    if not environments:
                        break
                rows = {tuple(value(t, env) for t in rule.head.args) for env in environments}
                new = rows - facts[rule.head.predicate]
                if new:
                    facts[rule.head.predicate].update(new)
                    changed = True
            check(sum(map(len, facts.values())) <= max_facts, 'Reference evaluator exceeded finite fact limit')
    return dict(facts), rounds


def structural_checks(root, notes):
    nodes = read_fhas(root / 'SemanticWeb_Profile_Candidate.fhas')
    external, allowed, badges, core_nodes = external_inventory(root, notes)
    unresolved = set()
    for fqn, node in nodes.items():
        props = node['props']
        check('__' not in props['hasName'], f'{fqn}: authored name contains forbidden double underscore')
        if node['parent'] and 'hasCustodian' in props:
            check(props['hasCustodian'] == node['parent'], f'{fqn}: explicit custodian conflicts with containment')
        if allowed:
            check(set(props) <= allowed, f'{fqn}: properties not declared by actual Core: {set(props)-allowed}')
            check(node['badge'] in badges, f'{fqn}: badge absent from actual Core declarations: {node["badge"]}')
        for prop in REFERENCE_PROPERTIES:
            ref = props.get(prop)
            if not ref:
                continue
            if ref.startswith(BASE + '.') or ref == BASE:
                check(ref in nodes, f'{fqn}: unresolved internal {prop} reference {ref}')
            elif ref.startswith('Ordium') and ref not in external:
                unresolved.add((prop, ref))
        for prop, expected_badge in (('fills', 'PM'), ('hasTag', 'DV'), ('ofDataType', 'DT')):
            ref = props.get(prop)
            target = nodes.get(ref) or core_nodes.get(ref)
            if target is not None:
                check(target['badge'] == expected_badge, f'{fqn}: {prop} target must be {expected_badge}')
    check(not unresolved, 'Unresolved external references: ' + repr(sorted(unresolved)))
    aliases, owners = interface_table(root / 'PREDICATE_INTERFACE.tsv')
    for fqn, row in owners.items():
        check(fqn in nodes or fqn in external, f'Interface owner does not resolve: {fqn}')
    rules = decode_rules(nodes, owners, {**core_nodes, **nodes})
    projection = parse_projection(root / 'SemanticWeb_Profile_Candidate.dl')
    actual = Counter((r.head, r.body) for r in rules)
    textual = Counter((r.head, r.body) for r in projection)
    check(actual == textual, f'FHAS/projection parity failed: {sum((actual-textual).values())} native-only, {sum((textual-actual).values())} text-only clauses; first native-only={next(iter(actual-textual), None)}; first text-only={next(iter(textual-actual), None)}')
    strata = safety_and_strata(rules)
    notes.extend([f'PASS: {len(nodes)} native FHAS nodes with unique names and resolved references.',
                  f'PASS: {len(aliases)} predicate signatures and {len(rules)} independently decoded rule clauses.',
                  'PASS: native Argument/body follows order, local Parameter binding and builtin flags.',
                  'PASS: exact multiset parity with separately parsed textual Datalog projection.',
                  f'PASS: ordered variable safety and stratified negation (maximum stratum {max(strata.values(), default=0)}).'])
    return rules, nodes, aliases, (external, allowed, badges, core_nodes)


def example_checks(root, profile_nodes, source_context, notes):
    external, allowed, badges, core_nodes = source_context
    paths = sorted((root / 'examples').glob('*.fhas'))
    all_examples, per_file = {}, []
    for path in paths:
        nodes = read_fhas(path)
        check(not (set(nodes) & (set(profile_nodes) | set(all_examples))),
              f'{path.name}: example identities collide with profile or other example')
        all_examples.update(nodes)
        per_file.append((path, nodes))
    combined = {**core_nodes, **profile_nodes, **all_examples}
    for path, nodes in per_file:
        for fqn, node in nodes.items():
            props = node['props']
            check('__' not in props['hasName'], f'{fqn}: forbidden double underscore')
            if allowed:
                check(set(props) <= allowed, f'{fqn}: unknown Core properties {set(props)-allowed}')
                check(node['badge'] in badges, f'{fqn}: unknown native badge')
            if node['parent'] and 'hasCustodian' in props:
                check(props['hasCustodian'] == node['parent'], f'{fqn}: inconsistent explicit custodian')
            for prop in REFERENCE_PROPERTIES:
                ref = props.get(prop)
                if ref and ref.startswith('Ordium'):
                    check(ref in combined or ref in external, f'{fqn}: unresolved example {prop}: {ref}')
            for prop, kind in (('fills', 'PM'), ('hasTag', 'DV'), ('ofDataType', 'DT')):
                ref = props.get(prop)
                if ref in combined:
                    check(combined[ref]['badge'] == kind, f'{fqn}: {prop} target must be {kind}')
        notes.append(f'PASS example: {path.name} ({len(nodes)} nodes; names, native properties and linked references).')
    if not paths:
        notes.append('LIMIT: no standalone .fhas examples were present for structural checking.')


def run_fixture_file(path, rules, notes):
    fixtures = json.loads(path.read_text())
    check(fixtures.get('oracle_policy') == 'manually specified', 'Fixture expectations must be manually specified')
    selected = [rule for rule in rules if not fixtures.get('rule_prefixes') or any(rule.name.startswith(prefix) for prefix in fixtures['rule_prefixes'])]
    check(selected, 'Fixture suite selected no native rules')
    for case in fixtures['cases']:
        facts, rounds = evaluate(selected, case['input'])
        for expected in case['checks']:
            predicate, pattern = expected['predicate'], expected['pattern']
            actual = {row for row in facts.get(predicate, ()) if len(row) == len(pattern) and all(v is None or v == item for v, item in zip(pattern, row))}
            wanted = {tuple(row) for row in expected['rows']}
            check(actual == wanted, f'Fixture {case["name"]}: {predicate}{tuple(pattern)} expected {sorted(wanted, key=repr)}, obtained {sorted(actual, key=repr)}')
        notes.append(f'PASS fixture: {case["name"]} ({len(case["checks"])} manual checks; {rounds} finite rounds).')
    return len(fixtures['cases'])


def self_checks(notes):
    # Independent fault injection confirms that the validator rejects hazards.
    v = Term('variable', 'X')
    p, q = Atom('p', (v,)), Atom('q', (v,))
    failures = [
        ('unsafe head', [Rule('bad', p, ())]),
        ('unsafe negation', [Rule('bad', p, (Atom('q', (v,), True),))]),
        ('negative cycle', [Rule('a', p, (q, Atom('p', (v,), True)))]),
    ]
    for name, rules in failures:
        try:
            safety_and_strata(rules)
        except CheckError:
            continue
        raise CheckError(f'Validator self-check did not reject {name}')
    check(parse_atom('?X != 1') == Atom('neq', (v, Term('integer', 1)), False, True), 'Builtin parser self-check')
    check(split_top('p(?X, <Ordium.X>), not q(?X)') == ['p(?X, <Ordium.X>)', 'not q(?X)'], 'Clause splitter self-check')
    notes.append('PASS: five independent parser/safety fault-detection self-checks.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    root = args.root.resolve()
    notes = ['SemanticWeb FHAS construction candidate — independent validation',
             'This is NOT an official PAMoLa parser/linker/runtime certification.', '']
    success = False
    try:
        self_checks(notes)
        rules, nodes, aliases, source_context = structural_checks(root, notes)
        example_checks(root, nodes, source_context, notes)
        count = 0
        for filename in ('semanticweb_kernel.json', 'semanticweb_services.json'):
            fixture_path = root / 'fixtures' / filename
            check(fixture_path.exists(), 'Missing manually specified fixture suite: ' + filename)
            count += run_fixture_file(fixture_path, rules, notes)
        notes.extend(['', f'PASS: all {count} finite kernel fixtures.',
                      'LIMIT: adapters, materialisation, full SPARQL/SHACL/RIF services and the official native runtime are not exercised by these finite tests.',
                      'LIMIT: external linking checks establish declared source identities, not runtime semantic compatibility.',
                      'LIMIT: no claim of complete OWL entailment or complete Semantic Web conformance follows from these checks.'])
        success = True
    except Exception as exc:
        notes.extend(['', f'FAIL: {type(exc).__name__}: {exc}'])
    text = '\n'.join(notes) + '\n'
    (root / 'VALIDATION.txt').write_text(text)
    print(text, end='')
    return 0 if success else 1


if __name__ == '__main__':
    sys.exit(main())
