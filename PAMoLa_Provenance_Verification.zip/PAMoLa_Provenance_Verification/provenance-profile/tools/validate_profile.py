"""Independent native decoding and execution checks. No builder imports."""
from pathlib import Path
from collections import defaultdict
import csv, json, sys
import fhas_reference as native

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'reference-analysis'))
import reference_analysis as reference

def main():
    native.BASE='Ordium.Profile.Provenance'
    nodes=native.read_fhas(ROOT/'Provenance_Profile_Candidate.fhas')
    example=native.read_fhas(ROOT/'examples/Classifier_Provenance.fhas')
    all_nodes={}
    for p in sorted((ROOT/'dependencies').glob('*.fhas')):
        all_nodes.update(native.read_fhas(p))
    all_nodes.update(nodes);all_nodes.update(example)
    refs=0
    for fqn,n in {**nodes,**example}.items():
        for key,value in n['props'].items():
            if key in native.REFERENCE_PROPERTIES|{'hasDeclaredType'}:
                assert value in all_nodes or value in {'true','false','Ordium.Profile'},(fqn,key,value)
                refs+=1
    aliases,owners=native.interface_table(ROOT/'INTERFACES.tsv')
    rules=native.decode_rules(nodes,owners,all_nodes)
    projected=native.parse_projection(ROOT/'Provenance_Profile_Candidate.dl')
    assert [(r.head,r.body) for r in rules]==[(r.head,r.body) for r in projected]
    strata=native.safety_and_strata(rules)
    def aa(a):
        assert all(t.kind=='variable' for t in a.args)
        return (a.predicate,tuple(t.value for t in a.args))
    executable=[(aa(r.head),[(a.negated,aa(a)) for a in r.body]) for r in rules]
    old=reference.parse_rules(ROOT/'reference-analysis/rules.dl')
    assert executable==old
    fx=json.loads((ROOT/'reference-analysis/fixtures.json').read_text())
    count=0;explicit=0;results=[]
    for case in fx['cases']:
        raw={tuple(f) for f in fx['base']}
        for name in case.get('extensions',[]):raw.update(tuple(f) for f in fx['extensions'][name])
        for f in case.get('remove',[]):raw.remove(tuple(f))
        raw.update(tuple(f) for f in case.get('add',[]))
        facts=defaultdict(set)
        for p,*vals in raw:facts[p].add(tuple(case['id'] if v=='$C' else v for v in vals))
        reference.prepare_views(facts)
        reference.evaluate(executable,facts)
        actual={p:sorted([list(r[1:]) for r in facts[p]]) for p in reference.OUTPUT_RELATIONS}
        for p in reference.OUTPUT_RELATIONS:
            assert actual[p]==sorted(case['expected'][p]),(case['id'],p);count+=1
        for check in case.get('checks',[]):
            p,*vals=check['fact'];row=tuple(case['id'] if v=='$C' else v for v in vals)
            assert (row in facts[p])==check['present'],(case['id'],check);explicit+=1
        results.append({'case':case['id'],'outputs':actual})
    # OCA example: the classifier is one node playing both ontological roles.
    eb='Ordium.ProvenanceExample'
    assert example[eb+'.run42']['props']['hasDeclaredType']==eb+'.CSVConversion'
    assert example[eb+'.CSVConversion']['props']['hasDeclaredType']==eb+'.ConversionKind'
    assert all(example[eb+'.'+x]['props']['hasLinguisticType']=='Ordium.Core.Entity' for x in ('run42','CSVConversion','ConversionKind'))
    # Policy selection must not mutate the native classification or attribution relations.
    assert not {'directType','conformsType','corresponds','wasAttributedTo','wasAssociatedWith'}&{r.head.predicate for r in rules}
    summary={'scope':'Independent FHAS parser/decoder plus finite reference execution, not official PAMoLa runtime',
             'profile_nodes':len(nodes),'example_nodes':len(example),'resolved_references':refs,'rule_clauses':len(rules),
             'max_stratum':max(strata.values()),'fixture_snapshots':len(results),'complete_relation_comparisons':count,
             'explicit_fact_checks':explicit,'failures':[],'cases':results}
    (ROOT/'results/native-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps({k:v for k,v in summary.items() if k!='cases'},indent=2))
if __name__=='__main__':main()
