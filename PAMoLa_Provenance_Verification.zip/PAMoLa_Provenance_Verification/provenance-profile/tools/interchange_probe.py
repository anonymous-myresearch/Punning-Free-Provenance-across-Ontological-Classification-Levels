"""Reference interchange checks through RDFLib, not production PAMoLa wares."""
from pathlib import Path
import csv, json
import rdflib
from rdflib import Graph, Dataset, URIRef, BNode, Literal, Namespace, RDF, XSD
from rdflib.compare import isomorphic
import fhas_reference as native

ROOT=Path(__file__).resolve().parents[1]
EX=Namespace('https://example.org/provenance/')
PROV=Namespace('http://www.w3.org/ns/prov#')
rdflib.NORMALIZE_LITERALS=False

def native_graph():
    nodes=native.read_fhas(ROOT/'examples/Classifier_Provenance.fhas')
    with (ROOT/'VOCABULARY.tsv').open() as f:iris={r['owner_fqn']:URIRef(r['iri']) for r in csv.DictReader(f,delimiter='\t')}
    g=Graph()
    for fqn,n in nodes.items():
        if n['badge']!='AO':continue
        args={a['props']['hasName']:a for a in n['children'] if a['badge']=='AG'}
        assert set(args)=={'subject','object'}
        assert args['object']['props']['follows']==fqn+'.subject'
        pred=n['props']['hasPredicate'];assert args['subject']['props']['fills']==pred+'.subject'
        assert args['object']['props']['fills']==pred+'.object'
        def term(a):return EX[a['props']['bindsTo'].split('.')[-1]]
        g.add((term(args['subject']),iris[pred],term(args['object'])))
    assert len(g)==6
    assert (EX.CSVConversion,PROV.wasAttributedTo,EX.Alice) in g
    assert (EX.run42,PROV.wasAttributedTo,EX.Alice) not in g
    return g

def guarded_dataset_export(d,fmt):
    named=[g for g in d.contexts() if g.identifier!=d.default_context.identifier]
    if any(len(g)==0 for g in named):
        reason='N-Quads has no empty graph declaration' if fmt=='nquads' else 'This RDFLib TriG binding drops empty named graphs; a preserving adapter is required'
        raise ValueError(reason)
    return d.serialize(format=fmt)

def lexical_jsonld(g):
    """Expanded JSON-LD with string lexical values, never native JSON numbers."""
    def identifier(t):return '_:'+str(t) if isinstance(t,BNode) else str(t)
    records=[]
    for subject in sorted(set(g.subjects()),key=str):
        record={'@id':identifier(subject)}
        for predicate,obj in sorted(g.predicate_objects(subject),key=lambda x:(str(x[0]),str(x[1]))):
            if isinstance(obj,Literal):
                value={'@value':str(obj)}
                if obj.language:value['@language']=obj.language
                elif obj.datatype:value['@type']=str(obj.datatype)
            else:value={'@id':identifier(obj)}
            record.setdefault(str(predicate),[]).append(value)
        records.append(record)
    return json.dumps(records,ensure_ascii=False,indent=2)

def main():
    g=native_graph();out=ROOT/'examples/interchange';out.mkdir(exist_ok=True)
    g.serialize(destination=out/'native-provenance.ttl',format='turtle')
    # Additional authored RDF evidence exercises exact terms and qualification.
    usage=BNode('usage');g.add((EX.run42,PROV.qualifiedUsage,usage));g.add((usage,RDF.type,PROV.Usage));g.add((usage,PROV.entity,EX.input17))
    g.add((EX.input17,EX.counter,Literal('01',datatype=XSD.integer,normalize=False)))
    g.add((EX.input17,EX.counter,Literal('1',datatype=XSD.integer,normalize=False)))
    g.add((EX.CSVConversion,EX.label,Literal('Prüfung',lang='de')))
    g.add((EX.input17,EX.externalValue,Literal('opaque',datatype=EX.UnknownDatatype)))
    results=[]
    for fmt,extension in [('turtle','ttl'),('nt','nt'),('xml','rdf'),('json-ld','jsonld')]:
        # N-Triples is a legal Turtle subset. Explicit typed lexical forms avoid
        # RDFLib's numeric Turtle shorthand parser collapsing 01 into 1.
        data=lexical_jsonld(g) if fmt=='json-ld' else g.serialize(format='nt' if fmt=='turtle' else fmt)
        (out/('term-stress.'+extension)).write_text(data)
        back=Graph().parse(data=data,format=fmt)
        assert isomorphic(g,back),fmt
        assert {str(o) for o in back.objects(EX.input17,EX.counter)}=={'01','1'}
        results.append({'format':fmt,'test':'RDF graph round trip','triples':len(g),'status':'pass'})
    d=Dataset();shared=BNode('shared')
    d.graph(EX.graph1).add((EX.run42,PROV.qualifiedUsage,shared))
    d.graph(EX.graph2).add((shared,PROV.entity,EX.input17))
    for fmt,extension in [('trig','trig'),('nquads','nq')]:
        data=guarded_dataset_export(d,fmt);back=Dataset();back.parse(data=data,format=fmt)
        a=list(back.graph(EX.graph1).objects(EX.run42,PROV.qualifiedUsage))
        b=list(back.graph(EX.graph2).subjects(PROV.entity,EX.input17))
        assert len(a)==1 and a==b and isinstance(a[0],BNode)
        assert len(back.graph(EX.graph1))==len(back.graph(EX.graph2))==1
        (out/('dataset.'+extension)).write_text(data)
        results.append({'format':fmt,'test':'named graphs and shared blank node','status':'pass'})
    d.graph(EX.emptyGraph)
    for fmt in ('trig','nquads'):
        try:guarded_dataset_export(d,fmt)
        except ValueError as error:results.append({'format':fmt,'test':'reject loss of empty named graph','status':'expected rejection','reason':str(error)})
        else:raise AssertionError('Empty graph loss was not rejected')
    summary={'scope':'Reference native-fact extraction and RDFLib interchange probes; not full syntax conformance or deployed wares',
             'rdflib_version':rdflib.__version__,'native_facts':6,'round_trip_probes':6,'expected_loss_rejections':2,'results':results}
    (ROOT/'results/interchange.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
