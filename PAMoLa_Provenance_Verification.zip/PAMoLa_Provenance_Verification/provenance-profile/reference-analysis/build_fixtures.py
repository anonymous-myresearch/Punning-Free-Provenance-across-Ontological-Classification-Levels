"""Author compact input fixtures and independently stated expected outcomes."""
import copy
import json
from pathlib import Path

C = "$C"
base = [
    ["classifier", C, x] for x in (
        "ConversionKind", "StandardConversion", "CSVConversion",
        "TabularDataset", "CSVDataset", "ImageDataset")
] + [
    ["directType", C, "StandardConversion", "ConversionKind"],
    ["directType", C, "CSVConversion", "ConversionKind"],
    ["directType", C, "run42", "CSVConversion"],
    ["directType", C, "input17", "CSVDataset"],
    ["specializes", C, "CSVConversion", "StandardConversion"],
    ["specializes", C, "CSVDataset", "TabularDataset"],
    ["declaredDisjoint", C, "ImageDataset", "CSVDataset"],
    ["expectedInput", C, "StandardConversion", "TabularDataset"],
    ["expectedInput", C, "CSVConversion", "CSVDataset"],
    ["requiresApproval", C, "ConversionKind"],
    ["completeApprovalRegistry", C, "ConversionKind"],
    ["approvedType", C, "StandardConversion"],
    ["approvedType", C, "CSVConversion"],
    ["stepType", C, "conversionStep", "CSVConversion"],
    ["corresponds", C, "run42", "conversionStep"],
    ["stepInPlan", C, "conversionStep", "conversionPlan"],
    ["designatedInputVariable", C, "conversionStep", "inputVariable"],
    ["used", C, "run42", "input17"],
    ["correspondsVariable", C, "input17", "inputVariable"],
    ["completeInputs", C, "run42"],
    ["designedBy", C, "CSVConversion", "Alice"],
    ["executedBy", C, "run42", "Bob"],
]
expected = {
    "candidate": [["run42", "CSVConversion"]],
    "effectiveInput": [["CSVConversion", "CSVDataset"],
                       ["CSVConversion", "TabularDataset"],
                       ["StandardConversion", "TabularDataset"]],
    "wrongInput": [], "hasInput": [["run42"]], "missingInput": [],
    "unapprovedType": [], "unapprovedUse": [],
}


def check(predicate, *row, present=True):
    return {"fact": [predicate, C, *row], "present": present}


common_checks = [
    check("conformsType", "run42", "StandardConversion"),
    check("conformsType", "run42", "ConversionKind", present=False),
    check("directType", "run42", "ConversionKind", present=False),
    check("executedBy", "run42", "Alice", present=False),
    check("designedBy", "CSVConversion", "Bob", present=False),
    check("executedBy", "run42", "Bob"),
    check("designedBy", "CSVConversion", "Alice"),
]
cases = []


def case(id, description, remove=(), add=(), changes=None, checks=None, extensions=()):
    result = {"id": id, "description": description, "remove": list(remove),
              "add": list(add), "extensions": list(extensions),
              "expected": copy.deepcopy(expected),
              "checks": copy.deepcopy(common_checks if checks is None else checks)}
    result["expected"].update(changes or {})
    cases.append(result)


case("A_suitable", "CSV input satisfies both retained contracts; approval evidence is present.")
case("B_incompatible", "Image input is positively disjoint with the CSV requirement.",
     remove=[["directType", C, "input17", "CSVDataset"]],
     add=[["directType", C, "input17", "ImageDataset"]],
     changes={"wrongInput": [
         ["run42", "CSVConversion", "input17", "CSVDataset", "ImageDataset"]]})
case("C_unknown_type", "Input exists but lacks type evidence: no incompatibility witness.",
     remove=[["directType", C, "input17", "CSVDataset"]])
case("D_missing_closed", "No designated input; selected input enumeration is explicitly complete.",
     remove=[["used", C, "run42", "input17"]],
     changes={"hasInput": [], "missingInput": [["run42", "CSVConversion"]]})
case("E_missing_open", "No designated input; no completeness assertion, hence no absence diagnostic.",
     remove=[["used", C, "run42", "input17"], ["completeInputs", C, "run42"]],
     changes={"hasInput": []})
case("F_unapproved_closed", "Approval absent from complete registry: classifier and its use flagged.",
     remove=[["approvedType", C, "CSVConversion"]],
     changes={"unapprovedType": [["CSVConversion", "ConversionKind"]],
              "unapprovedUse": [["run42", "CSVConversion"]]})
case("G_provenance_separation", "Designer Alice and execution agent Bob stay attached to their subjects.")
case("H_correspondence_only", "Contract selected through plan correspondence; no native run type supplied.",
     remove=[["directType", C, "run42", "CSVConversion"]],
     checks=[check("candidate", "run42", "CSVConversion"),
             check("directType", "run42", "CSVConversion", present=False),
             check("conformsType", "run42", "CSVConversion", present=False),
             check("conformsType", "run42", "StandardConversion", present=False),
             check("conformsType", "run42", "ConversionKind", present=False)])
case("I_approval_open", "Approval not known, but registry not closed: no unapproved diagnostic.",
     remove=[["approvedType", C, "CSVConversion"],
             ["completeApprovalRegistry", C, "ConversionKind"]])
case("J_configuration_excluded", "Only an unrelated configuration entity is used: designated input remains missing.",
     remove=[["used", C, "run42", "input17"]],
     add=[["used", C, "run42", "configuration17"],
          ["correspondsVariable", C, "configuration17", "configurationVariable"],
          ["directType", C, "configuration17", "ImageDataset"]],
     changes={"hasInput": [], "missingInput": [["run42", "CSVConversion"]]},
     checks=common_checks + [check("inputForRun", "run42", "configuration17", present=False)])

tsv = [
    ["classifier", C, "TSVConversion"], ["classifier", C, "TSVDataset"],
    ["directType", C, "TSVConversion", "ConversionKind"],
    ["specializes", C, "TSVConversion", "StandardConversion"],
    ["specializes", C, "TSVDataset", "TabularDataset"],
    ["declaredDisjoint", C, "CSVDataset", "TSVDataset"],
    ["expectedInput", C, "TSVConversion", "TSVDataset"],
]
for run, step, plan, entity, dtype in (
    ("run64", "labStep", "labPlan", "input64", "TSVDataset"),
    ("run65", "reportStep", "reportPlan", "input65", "TSVDataset"),
    ("run66", "archiveStep", "archivePlan", "input66", "CSVDataset"),
):
    variable = step + "InputVariable"
    tsv.extend([
        ["directType", C, run, "TSVConversion"],
        ["directType", C, entity, dtype],
        ["stepType", C, step, "TSVConversion"],
        ["stepInPlan", C, step, plan],
        ["corresponds", C, run, step],
        ["designatedInputVariable", C, step, variable],
        ["correspondsVariable", C, entity, variable],
        ["used", C, run, entity], ["completeInputs", C, run],
    ])

extended_expected = {
    "candidate": [["run42", "CSVConversion"], ["run64", "TSVConversion"],
                  ["run65", "TSVConversion"], ["run66", "TSVConversion"]],
    "effectiveInput": expected["effectiveInput"] + [
        ["TSVConversion", "TSVDataset"], ["TSVConversion", "TabularDataset"]],
    "hasInput": [["run42"], ["run64"], ["run65"], ["run66"]],
    "wrongInput": [["run66", "TSVConversion", "input66", "TSVDataset", "CSVDataset"]],
    "unapprovedType": [["TSVConversion", "ConversionKind"]],
    "unapprovedUse": [["run64", "TSVConversion"], ["run65", "TSVConversion"],
                      ["run66", "TSVConversion"]],
}
evolution_checks = common_checks + [
    check("effectiveInput", "TSVConversion", "CSVDataset", present=False),
    check("conformsType", "run64", "StandardConversion"),
    check("conformsType", "run64", "ConversionKind", present=False),
    check("unapprovedUse", "run42", "CSVConversion", present=False),
]
case("K_tsv_before_approval", "Three workflows share new TSV classifier; one wrong input, three unapproved uses.",
     changes=extended_expected, checks=evolution_checks, extensions=["tsv_three_workflows"])
case("L_tsv_after_approval", "Same three workflows after current approval: input violation remains.",
     add=[["approvedType", C, "TSVConversion"]],
     changes={**extended_expected, "unapprovedType": [], "unapprovedUse": []},
     checks=evolution_checks, extensions=["tsv_three_workflows"])

data = {"description": "Independent snapshots; $C expands to each case ID. Expected result rows omit context.",
        "base": base, "extensions": {"tsv_three_workflows": tsv}, "cases": cases}
Path(__file__).with_name("fixtures.json").write_text(json.dumps(data, indent=2) + "\n")
