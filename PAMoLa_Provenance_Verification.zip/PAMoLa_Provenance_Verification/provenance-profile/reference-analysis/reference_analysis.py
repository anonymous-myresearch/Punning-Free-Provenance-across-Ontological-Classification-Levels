#!/usr/bin/env python3
"""Finite reference evaluation of six provenance diagnostic rule schemes.

Python standard library only. This is not a PAMoLa adapter, OWL reasoner,
or complete implementation of any classification/provenance standard.
"""
import argparse
import hashlib
import json
import re
from collections import defaultdict
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUTPUT_RELATIONS = (
    "candidate", "effectiveInput", "wrongInput", "hasInput", "missingInput",
    "unapprovedType", "unapprovedUse",
)


def atom(text):
    name, args = re.fullmatch(r"(\w+)\(([^()]*)\)", text.strip()).groups()
    return name, tuple(x.strip() for x in args.split(","))


def parse_rules(path):
    source = "\n".join(line.split("#", 1)[0] for line in path.read_text().splitlines())
    rules = []
    for clause in source.split("."):
        if not clause.strip():
            continue
        head, body = clause.split(":-")
        literals = [(bool(neg), atom(text)) for neg, text in re.findall(
            r"(not\s+)?(\w+\([^()]*\))", body)]
        rules.append((atom(head), literals))
    return rules


def match(arguments, row, bindings):
    if len(arguments) != len(row):
        raise ValueError("Relation arity mismatch")
    result = dict(bindings)
    for variable, value in zip(arguments, row):
        if variable in result and result[variable] != value:
            return None
        result[variable] = value
    return result


def evaluate(rules, facts):
    """Least fixed point per stratum; reject non-stratified rule sets.

    All symbols in the supplied rule arguments are variables. Negated
    atoms must be fully bound by earlier positive literals.
    """
    strata = defaultdict(int)
    predicates = {head[0] for head, _ in rules}
    for _, body in rules:
        predicates.update(name for _, (name, _) in body)
    for _ in range(len(predicates) + 1):
        changed = False
        for (head, _), body in rules:
            required = max(strata[name] + int(neg) for neg, (name, _) in body)
            if required > strata[head]:
                strata[head] = required
                changed = True
        if not changed:
            break
    else:
        raise ValueError("Negation dependency is not stratifiable")
    for level in range(max(strata.values()) + 1):
        selected = [r for r in rules if strata[r[0][0]] == level]
        while True:
            additions = defaultdict(set)
            for (head, head_args), body in selected:
                assignments = [{}]
                for negated, (predicate, args) in body:
                    next_assignments = []
                    for assignment in assignments:
                        if negated:
                            if any(v not in assignment for v in args):
                                raise ValueError("Unsafe negated atom")
                            if tuple(assignment[v] for v in args) not in facts[predicate]:
                                next_assignments.append(assignment)
                        else:
                            for row in facts[predicate]:
                                unified = match(args, row, assignment)
                                if unified is not None:
                                    next_assignments.append(unified)
                    assignments = next_assignments
                for assignment in assignments:
                    additions[head].add(tuple(assignment[v] for v in head_args))
            count = 0
            for predicate, rows in additions.items():
                count += len(rows - facts[predicate])
                facts[predicate].update(rows)
            if count == 0:
                break
    return dict(strata)


def prepare_views(facts):
    """Precisely specified, deliberately restricted fixture read interface."""
    subclasses = set(facts["specializes"])
    subclasses.update((c, t, t) for c, t in facts["classifier"])
    while True:
        more = {(c, a, d) for c, a, b in subclasses
                for c2, b2, d in subclasses if c == c2 and b == b2}
        if more <= subclasses:
            break
        subclasses.update(more)
    facts["subClass"].update(subclasses)
    facts["conformsType"].update(
        (c, x, parent) for c, x, t in facts["directType"]
        for c2, child, parent in subclasses if c == c2 and child == t)
    symmetric = set(facts["declaredDisjoint"])
    symmetric.update((c, b, a) for c, a, b in tuple(symmetric))
    facts["disjoint"].update(
        (c, a, b) for c, x, y in symmetric
        for c2, a, x2 in subclasses if c == c2 and x == x2
        for c3, b, y2 in subclasses if c == c3 and y == y2)
    # One plan position and one designated input role per run in this example.
    for c, run, step in facts["corresponds"]:
        if sum(c == c2 and run == r2 for c2, r2, _ in facts["corresponds"]) != 1:
            raise ValueError("Fixture interface requires one corresponding step per run")
        variables = [v for c2, s2, v in facts["designatedInputVariable"]
                     if c == c2 and step == s2]
        if len(variables) != 1:
            raise ValueError("Fixture interface requires one designated input role per step")
        for c2, run2, entity in facts["used"]:
            if c == c2 and run == run2 and (c, entity, variables[0]) in facts["correspondsVariable"]:
                facts["inputForRun"].add((c, run, entity))


def serialise(facts):
    return {name: [list(row) for row in sorted(rows)]
            for name, rows in sorted(facts.items()) if rows}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixtures", type=Path, default=HERE / "fixtures.json")
    parser.add_argument("--output-dir", type=Path, default=HERE / "results")
    args = parser.parse_args()
    fixtures = json.loads(args.fixtures.read_text())
    rules_path = HERE / "rules.dl"
    rules = parse_rules(rules_path)
    outputs, resolved, failures = [], {}, []
    for case in fixtures["cases"]:
        raw = {tuple(f) for f in fixtures["base"]}
        for name in case.get("extensions", []):
            raw.update(tuple(f) for f in fixtures["extensions"][name])
        for fact in case.get("remove", []):
            if tuple(fact) not in raw:
                raise ValueError("Attempt to remove absent fixture fact")
            raw.remove(tuple(fact))
        raw.update(tuple(f) for f in case.get("add", []))
        # Each scenario is an independent context/snapshot, never a union.
        facts = defaultdict(set)
        for predicate, *values in raw:
            facts[predicate].add(tuple(case["id"] if x == "$C" else x for x in values))
        resolved[case["id"]] = serialise(facts)
        prepare_views(facts)
        strata = evaluate(rules, facts)
        # Expected rows omit their common context column for compact fixtures.
        actual = {name: sorted([list(row[1:]) for row in facts[name]])
                  for name in OUTPUT_RELATIONS}
        for predicate in OUTPUT_RELATIONS:
            expected = sorted(case["expected"][predicate])
            if actual[predicate] != expected:
                failures.append({"case": case["id"], "relation": predicate,
                                 "expected": expected, "actual": actual[predicate]})
        for check in case.get("checks", []):
            predicate, *row = check["fact"]
            row = tuple(case["id"] if x == "$C" else x for x in row)
            present = row in facts[predicate]
            if present != check["present"]:
                failures.append({"case": case["id"], "check": check, "actual": present})
        outputs.append({"id": case["id"], "description": case["description"],
                        "outputs": actual,
                        "selected_inputs": sorted([list(row[1:]) for row in facts["inputForRun"]]),
                        "explicit_check_count": len(case.get("checks", [])),
                        "derived_relation_strata": {p: strata[p] for p in OUTPUT_RELATIONS},
                        "all_read_views_and_facts": serialise(facts)})
    args.output_dir.mkdir(parents=True, exist_ok=True)
    summary = {"scope": "Independent finite Python reference evaluation; not PAMoLa/Nemo/OWL execution",
               "rule_schemes": 6, "rule_clauses_including_hasInput_helper": len(rules),
               "rule_file_sha256": hashlib.sha256(rules_path.read_bytes()).hexdigest(),
               "fixture_snapshots": len(outputs),
               "relation_output_comparisons": len(outputs) * len(OUTPUT_RELATIONS),
               "explicit_fact_checks": sum(c["explicit_check_count"] for c in outputs),
               "failures": failures,
               "cases": outputs}
    (args.output_dir / "results.json").write_text(json.dumps(summary, indent=2) + "\n")
    (args.output_dir / "resolved-inputs.json").write_text(json.dumps(resolved, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "cases"}, indent=2))
    raise SystemExit(bool(failures))


if __name__ == "__main__":
    main()
